'use client';

import React, { createContext, useContext, useState, useEffect } from 'react';

export interface CartItem {
  menuItemId: string;
  name: string;
  price: number;
  quantity: number;
  imageUrl?: string | null;
  notes?: string;
}

interface CartContextType {
  items: CartItem[];
  tableId: string | null;
  tableNumber: number | null;
  tableName: string | null;
  isOpen: boolean;
  setIsOpen: (open: boolean) => void;
  setTableContext: (id: string, num: number, name: string) => void;
  addItem: (item: Omit<CartItem, 'quantity'> & { quantity?: number }) => void;
  updateQuantity: (menuItemId: string, quantity: number) => void;
  updateNotes: (menuItemId: string, notes: string) => void;
  removeItem: (menuItemId: string) => void;
  clearCart: () => void;
  totalAmount: number;
  itemCount: number;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

export function CartProvider({ children }: { children: React.ReactNode }) {
  const [items, setItems] = useState<CartItem[]>([]);
  const [tableId, setTableId] = useState<string | null>(null);
  const [tableNumber, setTableNumber] = useState<number | null>(null);
  const [tableName, setTableName] = useState<string | null>(null);
  const [isOpen, setIsOpen] = useState(false);

  // Load cart from localStorage
  useEffect(() => {
    try {
      const savedCart = localStorage.getItem('restaurant_cart');
      const savedTable = localStorage.getItem('restaurant_table_session');
      if (savedCart) setItems(JSON.parse(savedCart));
      if (savedTable) {
        const parsed = JSON.parse(savedTable);
        setTableId(parsed.id);
        setTableNumber(parsed.number);
        setTableName(parsed.name);
      }
    } catch (e) {
      console.error('Failed to load cart state:', e);
    }
  }, []);

  // Save cart to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('restaurant_cart', JSON.stringify(items));
    } catch {}
  }, [items]);

  const setTableContext = (id: string, num: number, name: string) => {
    setTableId(id);
    setTableNumber(num);
    setTableName(name);
    try {
      localStorage.setItem('restaurant_table_session', JSON.stringify({ id, number: num, name }));
    } catch {}
  };

  const addItem = (item: Omit<CartItem, 'quantity'> & { quantity?: number }) => {
    setItems((prev) => {
      const existing = prev.find((i) => i.menuItemId === item.menuItemId);
      if (existing) {
        return prev.map((i) =>
          i.menuItemId === item.menuItemId
            ? { ...i, quantity: i.quantity + (item.quantity || 1) }
            : i
        );
      }
      return [...prev, { ...item, quantity: item.quantity || 1 }];
    });
    setIsOpen(true);
  };

  const updateQuantity = (menuItemId: string, quantity: number) => {
    if (quantity <= 0) {
      removeItem(menuItemId);
      return;
    }
    setItems((prev) =>
      prev.map((i) => (i.menuItemId === menuItemId ? { ...i, quantity } : i))
    );
  };

  const updateNotes = (menuItemId: string, notes: string) => {
    setItems((prev) =>
      prev.map((i) => (i.menuItemId === menuItemId ? { ...i, notes } : i))
    );
  };

  const removeItem = (menuItemId: string) => {
    setItems((prev) => prev.filter((i) => i.menuItemId !== menuItemId));
  };

  const clearCart = () => {
    setItems([]);
    try {
      localStorage.removeItem('restaurant_cart');
    } catch {}
  };

  const totalAmount = items.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const itemCount = items.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <CartContext.Provider
      value={{
        items,
        tableId,
        tableNumber,
        tableName,
        isOpen,
        setIsOpen,
        setTableContext,
        addItem,
        updateQuantity,
        updateNotes,
        removeItem,
        clearCart,
        totalAmount,
        itemCount,
      }}
    >
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  const context = useContext(CartContext);
  if (!context) {
    throw new Error('useCart must be used within a CartProvider');
  }
  return context;
}

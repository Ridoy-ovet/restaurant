'use client';

import React, { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { Navbar } from '@/components/Navbar';
import { Footer } from '@/components/Footer';
import { useToast } from '@/context/ToastContext';
import { ShieldCheck, LogIn, Key, Mail, Sparkles, User } from 'lucide-react';

export default function LoginPage() {
  const router = useRouter();
  const { showToast } = useToast();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      });

      const data = await res.json();

      if (!res.ok) {
        showToast(data.error || 'Authentication failed', 'error');
        return;
      }

      showToast(`Welcome back, ${data.user.name}`, 'success');

      if (['SUPER_ADMIN', 'MANAGER', 'STAFF'].includes(data.user.role)) {
        router.push('/admin');
      } else {
        router.push('/reservation');
      }
      router.refresh();
    } catch {
      showToast('Network error during login', 'error');
    } finally {
      setLoading(false);
    }
  };

  const quickFill = (e: string, p: string) => {
    setEmail(e);
    setPassword(p);
  };

  return (
    <>
      <Navbar />

      <main className="flex-1 py-16 px-4 sm:px-6 lg:px-8 max-w-md mx-auto w-full">
        <div className="bg-surface-card rounded-3xl border border-surface-border p-8 shadow-2xl space-y-6">
          <div className="text-center space-y-2">
            <div className="w-12 h-12 rounded-full border border-gold/40 bg-surface flex items-center justify-center mx-auto text-gold">
              <Key className="w-6 h-6" />
            </div>
            <h1 className="text-2xl font-serif font-bold text-white">Sign In</h1>
            <p className="text-xs text-gray-400">
              Access your reservation pass or management dashboard
            </p>
          </div>

          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="text-[11px] font-semibold uppercase tracking-wider text-gray-400 block mb-1">
                Email Address
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 text-gray-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name@restaurant.com"
                  className="w-full bg-surface border border-surface-border rounded-xl pl-10 pr-4 py-3 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-gold"
                  required
                />
              </div>
            </div>

            <div>
              <label className="text-[11px] font-semibold uppercase tracking-wider text-gray-400 block mb-1">
                Password
              </label>
              <div className="relative">
                <Key className="w-4 h-4 text-gray-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full bg-surface border border-surface-border rounded-xl pl-10 pr-4 py-3 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-gold"
                  required
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3.5 rounded-xl bg-gold hover:bg-gold-hover text-background font-bold text-xs uppercase tracking-wider transition-all shadow-lg hover:shadow-gold/20 flex items-center justify-center gap-2 mt-2"
            >
              {loading ? (
                <span className="w-4 h-4 border-2 border-background border-t-transparent rounded-full animate-spin" />
              ) : (
                <>
                  <LogIn className="w-4 h-4" />
                  <span>Enter Platform</span>
                </>
              )}
            </button>
          </form>

          {/* Quick Demo Pre-fill helper */}
          <div className="pt-4 border-t border-surface-border space-y-2">
            <span className="text-[10px] font-bold uppercase tracking-widest text-gold block text-center">
              Quick Demo Access
            </span>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => quickFill('admin@restaurant.com', 'admin123')}
                className="p-2 rounded-lg bg-surface hover:bg-surface-hover border border-surface-border text-[11px] text-gray-300 text-left transition-colors"
              >
                <strong className="text-gold block">Super Admin</strong>
                admin@restaurant.com
              </button>
              <button
                type="button"
                onClick={() => quickFill('staff@restaurant.com', 'staff123')}
                className="p-2 rounded-lg bg-surface hover:bg-surface-hover border border-surface-border text-[11px] text-gray-300 text-left transition-colors"
              >
                <strong className="text-emerald-400 block">Waiter / Staff</strong>
                staff@restaurant.com
              </button>
              <button
                type="button"
                onClick={() => quickFill('manager@restaurant.com', 'manager123')}
                className="p-2 rounded-lg bg-surface hover:bg-surface-hover border border-surface-border text-[11px] text-gray-300 text-left transition-colors"
              >
                <strong className="text-amber-400 block">Manager</strong>
                manager@restaurant.com
              </button>
              <button
                type="button"
                onClick={() => quickFill('john@example.com', 'customer123')}
                className="p-2 rounded-lg bg-surface hover:bg-surface-hover border border-surface-border text-[11px] text-gray-300 text-left transition-colors"
              >
                <strong className="text-white block">Customer</strong>
                john@example.com
              </button>
            </div>
          </div>

          <p className="text-center text-xs text-gray-500 pt-2">
            Don't have a guest account?{' '}
            <Link href="/signup" className="text-gold hover:underline">
              Create one
            </Link>
          </p>
        </div>
      </main>

      <Footer />
    </>
  );
}

'use client';

import React, { useEffect, useState } from 'react';
import { useParams } from 'next/navigation';
import Link from 'next/link';
import { Navbar } from '@/components/Navbar';
import { Footer } from '@/components/Footer';
import { 
  CheckCircle2, 
  Clock, 
  Flame, 
  Utensils, 
  ChefHat, 
  AlertCircle,
  XCircle,
  ArrowLeft
} from 'lucide-react';

const STATUS_STEPS = [
  { key: 'NEW', label: 'Order Received', desc: 'Queued for kitchen validation' },
  { key: 'CONFIRMED', label: 'Confirmed', desc: 'Accepted by Head Chef' },
  { key: 'PREPARING', label: 'Preparing', desc: 'Cooking over Binchotan hearth' },
  { key: 'READY', label: 'Plated & Ready', desc: 'At the pass for expeditious delivery' },
  { key: 'SERVED', label: 'Served', desc: 'Delivered to your table' },
  { key: 'COMPLETED', label: 'Completed', desc: 'Dining experience concluded' },
];

export default function OrderStatusPage() {
  const params = useParams();
  const orderNumber = params.orderNumber as string;

  const [order, setOrder] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchOrder = () => {
    if (!orderNumber) return;
    fetch(`/api/orders/by-number/${orderNumber}`)
      .then((res) => res.json())
      .then((data) => {
        if (data.order) {
          setOrder(data.order);
        } else {
          setError(data.error || 'Order not found');
        }
      })
      .catch(() => setError('Failed to load order status'))
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    fetchOrder();

    // Connect to real-time SSE stream for live status progression!
    const eventSource = new EventSource('/api/realtime');

    eventSource.onmessage = (event) => {
      try {
        const payload = JSON.parse(event.data);
        if (
          payload.type === 'ORDER_STATUS_CHANGED' &&
          payload.data?.orderNumber === orderNumber
        ) {
          setOrder((prev: any) =>
            prev ? { ...prev, status: payload.data.status } : prev
          );
        }
      } catch {}
    };

    return () => {
      eventSource.close();
    };
  }, [orderNumber]);

  const currentStepIndex = order
    ? STATUS_STEPS.findIndex((s) => s.key === order.status)
    : 0;

  return (
    <>
      <Navbar />

      <main className="flex-1 py-16 px-4 sm:px-6 lg:px-8 max-w-3xl mx-auto">
        {loading ? (
          <div className="py-24 text-center text-xs text-gray-400 flex items-center justify-center gap-2">
            <span className="w-4 h-4 border-2 border-gold border-t-transparent rounded-full animate-spin" />
            Tracking kitchen status...
          </div>
        ) : error || !order ? (
          <div className="bg-surface-card p-8 rounded-3xl border border-surface-border text-center space-y-4">
            <AlertCircle className="w-12 h-12 text-rose-400 mx-auto" />
            <h2 className="text-xl font-serif font-bold text-white">Order Not Located</h2>
            <p className="text-xs text-gray-400">
              Could not find order #{orderNumber}.
            </p>
            <Link
              href="/menu"
              className="inline-block mt-4 px-6 py-2.5 rounded-full bg-gold text-background font-bold text-xs uppercase tracking-wider"
            >
              Browse Menu
            </Link>
          </div>
        ) : (
          <div className="space-y-6">
            <Link
              href="/menu"
              className="inline-flex items-center gap-2 text-xs text-gray-400 hover:text-white transition-colors"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Back to Menu</span>
            </Link>

            {/* Header Status Card */}
            <div className="bg-surface-card rounded-3xl border border-surface-border p-6 sm:p-10 shadow-2xl space-y-8">
              <div className="text-center space-y-2 border-b border-surface-border pb-6">
                <span className="text-[10px] font-bold uppercase tracking-widest text-gold bg-gold/10 border border-gold/20 px-3 py-1 rounded-full">
                  Live Kitchen Tracker
                </span>
                <h1 className="text-2xl sm:text-3xl font-serif font-bold text-white mt-3">
                  Order {order.orderNumber}
                </h1>
                <p className="text-xs text-gray-400">
                  Assigned to <span className="text-white font-medium">Table #{order.table.tableNumber}</span> ({order.table.name})
                </p>
              </div>

              {/* Progress Stepper */}
              {order.status === 'CANCELLED' ? (
                <div className="p-4 rounded-2xl bg-rose-950/40 border border-rose-800/40 flex items-center justify-center gap-3 text-rose-300 text-xs">
                  <XCircle className="w-5 h-5 text-rose-400" />
                  <span className="font-semibold">This order was cancelled.</span>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="relative">
                    {/* Stepper items */}
                    <div className="space-y-6 sm:space-y-0 sm:grid sm:grid-cols-5 gap-2 text-center">
                      {STATUS_STEPS.slice(0, 5).map((step, idx) => {
                        const isPast = idx < currentStepIndex;
                        const isCurrent = idx === currentStepIndex;

                        return (
                          <div key={step.key} className="flex flex-col items-center">
                            <div
                              className={`w-10 h-10 rounded-full flex items-center justify-center text-xs font-bold transition-all shadow-md ${
                                isCurrent
                                  ? 'bg-gold text-background ring-4 ring-gold/20 animate-pulse'
                                  : isPast
                                  ? 'bg-emerald-600 text-white'
                                  : 'bg-surface border border-surface-border text-gray-500'
                              }`}
                            >
                              {isPast ? (
                                <CheckCircle2 className="w-5 h-5" />
                              ) : isCurrent ? (
                                <ChefHat className="w-5 h-5" />
                              ) : (
                                idx + 1
                              )}
                            </div>
                            <span
                              className={`text-[11px] font-semibold mt-2 ${
                                isCurrent ? 'text-gold' : isPast ? 'text-white' : 'text-gray-500'
                              }`}
                            >
                              {step.label}
                            </span>
                            <span className="text-[9px] text-gray-400 hidden sm:block mt-0.5 leading-tight">
                              {step.desc}
                            </span>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>
              )}

              {/* Order Items Breakdown */}
              <div className="space-y-3 pt-4 border-t border-surface-border">
                <h3 className="text-xs font-semibold uppercase tracking-wider text-gray-300">
                  Dishes in this Ticket
                </h3>
                <div className="divide-y divide-surface-border bg-surface rounded-2xl p-4 border border-surface-border">
                  {order.items.map((item: any) => (
                    <div key={item.id} className="py-2.5 first:pt-0 last:pb-0 flex justify-between items-start gap-4 text-xs">
                      <div>
                        <span className="font-semibold text-white">
                          {item.quantity}x {item.menuItem.name}
                        </span>
                        {item.notes && (
                          <p className="text-[11px] text-gold/80 italic mt-0.5">
                            Note: {item.notes}
                          </p>
                        )}
                      </div>
                      <span className="font-mono text-gray-300 shrink-0 font-medium">
                        ${(item.quantity * item.unitPrice).toFixed(2)}
                      </span>
                    </div>
                  ))}

                  <div className="pt-3 mt-2 flex justify-between items-center text-sm font-bold border-t border-surface-border">
                    <span className="text-white">Total</span>
                    <span className="text-gold font-serif">${order.totalAmount.toFixed(2)}</span>
                  </div>
                </div>
              </div>

              {order.notes && (
                <div className="p-3 rounded-xl bg-surface/50 border border-surface-border text-xs text-gray-300">
                  <span className="text-gray-500 font-semibold block mb-0.5">Kitchen Memo:</span>
                  {order.notes}
                </div>
              )}
            </div>
          </div>
        )}
      </main>

      <Footer />
    </>
  );
}

'use client';

import React, { useState, useEffect } from 'react';
import { useToast } from '@/context/ToastContext';
import { 
  UtensilsCrossed, 
  Plus, 
  Trash2, 
  Edit3, 
  Check, 
  Sparkles, 
  X, 
  Image as ImageIcon,
  DollarSign,
  AlertCircle
} from 'lucide-react';

export default function AdminMenuPage() {
  const { showToast } = useToast();
  const [categories, setCategories] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  // Add / Edit Modal state
  const [modalOpen, setModalOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [formCategory, setFormCategory] = useState('');
  const [formName, setFormName] = useState('');
  const [formDesc, setFormDesc] = useState('');
  const [formPrice, setFormPrice] = useState('');
  const [formDiscount, setFormDiscount] = useState('');
  const [formImage, setFormImage] = useState('');
  const [formTags, setFormTags] = useState('');
  const [formDietary, setFormDietary] = useState('');
  const [formFeatured, setFormFeatured] = useState(false);
  const [saving, setSaving] = useState(false);

  const fetchMenu = async () => {
    try {
      const res = await fetch('/api/menu');
      const data = await res.json();
      if (data.categories) {
        setCategories(data.categories);
        if (data.categories.length > 0 && !formCategory) {
          setFormCategory(data.categories[0].id);
        }
      }
    } catch {
      showToast('Failed to load menu catalog', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchMenu();
  }, []);

  const handleToggleStock = async (item: any) => {
    try {
      const newAvail = !item.isAvailable;
      const res = await fetch(`/api/menu/${item.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isAvailable: newAvail }),
      });
      if (res.ok) {
        showToast(`${item.name} is now ${newAvail ? 'Available' : 'Sold Out'}`, 'info');
        fetchMenu();
      }
    } catch {
      showToast('Failed to update availability', 'error');
    }
  };

  const handleDeleteItem = async (itemId: string, name: string) => {
    if (!confirm(`Are you sure you wish to delete "${name}" from the menu?`)) return;
    try {
      const res = await fetch(`/api/menu/${itemId}`, { method: 'DELETE' });
      if (res.ok) {
        showToast('Dish deleted', 'info');
        fetchMenu();
      }
    } catch {
      showToast('Failed to delete item', 'error');
    }
  };

  const openAddModal = () => {
    setEditingId(null);
    setFormName('');
    setFormDesc('');
    setFormPrice('');
    setFormDiscount('');
    setFormImage('');
    setFormTags('');
    setFormDietary('');
    setFormFeatured(false);
    setModalOpen(true);
  };

  const openEditModal = (item: any) => {
    setEditingId(item.id);
    setFormCategory(item.categoryId);
    setFormName(item.name);
    setFormDesc(item.description);
    setFormPrice(String(item.price));
    setFormDiscount(item.discountPrice ? String(item.discountPrice) : '');
    setFormImage(item.imageUrl || '');
    setFormTags(item.tags || '');
    setFormDietary(item.dietary || '');
    setFormFeatured(Boolean(item.isFeatured));
    setModalOpen(true);
  };

  const handleSaveItem = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);

    const payload = {
      categoryId: formCategory,
      name: formName,
      description: formDesc,
      price: formPrice,
      discountPrice: formDiscount || null,
      imageUrl: formImage || null,
      tags: formTags || null,
      dietary: formDietary || null,
      isFeatured: formFeatured,
    };

    try {
      const url = editingId ? `/api/menu/${editingId}` : '/api/menu';
      const method = editingId ? 'PATCH' : 'POST';

      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      if (res.ok) {
        showToast(editingId ? 'Dish updated!' : 'New dish added to menu!', 'success');
        setModalOpen(false);
        fetchMenu();
      } else {
        const err = await res.json();
        showToast(err.error || 'Failed to save item', 'error');
      }
    } catch {
      showToast('Network error while saving dish', 'error');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-serif font-bold text-white">
            Digital Menu & Catalog Manager
          </h1>
          <p className="text-xs text-gray-400">
            Edit dishes, prices, seasonal specials, and instant 86/out-of-stock toggles.
          </p>
        </div>

        <button
          onClick={openAddModal}
          className="px-4 py-2.5 rounded-xl bg-gold hover:bg-gold-hover text-background font-bold text-xs uppercase tracking-wider transition-all shadow-md flex items-center gap-2"
        >
          <Plus className="w-4 h-4" />
          <span>Add New Dish</span>
        </button>
      </div>

      {loading ? (
        <div className="py-24 text-center text-xs text-gray-400 flex items-center justify-center gap-2">
          <span className="w-4 h-4 border-2 border-gold border-t-transparent rounded-full animate-spin" />
          Loading menu catalog...
        </div>
      ) : (
        <div className="space-y-12">
          {categories.map((cat) => (
            <div key={cat.id} className="space-y-4">
              <div className="border-b border-surface-border pb-2 flex justify-between items-baseline">
                <h2 className="text-lg font-serif font-bold text-white tracking-wide">
                  {cat.name}
                </h2>
                <span className="text-xs text-gold font-mono">
                  {cat.items.length} items
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                {cat.items.map((item: any) => (
                  <div
                    key={item.id}
                    className="bg-surface-card rounded-2xl border border-surface-border p-4 flex flex-col justify-between space-y-3 hover:border-gray-700 transition-all shadow-lg"
                  >
                    <div className="flex gap-3">
                      {item.imageUrl && (
                        <img
                          src={item.imageUrl}
                          alt={item.name}
                          className="w-16 h-16 rounded-xl object-cover bg-surface shrink-0"
                        />
                      )}
                      <div className="min-w-0 flex-1">
                        <div className="flex justify-between items-start gap-1">
                          <h4 className="text-sm font-bold text-white truncate">{item.name}</h4>
                          <span className="text-xs font-serif font-bold text-gold shrink-0">
                            ${item.price.toFixed(2)}
                          </span>
                        </div>
                        <p className="text-[11px] text-gray-400 line-clamp-2 mt-0.5">
                          {item.description}
                        </p>
                      </div>
                    </div>

                    <div className="pt-2 border-t border-surface-border flex items-center justify-between gap-2">
                      <button
                        onClick={() => handleToggleStock(item)}
                        className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider transition-colors ${
                          item.isAvailable
                            ? 'bg-emerald-950/60 border border-emerald-700 text-emerald-300 hover:bg-emerald-900'
                            : 'bg-rose-950/60 border border-rose-700 text-rose-300 hover:bg-rose-900'
                        }`}
                      >
                        {item.isAvailable ? 'In Stock' : 'Sold Out (86)'}
                      </button>

                      <div className="flex items-center gap-1.5">
                        <button
                          onClick={() => openEditModal(item)}
                          className="p-1.5 rounded-lg border border-surface-border hover:bg-surface-hover text-gray-400 hover:text-white"
                          title="Edit Dish"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => handleDeleteItem(item.id, item.name)}
                          className="p-1.5 rounded-lg border border-surface-border hover:bg-rose-950/40 text-gray-400 hover:text-rose-400"
                          title="Delete Dish"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Add / Edit Dish Modal */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in">
          <div className="bg-surface-card border border-surface-border rounded-2xl max-w-lg w-full p-6 shadow-2xl relative">
            <button
              onClick={() => setModalOpen(false)}
              className="absolute top-4 right-4 text-gray-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>

            <h3 className="text-lg font-serif font-bold text-white mb-4">
              {editingId ? 'Edit Dish' : 'Create New Menu Item'}
            </h3>

            <form onSubmit={handleSaveItem} className="space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-gray-400 block mb-1">Category</label>
                  <select
                    value={formCategory}
                    onChange={(e) => setFormCategory(e.target.value)}
                    className="w-full bg-surface border border-surface-border rounded-xl p-2.5 text-white"
                    required
                  >
                    {categories.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="text-gray-400 block mb-1">Dish Name *</label>
                  <input
                    type="text"
                    value={formName}
                    onChange={(e) => setFormName(e.target.value)}
                    placeholder="e.g. Pan-Seared Scallops"
                    className="w-full bg-surface border border-surface-border rounded-xl p-2.5 text-white"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="text-gray-400 block mb-1">Description</label>
                <textarea
                  rows={2}
                  value={formDesc}
                  onChange={(e) => setFormDesc(e.target.value)}
                  placeholder="Ingredients, preparation techniques, garnish..."
                  className="w-full bg-surface border border-surface-border rounded-xl p-2.5 text-white resize-none"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-gray-400 block mb-1">Price ($) *</label>
                  <input
                    type="number"
                    step="0.5"
                    min="0"
                    value={formPrice}
                    onChange={(e) => setFormPrice(e.target.value)}
                    placeholder="34.00"
                    className="w-full bg-surface border border-surface-border rounded-xl p-2.5 text-white"
                    required
                  />
                </div>
                <div>
                  <label className="text-gray-400 block mb-1">Discount Price (Optional)</label>
                  <input
                    type="number"
                    step="0.5"
                    min="0"
                    value={formDiscount}
                    onChange={(e) => setFormDiscount(e.target.value)}
                    placeholder="28.00"
                    className="w-full bg-surface border border-surface-border rounded-xl p-2.5 text-white"
                  />
                </div>
              </div>

              <div>
                <label className="text-gray-400 block mb-1">Image URL (Unsplash or direct asset)</label>
                <input
                  type="url"
                  value={formImage}
                  onChange={(e) => setFormImage(e.target.value)}
                  placeholder="https://images.unsplash.com/..."
                  className="w-full bg-surface border border-surface-border rounded-xl p-2.5 text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-gray-400 block mb-1">Dietary Tags (comma-separated)</label>
                  <input
                    type="text"
                    value={formDietary}
                    onChange={(e) => setFormDietary(e.target.value)}
                    placeholder="Gluten-Free, Vegan, Dairy-Free"
                    className="w-full bg-surface border border-surface-border rounded-xl p-2.5 text-white"
                  />
                </div>
                <div>
                  <label className="text-gray-400 block mb-1">Promotional Badges</label>
                  <input
                    type="text"
                    value={formTags}
                    onChange={(e) => setFormTags(e.target.value)}
                    placeholder="Chef's Special, Signature"
                    className="w-full bg-surface border border-surface-border rounded-xl p-2.5 text-white"
                  />
                </div>
              </div>

              <div className="flex items-center gap-2 pt-1">
                <input
                  type="checkbox"
                  id="featured"
                  checked={formFeatured}
                  onChange={(e) => setFormFeatured(e.target.checked)}
                  className="w-4 h-4 rounded text-gold"
                />
                <label htmlFor="featured" className="text-gray-300 font-medium">
                  Mark as Featured Highlight on Landing Page
                </label>
              </div>

              <button
                type="submit"
                disabled={saving}
                className="w-full py-3 rounded-xl bg-gold hover:bg-gold-hover text-background font-bold text-xs uppercase tracking-wider transition-all shadow-md flex items-center justify-center gap-2 mt-2"
              >
                {saving ? 'Saving...' : editingId ? 'Update Dish' : 'Publish Dish to Live Menu'}
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

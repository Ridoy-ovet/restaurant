'use client';

import React, { useState, useEffect } from 'react';
import { useToast } from '@/context/ToastContext';
import { ShieldCheck, Clock, User, FileText } from 'lucide-react';

export default function AdminAuditPage() {
  const { showToast } = useToast();
  const [logs, setLogs] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/audit-logs')
      .then((res) => res.json())
      .then((data) => {
        if (data.logs) setLogs(data.logs);
      })
      .catch(() => showToast('Failed to load audit trail', 'error'))
      .finally(() => setLoading(false));
  }, []);

  if (loading) {
    return (
      <div className="py-24 text-center text-xs text-gray-400 flex items-center justify-center gap-2">
        <span className="w-4 h-4 border-2 border-gold border-t-transparent rounded-full animate-spin" />
        Loading administrative audit trail...
      </div>
    );
  }

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      <div>
        <h1 className="text-2xl sm:text-3xl font-serif font-bold text-white">
          Administrative Audit Log
        </h1>
        <p className="text-xs text-gray-400">
          Cryptographic chronological record of menu alterations, table changes, and system configurations.
        </p>
      </div>

      <div className="bg-surface-card rounded-3xl border border-surface-border p-6 shadow-xl">
        {logs.length === 0 ? (
          <div className="py-12 text-center text-xs text-gray-500">
            No audit records logged yet.
          </div>
        ) : (
          <div className="divide-y divide-surface-border text-xs">
            {logs.map((log) => (
              <div key={log.id} className="py-3.5 flex flex-col sm:flex-row justify-between sm:items-center gap-2">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-[10px] font-bold px-2 py-0.5 rounded bg-surface border border-surface-border text-gold">
                      {log.action}
                    </span>
                    <span className="font-semibold text-white">
                      {log.entity}
                    </span>
                  </div>
                  <p className="text-gray-400 text-[11px]">
                    {log.details}
                  </p>
                </div>

                <div className="text-right shrink-0 text-[11px] text-gray-500 space-y-0.5">
                  <span className="block text-gray-300 font-medium">
                    {log.userName || 'System Action'} ({log.userRole || 'SYSTEM'})
                  </span>
                  <span className="font-mono text-[10px]">
                    {new Date(log.createdAt).toLocaleString()}
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

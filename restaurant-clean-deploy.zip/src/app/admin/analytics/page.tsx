'use client';

import React, { useState, useEffect } from 'react';
import { useToast } from '@/context/ToastContext';
import { BarChart3, TrendingUp, DollarSign, Calendar, Users, Flame } from 'lucide-react';

export default function AdminAnalyticsPage() {
  const { showToast } = useToast();
  const [metrics, setMetrics] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/analytics')
      .then((res) => res.json())
      .then((data) => {
        if (data.metrics) setMetrics(data.metrics);
      })
      .catch(() => showToast('Failed to load analytics', 'error'))
      .finally(() => setLoading(false));
  }, []);

  if (loading) {
    return (
      <div className="py-24 text-center text-xs text-gray-400 flex items-center justify-center gap-2">
        <span className="w-4 h-4 border-2 border-gold border-t-transparent rounded-full animate-spin" />
        Calculating operational analytics...
      </div>
    );
  }

  return (
    <div className="space-y-8 max-w-6xl mx-auto">
      <div>
        <h1 className="text-2xl sm:text-3xl font-serif font-bold text-white">
          Performance & Culinary Analytics
        </h1>
        <p className="text-xs text-gray-400">
          Revenue totals, table utilization, and top-ordered kitchen repertoire.
        </p>
      </div>

      {/* Top Metrics Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
        <div className="bg-surface-card p-6 rounded-3xl border border-surface-border space-y-2">
          <span className="text-[10px] uppercase tracking-wider text-gray-400 font-semibold">
            Total Revenue (Delivered Orders)
          </span>
          <div className="text-3xl sm:text-4xl font-serif font-bold text-gold">
            ${metrics?.totalRevenue?.toFixed(2) || '0.00'}
          </div>
          <p className="text-xs text-emerald-400 flex items-center gap-1 font-medium">
            <TrendingUp className="w-3 h-3" /> Live Kitchen Gross
          </p>
        </div>

        <div className="bg-surface-card p-6 rounded-3xl border border-surface-border space-y-2">
          <span className="text-[10px] uppercase tracking-wider text-gray-400 font-semibold">
            Today's Reserved Covers
          </span>
          <div className="text-3xl sm:text-4xl font-serif font-bold text-white">
            {metrics?.todayReservations || 0}
          </div>
          <p className="text-xs text-gray-400">
            Active confirmed dining reservations
          </p>
        </div>

        <div className="bg-surface-card p-6 rounded-3xl border border-surface-border space-y-2">
          <span className="text-[10px] uppercase tracking-wider text-gray-400 font-semibold">
            Floor Utilization
          </span>
          <div className="text-3xl sm:text-4xl font-serif font-bold text-white">
            {metrics?.tableStats?.occupied || 0}
            <span className="text-lg font-normal text-gray-500">
              {' '}/ {metrics?.tableStats?.total || 12}
            </span>
          </div>
          <p className="text-xs text-gray-400">
            {metrics?.tableStats?.available || 0} tables currently open
          </p>
        </div>
      </div>

      {/* Popular Menu Items Breakdown */}
      <div className="bg-surface-card rounded-3xl border border-surface-border p-6 sm:p-8 space-y-6">
        <h2 className="text-lg font-serif font-bold text-white flex items-center gap-2">
          <Flame className="w-5 h-5 text-gold" />
          Top-Selling Signature Repertoire
        </h2>

        {metrics?.popularDishes?.length === 0 ? (
          <p className="text-xs text-gray-500 py-6 text-center">
            No order item history yet recorded.
          </p>
        ) : (
          <div className="divide-y divide-surface-border">
            {metrics?.popularDishes?.map((dish: any, idx: number) => (
              <div key={idx} className="py-3.5 flex items-center justify-between gap-4 text-xs">
                <div className="flex items-center gap-3">
                  <span className="w-6 h-6 rounded-full bg-gold/20 text-gold flex items-center justify-center font-bold text-xs">
                    {idx + 1}
                  </span>
                  <div>
                    <h4 className="font-semibold text-white">
                      {dish.item?.name || 'Dish Item'}
                    </h4>
                    <span className="text-[11px] text-gray-400">
                      ${dish.item?.price?.toFixed(2)}
                    </span>
                  </div>
                </div>

                <div className="text-right">
                  <span className="font-mono font-bold text-white block">
                    {dish.totalOrdered} orders
                  </span>
                  <span className="text-[10px] text-gold font-medium">
                    ${((dish.item?.price || 0) * dish.totalOrdered).toFixed(2)} gross
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

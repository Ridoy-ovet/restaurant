'use client';

import React, { useState, useEffect } from 'react';
import { useToast } from '@/context/ToastContext';
import { 
  Calendar as CalendarIcon, 
  Search, 
  Plus, 
  CheckCircle2, 
  Clock, 
  Users, 
  X, 
  Filter, 
  Phone, 
  Mail,
  Edit2
} from 'lucide-react';

export default function AdminReservationsPage() {
  const { showToast } = useToast();
  const [reservations, setReservations] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [selectedDate, setSelectedDate] = useState('');
  const [selectedStatus, setSelectedStatus] = useState('ALL');

  // Manual Reservation Modal state
  const [modalOpen, setModalOpen] = useState(false);
  const [newDate, setNewDate] = useState(new Date().toISOString().split('T')[0]);
  const [newTime, setNewTime] = useState('19:00');
  const [newGuests, setNewGuests] = useState(2);
  const [newName, setNewName] = useState('');
  const [newEmail, setNewEmail] = useState('');
  const [newPhone, setNewPhone] = useState('');
  const [newNotes, setNewNotes] = useState('');
  const [submittingManual, setSubmittingManual] = useState(false);

  const fetchReservations = async () => {
    try {
      let url = '/api/reservations?';
      if (selectedDate) url += `date=${selectedDate}&`;
      if (selectedStatus && selectedStatus !== 'ALL') url += `status=${selectedStatus}&`;
      if (search) url += `search=${encodeURIComponent(search)}&`;

      const res = await fetch(url);
      const data = await res.json();
      if (data.reservations) setReservations(data.reservations);
    } catch {
      showToast('Failed to fetch reservations', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchReservations();
  }, [selectedDate, selectedStatus, search]);

  const handleUpdateStatus = async (code: string, newStatus: string) => {
    try {
      const res = await fetch(`/api/reservations/${code}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: newStatus }),
      });
      if (res.ok) {
        showToast(`Reservation marked as ${newStatus}`, 'success');
        setReservations((prev) =>
          prev.map((r) => (r.reservationCode === code ? { ...r, status: newStatus } : r))
        );
      } else {
        showToast('Failed to update reservation', 'error');
      }
    } catch {
      showToast('Network error', 'error');
    }
  };

  const handleCreateManualReservation = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmittingManual(true);

    try {
      const res = await fetch('/api/reservations', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          date: newDate,
          timeSlot: newTime,
          partySize: newGuests,
          guestName: newName,
          guestEmail: newEmail,
          guestPhone: newPhone,
          specialRequests: newNotes,
        }),
      });

      const data = await res.json();
      if (res.ok) {
        showToast(`Reservation #${data.reservation.reservationCode} created!`, 'success');
        setModalOpen(false);
        fetchReservations();
        setNewName('');
        setNewEmail('');
        setNewPhone('');
        setNewNotes('');
      } else {
        showToast(data.error || 'Failed to book reservation', 'error');
      }
    } catch {
      showToast('Network error while booking', 'error');
    } finally {
      setSubmittingManual(false);
    }
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Title & Actions */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-serif font-bold text-white">
            Table Reservations Deck
          </h1>
          <p className="text-xs text-gray-400">
            Monitor, seat, and reschedule guest dining itineraries.
          </p>
        </div>

        <button
          onClick={() => setModalOpen(true)}
          className="px-4 py-2.5 rounded-xl bg-gold hover:bg-gold-hover text-background font-bold text-xs uppercase tracking-wider transition-all shadow-md flex items-center gap-2"
        >
          <Plus className="w-4 h-4" />
          <span>New Booking</span>
        </button>
      </div>

      {/* Filter Controls Bar */}
      <div className="bg-surface-card p-4 rounded-2xl border border-surface-border flex flex-wrap items-center justify-between gap-4">
        {/* Search */}
        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search guest, code, phone..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full bg-surface border border-surface-border rounded-xl pl-9 pr-4 py-2 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-gold"
          />
        </div>

        <div className="flex flex-wrap items-center gap-3 w-full sm:w-auto">
          {/* Date Picker Filter */}
          <input
            type="date"
            value={selectedDate}
            onChange={(e) => setSelectedDate(e.target.value)}
            className="bg-surface border border-surface-border rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-gold"
          />

          {/* Status Filter */}
          <select
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value)}
            className="bg-surface border border-surface-border rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-gold"
          >
            <option value="ALL">All Statuses</option>
            <option value="CONFIRMED">Confirmed</option>
            <option value="SEATED">Seated</option>
            <option value="COMPLETED">Completed</option>
            <option value="CANCELLED">Cancelled</option>
          </select>

          {(selectedDate || selectedStatus !== 'ALL' || search) && (
            <button
              onClick={() => {
                setSelectedDate('');
                setSelectedStatus('ALL');
                setSearch('');
              }}
              className="text-xs text-gold hover:underline font-medium"
            >
              Reset Filters
            </button>
          )}
        </div>
      </div>

      {/* Reservations Table */}
      <div className="bg-surface-card rounded-2xl border border-surface-border overflow-hidden shadow-xl">
        {loading ? (
          <div className="py-24 text-center text-xs text-gray-400 flex items-center justify-center gap-2">
            <span className="w-4 h-4 border-2 border-gold border-t-transparent rounded-full animate-spin" />
            Loading reservations...
          </div>
        ) : reservations.length === 0 ? (
          <div className="py-16 text-center text-xs text-gray-500">
            No reservations found for current criteria.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-surface text-gray-400 uppercase tracking-wider text-[10px] border-b border-surface-border">
                <tr>
                  <th className="py-3.5 px-4 font-semibold">Reference</th>
                  <th className="py-3.5 px-4 font-semibold">Date & Time</th>
                  <th className="py-3.5 px-4 font-semibold">Guest Details</th>
                  <th className="py-3.5 px-4 font-semibold">Party</th>
                  <th className="py-3.5 px-4 font-semibold">Table</th>
                  <th className="py-3.5 px-4 font-semibold">Status</th>
                  <th className="py-3.5 px-4 font-semibold text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-surface-border/50 text-gray-300">
                {reservations.map((res) => (
                  <tr key={res.id} className="hover:bg-surface-hover/50 transition-colors">
                    <td className="py-3.5 px-4 font-mono font-bold text-gold">
                      {res.reservationCode}
                    </td>
                    <td className="py-3.5 px-4">
                      <span className="font-medium text-white block">{res.date}</span>
                      <span className="text-gray-400 text-[11px] flex items-center gap-1 mt-0.5">
                        <Clock className="w-3 h-3 text-gold" /> {res.timeSlot}
                      </span>
                    </td>
                    <td className="py-3.5 px-4">
                      <span className="font-semibold text-white block">{res.guestName}</span>
                      <span className="text-[11px] text-gray-400 block">{res.guestEmail}</span>
                      <span className="text-[11px] text-gray-500 block">{res.guestPhone}</span>
                      {res.specialRequests && (
                        <p className="text-[10px] text-amber-300/90 italic mt-0.5 max-w-xs truncate">
                          "{res.specialRequests}"
                        </p>
                      )}
                    </td>
                    <td className="py-3.5 px-4 font-medium text-white">
                      {res.partySize} Guests
                    </td>
                    <td className="py-3.5 px-4">
                      {res.table ? (
                        <span className="px-2 py-0.5 rounded bg-surface border border-surface-border text-gold font-mono text-[11px]">
                          Table #{res.table.tableNumber}
                        </span>
                      ) : (
                        <span className="text-gray-500">Unassigned</span>
                      )}
                    </td>
                    <td className="py-3.5 px-4">
                      <span
                        className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full border ${
                          res.status === 'CONFIRMED'
                            ? 'bg-blue-950/60 border-blue-600 text-blue-300'
                            : res.status === 'SEATED'
                            ? 'bg-emerald-950/60 border-emerald-600 text-emerald-300'
                            : res.status === 'COMPLETED'
                            ? 'bg-gray-800 border-gray-700 text-gray-300'
                            : 'bg-rose-950/60 border-rose-600 text-rose-300'
                        }`}
                      >
                        {res.status}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 text-right">
                      <div className="inline-flex items-center gap-1.5">
                        {res.status === 'CONFIRMED' && (
                          <button
                            onClick={() => handleUpdateStatus(res.reservationCode, 'SEATED')}
                            className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-[10px] uppercase tracking-wider"
                          >
                            Seat
                          </button>
                        )}
                        {res.status === 'SEATED' && (
                          <button
                            onClick={() => handleUpdateStatus(res.reservationCode, 'COMPLETED')}
                            className="px-2.5 py-1 rounded-lg bg-gray-700 hover:bg-gray-600 text-white font-bold text-[10px] uppercase tracking-wider"
                          >
                            Complete
                          </button>
                        )}
                        {res.status !== 'CANCELLED' && res.status !== 'COMPLETED' && (
                          <button
                            onClick={() => handleUpdateStatus(res.reservationCode, 'CANCELLED')}
                            className="px-2 py-1 rounded-lg border border-surface-border hover:bg-rose-950/30 text-gray-400 hover:text-rose-400 text-[10px]"
                          >
                            Cancel
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Manual Booking Modal */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in">
          <div className="bg-surface-card border border-surface-border rounded-2xl max-w-lg w-full p-6 shadow-2xl relative">
            <button
              onClick={() => setModalOpen(false)}
              className="absolute top-4 right-4 text-gray-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>

            <h3 className="text-lg font-serif font-bold text-white mb-4">
              Create Manual Reservation
            </h3>

            <form onSubmit={handleCreateManualReservation} className="space-y-4 text-xs">
              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="text-gray-400 block mb-1">Date</label>
                  <input
                    type="date"
                    value={newDate}
                    onChange={(e) => setNewDate(e.target.value)}
                    className="w-full bg-surface border border-surface-border rounded-xl p-2.5 text-white"
                    required
                  />
                </div>
                <div>
                  <label className="text-gray-400 block mb-1">Time</label>
                  <input
                    type="time"
                    value={newTime}
                    onChange={(e) => setNewTime(e.target.value)}
                    className="w-full bg-surface border border-surface-border rounded-xl p-2.5 text-white"
                    required
                  />
                </div>
                <div>
                  <label className="text-gray-400 block mb-1">Party Size</label>
                  <input
                    type="number"
                    min={1}
                    max={15}
                    value={newGuests}
                    onChange={(e) => setNewGuests(parseInt(e.target.value, 10))}
                    className="w-full bg-surface border border-surface-border rounded-xl p-2.5 text-white"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="text-gray-400 block mb-1">Guest Full Name</label>
                <input
                  type="text"
                  placeholder="Claire Delacour"
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  className="w-full bg-surface border border-surface-border rounded-xl p-2.5 text-white"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-gray-400 block mb-1">Email</label>
                  <input
                    type="email"
                    placeholder="claire@example.com"
                    value={newEmail}
                    onChange={(e) => setNewEmail(e.target.value)}
                    className="w-full bg-surface border border-surface-border rounded-xl p-2.5 text-white"
                    required
                  />
                </div>
                <div>
                  <label className="text-gray-400 block mb-1">Phone</label>
                  <input
                    type="tel"
                    placeholder="+1 (555) 019-2000"
                    value={newPhone}
                    onChange={(e) => setNewPhone(e.target.value)}
                    className="w-full bg-surface border border-surface-border rounded-xl p-2.5 text-white"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="text-gray-400 block mb-1">Special Notes / Requests</label>
                <textarea
                  rows={2}
                  placeholder="VIP guest, quiet table requested..."
                  value={newNotes}
                  onChange={(e) => setNewNotes(e.target.value)}
                  className="w-full bg-surface border border-surface-border rounded-xl p-2.5 text-white resize-none"
                />
              </div>

              <button
                type="submit"
                disabled={submittingManual}
                className="w-full py-3 rounded-xl bg-gold hover:bg-gold-hover text-background font-bold text-xs uppercase tracking-wider transition-all shadow-md flex items-center justify-center gap-2 mt-2"
              >
                {submittingManual ? 'Checking & Booking...' : 'Confirm Table Booking'}
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

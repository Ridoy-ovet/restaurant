'use client';

import React, { useState, useEffect } from 'react';
import { useToast } from '@/context/ToastContext';
import { 
  ChefHat, 
  Clock, 
  CheckCircle2, 
  Flame, 
  Utensils, 
  AlertCircle, 
  ArrowRight,
  Filter,
  RefreshCw,
  Printer
} from 'lucide-react';

export default function AdminOrdersPage() {
  const { showToast } = useToast();
  const [orders, setOrders] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedStatus, setSelectedStatus] = useState<string>('ACTIVE');

  const fetchOrders = async () => {
    try {
      const res = await fetch('/api/orders');
      const data = await res.json();
      if (data.orders) setOrders(data.orders);
    } catch {
      showToast('Failed to fetch orders', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchOrders();

    const eventSource = new EventSource('/api/realtime');
    eventSource.onmessage = (event) => {
      try {
        const payload = JSON.parse(event.data);
        if (payload.type === 'ORDER_CREATED' || payload.type === 'ORDER_STATUS_CHANGED') {
          fetchOrders();
        }
      } catch {}
    };

    return () => eventSource.close();
  }, []);

  const updateOrderStatus = async (orderId: string, newStatus: string) => {
    try {
      const res = await fetch(`/api/orders/${orderId}/status`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: newStatus }),
      });

      if (res.ok) {
        showToast(`Order status advanced to ${newStatus}`, 'success');
        setOrders((prev) =>
          prev.map((o) => (o.id === orderId ? { ...o, status: newStatus } : o))
        );
      } else {
        showToast('Failed to update status', 'error');
      }
    } catch {
      showToast('Network error updating status', 'error');
    }
  };

  const filteredOrders = orders.filter((order) => {
    if (selectedStatus === 'ALL') return true;
    if (selectedStatus === 'ACTIVE') {
      return ['NEW', 'CONFIRMED', 'PREPARING', 'READY', 'SERVED'].includes(order.status);
    }
    return order.status === selectedStatus;
  });

  const getNextStatus = (current: string) => {
    switch (current) {
      case 'NEW':
        return { label: 'Confirm Ticket', next: 'CONFIRMED', color: 'bg-blue-600 hover:bg-blue-500' };
      case 'CONFIRMED':
        return { label: 'Start Cooking', next: 'PREPARING', color: 'bg-amber-600 hover:bg-amber-500' };
      case 'PREPARING':
        return { label: 'Mark Ready', next: 'READY', color: 'bg-purple-600 hover:bg-purple-500' };
      case 'READY':
        return { label: 'Mark Served', next: 'SERVED', color: 'bg-emerald-600 hover:bg-emerald-500' };
      case 'SERVED':
        return { label: 'Complete Order', next: 'COMPLETED', color: 'bg-gray-700 hover:bg-gray-600' };
      default:
        return null;
    }
  };

  const printTicket = (order: any) => {
    window.print();
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-serif font-bold text-white">
            Live Kitchen Display System (KDS)
          </h1>
          <p className="text-xs text-gray-400">
            Real-time culinary queue with instant status progression.
          </p>
        </div>

        <button
          onClick={fetchOrders}
          className="px-3.5 py-2 rounded-xl bg-surface border border-surface-border hover:border-gold/40 text-xs text-gray-300 hover:text-white flex items-center gap-2 transition-colors"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          <span>Refresh Queue</span>
        </button>
      </div>

      {/* Status Filter Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
        {[
          { label: 'Active Kitchen (All)', value: 'ACTIVE' },
          { label: 'New Tickets', value: 'NEW' },
          { label: 'Confirmed', value: 'CONFIRMED' },
          { label: 'In Preparation', value: 'PREPARING' },
          { label: 'Ready at Pass', value: 'READY' },
          { label: 'Served', value: 'SERVED' },
          { label: 'Completed History', value: 'COMPLETED' },
          { label: 'All', value: 'ALL' },
        ].map((tab) => (
          <button
            key={tab.value}
            onClick={() => setSelectedStatus(tab.value)}
            className={`px-4 py-2 rounded-full text-xs font-semibold uppercase tracking-wider whitespace-nowrap transition-all ${
              selectedStatus === tab.value
                ? 'bg-gold text-background shadow-md shadow-gold/20'
                : 'bg-surface-card border border-surface-border text-gray-400 hover:text-white'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Orders Grid */}
      {loading ? (
        <div className="py-24 text-center text-xs text-gray-400 flex items-center justify-center gap-2">
          <span className="w-4 h-4 border-2 border-gold border-t-transparent rounded-full animate-spin" />
          Loading kitchen tickets...
        </div>
      ) : filteredOrders.length === 0 ? (
        <div className="py-20 text-center bg-surface-card rounded-3xl border border-surface-border">
          <ChefHat className="w-12 h-12 text-gray-600 mx-auto mb-3" />
          <p className="text-base font-serif text-white">No tickets in this queue</p>
          <p className="text-xs text-gray-400 mt-1">All kitchen orders are up to date.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredOrders.map((order) => {
            const nextAction = getNextStatus(order.status);
            const isNew = order.status === 'NEW';
            const isReady = order.status === 'READY';
            const isPreparing = order.status === 'PREPARING';

            return (
              <div
                key={order.id}
                className={`bg-surface-card rounded-2xl border flex flex-col justify-between overflow-hidden shadow-xl transition-all ${
                  isNew
                    ? 'border-gold shadow-gold/10 ring-2 ring-gold/20 animate-pulse'
                    : isReady
                    ? 'border-emerald-500 shadow-emerald-500/10'
                    : 'border-surface-border'
                }`}
              >
                {/* Header */}
                <div className="p-4 bg-surface border-b border-surface-border flex justify-between items-start">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-xs font-bold text-gold">
                        #{order.orderNumber}
                      </span>
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-surface-card text-gray-300 border border-surface-border">
                        {new Date(order.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>
                    <h3 className="text-base font-serif font-bold text-white mt-1">
                      Table #{order.table.tableNumber} • {order.table.name}
                    </h3>
                    <p className="text-[10px] text-gray-400">
                      Guest: <span className="text-gray-200 font-medium">{order.guestName}</span>
                    </p>
                  </div>

                  <span
                    className={`text-[10px] font-bold uppercase tracking-wider px-2.5 py-1 rounded-full border ${
                      order.status === 'NEW'
                        ? 'bg-amber-950/60 border-amber-600 text-amber-300 animate-bounce'
                        : order.status === 'PREPARING'
                        ? 'bg-purple-950/60 border-purple-600 text-purple-300'
                        : order.status === 'READY'
                        ? 'bg-emerald-950/60 border-emerald-600 text-emerald-300'
                        : 'bg-surface-card border-surface-border text-gray-400'
                    }`}
                  >
                    {order.status}
                  </span>
                </div>

                {/* Items List */}
                <div className="p-4 flex-1 divide-y divide-surface-border/60 text-xs">
                  {order.items.map((item: any) => (
                    <div key={item.id} className="py-2.5 first:pt-0 last:pb-0 flex justify-between items-start gap-3">
                      <div>
                        <div className="font-semibold text-white flex items-center gap-1.5">
                          <span className="w-5 h-5 rounded-md bg-gold/20 text-gold flex items-center justify-center font-mono font-bold text-[11px]">
                            {item.quantity}
                          </span>
                          <span>{item.menuItem.name}</span>
                        </div>
                        {item.notes && (
                          <p className="text-[11px] text-amber-400 italic mt-0.5 ml-6">
                            Note: {item.notes}
                          </p>
                        )}
                      </div>
                      <span className="font-mono text-gray-400 shrink-0">
                        ${(item.quantity * item.unitPrice).toFixed(2)}
                      </span>
                    </div>
                  ))}

                  {order.notes && (
                    <div className="pt-2 text-[11px] text-amber-300 bg-amber-950/30 p-2.5 rounded-lg mt-2 border border-amber-800/30">
                      <strong>Special Ticket Memo:</strong> {order.notes}
                    </div>
                  )}
                </div>

                {/* Footer Controls */}
                <div className="p-4 bg-surface/50 border-t border-surface-border flex items-center justify-between gap-2">
                  <span className="text-sm font-serif font-bold text-gold">
                    ${order.totalAmount.toFixed(2)}
                  </span>

                  <div className="flex items-center gap-1.5">
                    {nextAction && (
                      <button
                        onClick={() => updateOrderStatus(order.id, nextAction.next)}
                        className={`px-3.5 py-1.5 rounded-lg text-white font-bold text-xs uppercase tracking-wider transition-colors shadow-md ${nextAction.color}`}
                      >
                        {nextAction.label}
                      </button>
                    )}

                    {order.status !== 'CANCELLED' && order.status !== 'COMPLETED' && (
                      <button
                        onClick={() => updateOrderStatus(order.id, 'CANCELLED')}
                        className="px-2 py-1.5 rounded-lg border border-surface-border hover:bg-rose-950/40 text-gray-500 hover:text-rose-400 text-xs transition-colors"
                        title="Cancel Ticket"
                      >
                        Cancel
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

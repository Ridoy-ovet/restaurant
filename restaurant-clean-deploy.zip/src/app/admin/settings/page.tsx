'use client';

import React, { useState, useEffect } from 'react';
import { useToast } from '@/context/ToastContext';
import { Settings, Save, Clock, MapPin, Globe, Sparkles } from 'lucide-react';

export default function AdminSettingsPage() {
  const { showToast } = useToast();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const [name, setName] = useState('');
  const [tagline, setTagline] = useState('');
  const [description, setDescription] = useState('');
  const [address, setAddress] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [heroBanner, setHeroBanner] = useState('');

  // Service Schedule
  const [openingHours, setOpeningHours] = useState<any>({});
  const [bookingConfig, setBookingConfig] = useState<any>({});

  const fetchSettings = async () => {
    try {
      const res = await fetch('/api/settings');
      const data = await res.json();
      if (data.settings) {
        setName(data.settings.name || '');
        setTagline(data.settings.tagline || '');
        setDescription(data.settings.description || '');
        setAddress(data.settings.address || '');
        setPhone(data.settings.phone || '');
        setEmail(data.settings.email || '');
        setHeroBanner(data.settings.heroBanner || '');
        setOpeningHours(data.settings.openingHours || {});
        setBookingConfig(data.settings.bookingConfig || {});
      }
    } catch {
      showToast('Failed to load settings', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSettings();
  }, []);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);

    try {
      const res = await fetch('/api/settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name,
          tagline,
          description,
          address,
          phone,
          email,
          heroBanner,
          openingHours,
          bookingConfig,
        }),
      });

      if (res.ok) {
        showToast('Restaurant configuration successfully updated!', 'success');
      } else {
        showToast('Failed to save settings', 'error');
      }
    } catch {
      showToast('Network error while saving settings', 'error');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="py-24 text-center text-xs text-gray-400 flex items-center justify-center gap-2">
        <span className="w-4 h-4 border-2 border-gold border-t-transparent rounded-full animate-spin" />
        Loading restaurant profile...
      </div>
    );
  }

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      <div>
        <h1 className="text-2xl sm:text-3xl font-serif font-bold text-white">
          Restaurant Profile & Operating Engine
        </h1>
        <p className="text-xs text-gray-400">
          Configure brand presentation, guest booking rules, and live service periods without coding.
        </p>
      </div>

      <form onSubmit={handleSave} className="space-y-8">
        {/* Profile Card */}
        <div className="bg-surface-card rounded-3xl border border-surface-border p-6 sm:p-8 space-y-5 shadow-xl">
          <h2 className="text-base font-serif font-bold text-white flex items-center gap-2 border-b border-surface-border pb-3">
            <Globe className="w-4 h-4 text-gold" />
            Brand & Public Identity
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div>
              <label className="text-gray-400 block mb-1">Restaurant Name</label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full bg-surface border border-surface-border rounded-xl p-3 text-white"
                required
              />
            </div>
            <div>
              <label className="text-gray-400 block mb-1">Brand Tagline</label>
              <input
                type="text"
                value={tagline}
                onChange={(e) => setTagline(e.target.value)}
                className="w-full bg-surface border border-surface-border rounded-xl p-3 text-white"
                required
              />
            </div>
          </div>

          <div className="text-xs">
            <label className="text-gray-400 block mb-1">Public Story & Description</label>
            <textarea
              rows={3}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full bg-surface border border-surface-border rounded-xl p-3 text-white resize-none"
              required
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
            <div>
              <label className="text-gray-400 block mb-1">Street Address</label>
              <input
                type="text"
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                className="w-full bg-surface border border-surface-border rounded-xl p-3 text-white"
                required
              />
            </div>
            <div>
              <label className="text-gray-400 block mb-1">Concierge Phone</label>
              <input
                type="text"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full bg-surface border border-surface-border rounded-xl p-3 text-white"
                required
              />
            </div>
            <div>
              <label className="text-gray-400 block mb-1">Concierge Email</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-surface border border-surface-border rounded-xl p-3 text-white"
                required
              />
            </div>
          </div>

          <div className="text-xs">
            <label className="text-gray-400 block mb-1">Hero Banner Image URL</label>
            <input
              type="url"
              value={heroBanner}
              onChange={(e) => setHeroBanner(e.target.value)}
              className="w-full bg-surface border border-surface-border rounded-xl p-3 text-white font-mono text-[11px]"
            />
          </div>
        </div>

        {/* Booking Parameters Card */}
        <div className="bg-surface-card rounded-3xl border border-surface-border p-6 sm:p-8 space-y-5 shadow-xl">
          <h2 className="text-base font-serif font-bold text-white flex items-center gap-2 border-b border-surface-border pb-3">
            <Clock className="w-4 h-4 text-gold" />
            Table Reservation Parameters
          </h2>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs">
            <div>
              <label className="text-gray-400 block mb-1">Seating Interval (min)</label>
              <input
                type="number"
                value={bookingConfig.intervalMinutes || 15}
                onChange={(e) =>
                  setBookingConfig({ ...bookingConfig, intervalMinutes: parseInt(e.target.value, 10) })
                }
                className="w-full bg-surface border border-surface-border rounded-xl p-2.5 text-white"
              />
            </div>

            <div>
              <label className="text-gray-400 block mb-1">Standard Duration (min)</label>
              <input
                type="number"
                value={bookingConfig.defaultDurationMinutes || 90}
                onChange={(e) =>
                  setBookingConfig({ ...bookingConfig, defaultDurationMinutes: parseInt(e.target.value, 10) })
                }
                className="w-full bg-surface border border-surface-border rounded-xl p-2.5 text-white"
              />
            </div>

            <div>
              <label className="text-gray-400 block mb-1">Max Advance (Days)</label>
              <input
                type="number"
                value={bookingConfig.maxAdvanceDays || 60}
                onChange={(e) =>
                  setBookingConfig({ ...bookingConfig, maxAdvanceDays: parseInt(e.target.value, 10) })
                }
                className="w-full bg-surface border border-surface-border rounded-xl p-2.5 text-white"
              />
            </div>

            <div>
              <label className="text-gray-400 block mb-1">Max Party Size</label>
              <input
                type="number"
                value={bookingConfig.maxPartySize || 12}
                onChange={(e) =>
                  setBookingConfig({ ...bookingConfig, maxPartySize: parseInt(e.target.value, 10) })
                }
                className="w-full bg-surface border border-surface-border rounded-xl p-2.5 text-white"
              />
            </div>
          </div>
        </div>

        {/* Save CTA */}
        <div className="flex justify-end">
          <button
            type="submit"
            disabled={saving}
            className="px-8 py-3.5 rounded-xl bg-gold hover:bg-gold-hover text-background font-bold text-xs uppercase tracking-wider transition-all shadow-xl hover:shadow-gold/20 flex items-center gap-2"
          >
            <Save className="w-4 h-4" />
            <span>{saving ? 'Persisting Configuration...' : 'Save Settings'}</span>
          </button>
        </div>
      </form>
    </div>
  );
}

'use client';

import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { AdminSidebar } from '@/components/AdminSidebar';
import { useToast } from '@/context/ToastContext';
import { Bell, ShieldCheck, Menu, Wifi, WifiOff } from 'lucide-react';

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const { showToast } = useToast();
  const [user, setUser] = useState<{ id: string; name: string; role: string } | null>(null);
  const [loading, setLoading] = useState(true);
  const [isConnected, setIsConnected] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);

  // Play subtle web audio chime for incoming orders or waiter calls
  const playAlertSound = () => {
    try {
      const AudioContext = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioContext) return;
      const ctx = new AudioContext();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(587.33, ctx.currentTime); // D5
      osc.frequency.exponentialRampToValueAtTime(880, ctx.currentTime + 0.15); // A5
      gain.gain.setValueAtTime(0.2, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.35);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.4);
    } catch {}
  };

  useEffect(() => {
    // 1. Verify Authentication & Role
    fetch('/api/auth/me')
      .then((res) => res.json())
      .then((data) => {
        if (!data?.user || !['SUPER_ADMIN', 'MANAGER', 'STAFF'].includes(data.user.role)) {
          router.push('/login');
        } else {
          setUser(data.user);
        }
      })
      .catch(() => router.push('/login'))
      .finally(() => setLoading(false));

    // 2. Attach SSE Realtime Stream for Staff Dashboard
    const eventSource = new EventSource('/api/realtime');

    eventSource.onopen = () => {
      setIsConnected(true);
    };

    eventSource.onmessage = (event) => {
      try {
        const payload = JSON.parse(event.data);
        if (payload.type === 'ORDER_CREATED') {
          playAlertSound();
          showToast(
            `🔔 NEW ORDER: #${payload.data.orderNumber} for Table ${payload.data.tableNumber} ($${payload.data.totalAmount})`,
            'warning',
            8000
          );
        } else if (payload.type === 'WAITER_CALLED') {
          playAlertSound();
          showToast(
            `🚨 WAITER REQUEST: Table ${payload.data.tableNumber} (${payload.data.tableName}) is summoning staff!`,
            'error',
            10000
          );
        } else if (payload.type === 'RESERVATION_CREATED') {
          showToast(
            `📅 NEW RESERVATION: ${payload.data.guestName} booked for ${payload.data.partySize} guests on ${payload.data.date} @ ${payload.data.timeSlot}`,
            'info',
            6000
          );
        }
      } catch {}
    };

    eventSource.onerror = () => {
      setIsConnected(false);
    };

    return () => {
      eventSource.close();
    };
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center space-y-3">
          <span className="w-8 h-8 border-2 border-gold border-t-transparent rounded-full animate-spin inline-block" />
          <p className="text-xs text-gold uppercase tracking-widest font-mono">
            Verifying staff credentials...
          </p>
        </div>
      </div>
    );
  }

  if (!user) return null;

  return (
    <div className="min-h-screen bg-background flex">
      {/* Desktop Sidebar */}
      <div className="hidden lg:block">
        <AdminSidebar userRole={user.role} userName={user.name} />
      </div>

      {/* Mobile Drawer */}
      {sidebarOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div
            className="fixed inset-0 bg-black/70 backdrop-blur-sm"
            onClick={() => setSidebarOpen(false)}
          />
          <div className="fixed inset-y-0 left-0 w-64 z-50">
            <AdminSidebar userRole={user.role} userName={user.name} />
          </div>
        </div>
      )}

      {/* Main View Area */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Top Operational Bar */}
        <header className="h-16 bg-surface-card border-b border-surface-border px-4 sm:px-8 flex items-center justify-between sticky top-0 z-30">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setSidebarOpen(true)}
              className="lg:hidden p-2 rounded-lg text-gray-400 hover:text-white hover:bg-surface"
            >
              <Menu className="w-5 h-5" />
            </button>
            <span className="text-xs font-serif font-bold text-white uppercase tracking-wider hidden sm:inline">
              L'Étoile Operations Deck
            </span>
          </div>

          <div className="flex items-center gap-4">
            {/* Live SSE status indicator */}
            <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-surface border border-surface-border text-[11px] font-mono">
              {isConnected ? (
                <>
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                  <span className="text-emerald-400 hidden sm:inline">Realtime Feed Active</span>
                </>
              ) : (
                <>
                  <span className="w-2 h-2 rounded-full bg-rose-500" />
                  <span className="text-gray-400 hidden sm:inline">Connecting Stream...</span>
                </>
              )}
            </div>

            <div className="text-right">
              <span className="text-xs font-semibold text-white block leading-none">{user.name}</span>
              <span className="text-[10px] text-gold font-mono uppercase">{user.role}</span>
            </div>
          </div>
        </header>

        {/* Inner Content */}
        <main className="flex-1 p-4 sm:p-8 overflow-y-auto">
          {children}
        </main>
      </div>
    </div>
  );
}

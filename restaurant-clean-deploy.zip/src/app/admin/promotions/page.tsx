'use client';

import React, { useState, useEffect } from 'react';
import { useToast } from '@/context/ToastContext';
import { Sparkles, Plus, Trash2, Edit3, X, Calendar, Eye, EyeOff } from 'lucide-react';

export default function AdminPromotionsPage() {
  const { showToast } = useToast();
  const [promotions, setPromotions] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const [modalOpen, setModalOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [targetPage, setTargetPage] = useState('ALL');
  const [buttonText, setButtonText] = useState('Explore');
  const [buttonUrl, setButtonUrl] = useState('/reservation');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [saving, setSaving] = useState(false);

  const fetchPromos = async () => {
    try {
      const res = await fetch('/api/promotions');
      const data = await res.json();
      if (data.promotions) setPromotions(data.promotions);
    } catch {
      showToast('Failed to fetch promotions', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchPromos();
  }, []);

  const openAdd = () => {
    setEditingId(null);
    setTitle('');
    setDescription('');
    setImageUrl('');
    setTargetPage('ALL');
    setButtonText('Reserve Experience');
    setButtonUrl('/reservation');
    setStartDate('');
    setEndDate('');
    setModalOpen(true);
  };

  const handleToggleActive = async (promo: any) => {
    try {
      const res = await fetch(`/api/promotions/${promo.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isActive: !promo.isActive }),
      });
      if (res.ok) {
        showToast('Promotion status updated', 'success');
        fetchPromos();
      }
    } catch {
      showToast('Failed to toggle promotion', 'error');
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you wish to delete this promotion?')) return;
    try {
      const res = await fetch(`/api/promotions/${id}`, { method: 'DELETE' });
      if (res.ok) {
        showToast('Promotion deleted', 'info');
        fetchPromos();
      }
    } catch {
      showToast('Failed to delete', 'error');
    }
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);

    try {
      const res = await fetch('/api/promotions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title,
          description,
          imageUrl,
          targetPage,
          buttonText,
          buttonUrl,
          startDate,
          endDate,
        }),
      });

      if (res.ok) {
        showToast('Promotion published!', 'success');
        setModalOpen(false);
        fetchPromos();
      } else {
        showToast('Failed to save promotion', 'error');
      }
    } catch {
      showToast('Network error', 'error');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-serif font-bold text-white">
            Promotions & Banners
          </h1>
          <p className="text-xs text-gray-400">
            Publish seasonal campaigns, tasting event banners, and scheduled dining offers.
          </p>
        </div>

        <button
          onClick={openAdd}
          className="px-4 py-2.5 rounded-xl bg-gold hover:bg-gold-hover text-background font-bold text-xs uppercase tracking-wider transition-all shadow-md flex items-center gap-2"
        >
          <Plus className="w-4 h-4" />
          <span>New Promotion</span>
        </button>
      </div>

      {loading ? (
        <div className="py-24 text-center text-xs text-gray-400 flex items-center justify-center gap-2">
          <span className="w-4 h-4 border-2 border-gold border-t-transparent rounded-full animate-spin" />
          Loading promotions...
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {promotions.map((promo) => (
            <div
              key={promo.id}
              className="bg-surface-card rounded-2xl border border-surface-border p-5 flex flex-col justify-between space-y-4 shadow-xl"
            >
              <div className="flex gap-4">
                {promo.imageUrl && (
                  <img
                    src={promo.imageUrl}
                    alt={promo.title}
                    className="w-24 h-24 rounded-xl object-cover bg-surface shrink-0"
                  />
                )}
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-surface border border-surface-border text-gold">
                      {promo.targetPage} Page
                    </span>
                    <span
                      className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded ${
                        promo.isActive
                          ? 'bg-emerald-950/60 border border-emerald-800 text-emerald-300'
                          : 'bg-gray-800 text-gray-400'
                      }`}
                    >
                      {promo.isActive ? 'Active' : 'Inactive'}
                    </span>
                  </div>
                  <h3 className="text-sm font-serif font-bold text-white truncate">
                    {promo.title}
                  </h3>
                  <p className="text-xs text-gray-400 mt-1 line-clamp-2">
                    {promo.description}
                  </p>
                </div>
              </div>

              <div className="pt-3 border-t border-surface-border flex items-center justify-between text-xs">
                <span className="text-[11px] text-gray-400">
                  CTA: <strong className="text-white">{promo.buttonText}</strong> ({promo.buttonUrl})
                </span>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleToggleActive(promo)}
                    className="p-1.5 rounded-lg border border-surface-border hover:bg-surface-hover text-gray-400 hover:text-white"
                    title={promo.isActive ? 'Deactivate' : 'Activate'}
                  >
                    {promo.isActive ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
                  </button>
                  <button
                    onClick={() => handleDelete(promo.id)}
                    className="p-1.5 rounded-lg border border-surface-border hover:bg-rose-950/40 text-gray-400 hover:text-rose-400"
                    title="Delete"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Add Modal */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in">
          <div className="bg-surface-card border border-surface-border rounded-2xl max-w-lg w-full p-6 shadow-2xl relative">
            <button
              onClick={() => setModalOpen(false)}
              className="absolute top-4 right-4 text-gray-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>

            <h3 className="text-lg font-serif font-bold text-white mb-4">
              Publish Seasonal Promotion
            </h3>

            <form onSubmit={handleSave} className="space-y-4 text-xs">
              <div>
                <label className="text-gray-400 block mb-1">Campaign Title *</label>
                <input
                  type="text"
                  placeholder="e.g. Autumn White Truffle Degustation"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full bg-surface border border-surface-border rounded-xl p-2.5 text-white"
                  required
                />
              </div>

              <div>
                <label className="text-gray-400 block mb-1">Description *</label>
                <textarea
                  rows={2}
                  placeholder="Details of the experience or discount..."
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full bg-surface border border-surface-border rounded-xl p-2.5 text-white resize-none"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-gray-400 block mb-1">Banner Image URL</label>
                  <input
                    type="url"
                    placeholder="https://images.unsplash.com/..."
                    value={imageUrl}
                    onChange={(e) => setImageUrl(e.target.value)}
                    className="w-full bg-surface border border-surface-border rounded-xl p-2.5 text-white"
                  />
                </div>
                <div>
                  <label className="text-gray-400 block mb-1">Display Placement</label>
                  <select
                    value={targetPage}
                    onChange={(e) => setTargetPage(e.target.value)}
                    className="w-full bg-surface border border-surface-border rounded-xl p-2.5 text-white"
                  >
                    <option value="ALL">All Pages</option>
                    <option value="HOME">Homepage Only</option>
                    <option value="MENU">Menu Page Only</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-gray-400 block mb-1">Button Text</label>
                  <input
                    type="text"
                    placeholder="Reserve Experience"
                    value={buttonText}
                    onChange={(e) => setButtonText(e.target.value)}
                    className="w-full bg-surface border border-surface-border rounded-xl p-2.5 text-white"
                  />
                </div>
                <div>
                  <label className="text-gray-400 block mb-1">Button Target Link</label>
                  <input
                    type="text"
                    placeholder="/reservation"
                    value={buttonUrl}
                    onChange={(e) => setButtonUrl(e.target.value)}
                    className="w-full bg-surface border border-surface-border rounded-xl p-2.5 text-white"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={saving}
                className="w-full py-3 rounded-xl bg-gold hover:bg-gold-hover text-background font-bold text-xs uppercase tracking-wider transition-all shadow-md mt-2"
              >
                {saving ? 'Publishing...' : 'Launch Promotion'}
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

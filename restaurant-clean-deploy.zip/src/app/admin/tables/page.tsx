'use client';

import React, { useState, useEffect } from 'react';
import { useToast } from '@/context/ToastContext';
import { 
  Grid, 
  Plus, 
  QrCode, 
  Trash2, 
  RotateCw, 
  Printer, 
  Edit3, 
  X,
  ExternalLink,
  Users
} from 'lucide-react';

export default function AdminTablesPage() {
  const { showToast } = useToast();
  const [tables, setTables] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  // QR Preview Modal
  const [selectedQR, setSelectedQR] = useState<any | null>(null);
  const [qrLoading, setQrLoading] = useState(false);

  // New Table Modal
  const [newModalOpen, setNewModalOpen] = useState(false);
  const [newNumber, setNewNumber] = useState('');
  const [newName, setNewName] = useState('');
  const [newCapacity, setNewCapacity] = useState(4);
  const [newSection, setNewSection] = useState('Indoor Main');
  const [creating, setCreating] = useState(false);

  const fetchTables = async () => {
    try {
      const res = await fetch('/api/tables');
      const data = await res.json();
      if (data.tables) setTables(data.tables);
    } catch {
      showToast('Failed to fetch tables', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTables();
  }, []);

  const handleOpenQR = async (table: any) => {
    setQrLoading(true);
    try {
      const res = await fetch(`/api/tables/${table.id}/qr`);
      const data = await res.json();
      setSelectedQR(data);
    } catch {
      showToast('Failed to generate table QR', 'error');
    } finally {
      setQrLoading(false);
    }
  };

  const handleRegenerateQR = async (tableId: string) => {
    if (!confirm('Regenerating this QR token will invalidate old printed QR cards for this table. Continue?')) return;
    try {
      const res = await fetch(`/api/tables/${tableId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ regenerateQR: true }),
      });
      if (res.ok) {
        showToast('New QR token generated', 'success');
        fetchTables();
        setSelectedQR(null);
      }
    } catch {
      showToast('Failed to regenerate token', 'error');
    }
  };

  const handleDeleteTable = async (tableId: string) => {
    if (!confirm('Are you sure you wish to delete this table?')) return;
    try {
      const res = await fetch(`/api/tables/${tableId}`, { method: 'DELETE' });
      if (res.ok) {
        showToast('Table deleted', 'info');
        setTables((prev) => prev.filter((t) => t.id !== tableId));
      }
    } catch {
      showToast('Failed to delete table', 'error');
    }
  };

  const handleCreateTable = async (e: React.FormEvent) => {
    e.preventDefault();
    setCreating(true);
    try {
      const res = await fetch('/api/tables', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          tableNumber: newNumber,
          name: newName,
          capacity: newCapacity,
          section: newSection,
        }),
      });
      const data = await res.json();
      if (res.ok) {
        showToast(`Table #${data.table.tableNumber} added!`, 'success');
        setNewModalOpen(false);
        fetchTables();
        setNewNumber('');
        setNewName('');
      } else {
        showToast(data.error || 'Failed to create table', 'error');
      }
    } catch {
      showToast('Network error', 'error');
    } finally {
      setCreating(false);
    }
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Title */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-serif font-bold text-white">
            Table Floor Plan & QR Management
          </h1>
          <p className="text-xs text-gray-400">
            Generate printable QR tent cards, assign sections, and manage table capacities.
          </p>
        </div>

        <button
          onClick={() => setNewModalOpen(true)}
          className="px-4 py-2.5 rounded-xl bg-gold hover:bg-gold-hover text-background font-bold text-xs uppercase tracking-wider transition-all shadow-md flex items-center gap-2"
        >
          <Plus className="w-4 h-4" />
          <span>Add New Table</span>
        </button>
      </div>

      {/* Tables Grid */}
      {loading ? (
        <div className="py-24 text-center text-xs text-gray-400 flex items-center justify-center gap-2">
          <span className="w-4 h-4 border-2 border-gold border-t-transparent rounded-full animate-spin" />
          Loading table inventory...
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {tables.map((table) => (
            <div
              key={table.id}
              className="bg-surface-card rounded-2xl border border-surface-border p-5 flex flex-col justify-between space-y-4 hover:border-gold/40 transition-all shadow-xl"
            >
              <div className="flex justify-between items-start">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-xl bg-gold/15 border border-gold/40 flex items-center justify-center text-gold font-serif font-bold text-xl">
                    {table.tableNumber}
                  </div>
                  <div>
                    <h3 className="text-sm font-serif font-bold text-white">
                      {table.name}
                    </h3>
                    <span className="text-[11px] text-gray-400 block">
                      {table.section}
                    </span>
                  </div>
                </div>

                <span className="px-2.5 py-1 rounded-full bg-surface border border-surface-border text-[10px] font-mono text-gray-300 flex items-center gap-1">
                  <Users className="w-3 h-3 text-gold" /> {table.capacity} Guests
                </span>
              </div>

              {/* Status and QR link info */}
              <div className="p-3 bg-surface rounded-xl border border-surface-border flex items-center justify-between text-xs">
                <div>
                  <span className="text-[10px] text-gray-500 uppercase tracking-wider block">
                    Current Status
                  </span>
                  <span
                    className={`font-semibold text-[11px] ${
                      table.status === 'AVAILABLE'
                        ? 'text-emerald-400'
                        : table.status === 'OCCUPIED'
                        ? 'text-rose-400'
                        : 'text-amber-400'
                    }`}
                  >
                    {table.status}
                  </span>
                </div>

                <div className="text-right">
                  <span className="text-[10px] text-gray-500 uppercase tracking-wider block">
                    Secure QR Token
                  </span>
                  <span className="font-mono text-[10px] text-gray-400 truncate max-w-[120px] block">
                    {table.qrToken}
                  </span>
                </div>
              </div>

              {/* Bottom Actions */}
              <div className="pt-2 border-t border-surface-border flex items-center justify-between gap-2">
                <button
                  onClick={() => handleOpenQR(table)}
                  className="flex-1 py-2 px-3 rounded-xl bg-surface hover:bg-gold hover:text-background border border-surface-border hover:border-gold text-xs font-semibold text-gray-200 transition-all flex items-center justify-center gap-2"
                >
                  <QrCode className="w-3.5 h-3.5 text-gold" />
                  <span>View QR Card</span>
                </button>

                <button
                  onClick={() => handleRegenerateQR(table.id)}
                  className="p-2 rounded-xl border border-surface-border hover:bg-surface-hover text-gray-400 hover:text-white transition-colors"
                  title="Regenerate QR Token"
                >
                  <RotateCw className="w-4 h-4" />
                </button>

                <button
                  onClick={() => handleDeleteTable(table.id)}
                  className="p-2 rounded-xl border border-surface-border hover:bg-rose-950/40 text-gray-400 hover:text-rose-400 transition-colors"
                  title="Delete Table"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Printable QR Code Modal */}
      {selectedQR && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-in fade-in">
          <div className="bg-surface-card border border-surface-border rounded-3xl max-w-sm w-full p-6 shadow-2xl relative text-center space-y-4">
            <button
              onClick={() => setSelectedQR(null)}
              className="absolute top-4 right-4 text-gray-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Printable Tent Card Area */}
            <div id="printable-qr-card" className="bg-white text-black p-6 rounded-2xl shadow-inner space-y-3">
              <div className="border-b border-gray-200 pb-2">
                <h3 className="font-serif font-bold text-xl tracking-widest text-gray-900">
                  L'ÉTOILE
                </h3>
                <p className="text-[9px] uppercase tracking-widest text-gray-500 font-semibold">
                  Modern Brasserie • Table {selectedQR.tableNumber}
                </p>
              </div>

              {/* QR Image */}
              <div className="py-2 flex justify-center">
                <img
                  src={selectedQR.dataUrl}
                  alt={`QR Code for Table ${selectedQR.tableNumber}`}
                  className="w-48 h-48 mx-auto"
                />
              </div>

              <div className="border-t border-gray-200 pt-2 text-[10px] text-gray-600 space-y-0.5">
                <p className="font-bold text-gray-900">Scan with camera to browse menu & order</p>
                <p className="font-mono text-[9px] text-gray-400">{selectedQR.targetUrl}</p>
              </div>
            </div>

            {/* Actions */}
            <div className="flex gap-2">
              <button
                onClick={() => window.print()}
                className="flex-1 py-2.5 rounded-xl bg-gold hover:bg-gold-hover text-background font-bold text-xs uppercase tracking-wider transition-all flex items-center justify-center gap-2"
              >
                <Printer className="w-4 h-4" />
                <span>Print Table Card</span>
              </button>

              <a
                href={selectedQR.targetUrl}
                target="_blank"
                rel="noreferrer"
                className="p-2.5 rounded-xl border border-surface-border hover:bg-surface-hover text-gray-300 hover:text-white"
                title="Test Scan in Browser"
              >
                <ExternalLink className="w-4 h-4" />
              </a>
            </div>
          </div>
        </div>
      )}

      {/* Add Table Modal */}
      {newModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in">
          <div className="bg-surface-card border border-surface-border rounded-2xl max-w-md w-full p-6 shadow-2xl relative">
            <button
              onClick={() => setNewModalOpen(false)}
              className="absolute top-4 right-4 text-gray-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>

            <h3 className="text-lg font-serif font-bold text-white mb-4">
              Add New Restaurant Table
            </h3>

            <form onSubmit={handleCreateTable} className="space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-gray-400 block mb-1">Table Number *</label>
                  <input
                    type="number"
                    min={1}
                    placeholder="15"
                    value={newNumber}
                    onChange={(e) => setNewNumber(e.target.value)}
                    className="w-full bg-surface border border-surface-border rounded-xl p-2.5 text-white"
                    required
                  />
                </div>
                <div>
                  <label className="text-gray-400 block mb-1">Guest Capacity</label>
                  <input
                    type="number"
                    min={1}
                    max={24}
                    value={newCapacity}
                    onChange={(e) => setNewCapacity(parseInt(e.target.value, 10))}
                    className="w-full bg-surface border border-surface-border rounded-xl p-2.5 text-white"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="text-gray-400 block mb-1">Table Name / Description</label>
                <input
                  type="text"
                  placeholder="e.g. Table 15 (Garden Gazebo)"
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  className="w-full bg-surface border border-surface-border rounded-xl p-2.5 text-white"
                  required
                />
              </div>

              <div>
                <label className="text-gray-400 block mb-1">Dining Section</label>
                <select
                  value={newSection}
                  onChange={(e) => setNewSection(e.target.value)}
                  className="w-full bg-surface border border-surface-border rounded-xl p-2.5 text-white"
                >
                  <option value="Indoor Main">Indoor Main Dining Room</option>
                  <option value="Sunset Terrace">Sunset Terrace</option>
                  <option value="Garden Patio">Garden Patio</option>
                  <option value="Private VIP Lounge">Private VIP Lounge</option>
                  <option value="Artisan Bar">Artisan Bar</option>
                </select>
              </div>

              <button
                type="submit"
                disabled={creating}
                className="w-full py-3 rounded-xl bg-gold hover:bg-gold-hover text-background font-bold text-xs uppercase tracking-wider transition-all shadow-md flex items-center justify-center gap-2 mt-2"
              >
                {creating ? 'Adding Table...' : 'Save & Generate QR'}
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

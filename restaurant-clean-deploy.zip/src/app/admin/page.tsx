'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { useToast } from '@/context/ToastContext';
import { 
  Calendar, 
  ChefHat, 
  DollarSign, 
  Users, 
  Bell, 
  Grid, 
  CheckCircle2, 
  Clock, 
  ArrowRight,
  TrendingUp,
  AlertTriangle
} from 'lucide-react';

export default function AdminOverviewPage() {
  const { showToast } = useToast();
  const [metrics, setMetrics] = useState<any>(null);
  const [tables, setTables] = useState<any[]>([]);
  const [waiterCalls, setWaiterCalls] = useState<any[]>([]);
  const [recentOrders, setRecentOrders] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const loadData = async () => {
    try {
      const [analyticsRes, tablesRes, waiterRes, ordersRes] = await Promise.all([
        fetch('/api/analytics').then((r) => r.json()),
        fetch('/api/tables').then((r) => r.json()),
        fetch('/api/waiter-calls').then((r) => r.json()),
        fetch('/api/orders?status=NEW').then((r) => r.json()),
      ]);

      if (analyticsRes.metrics) setMetrics(analyticsRes.metrics);
      if (tablesRes.tables) setTables(tablesRes.tables);
      if (waiterRes.activeCalls) setWaiterCalls(waiterRes.activeCalls);
      if (ordersRes.orders) setRecentOrders(ordersRes.orders.slice(0, 5));
    } catch {
      showToast('Error refreshing operational data', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();

    // Listen to real-time events to refresh KPIs
    const eventSource = new EventSource('/api/realtime');
    eventSource.onmessage = () => {
      loadData();
    };

    return () => eventSource.close();
  }, []);

  const handleResolveWaiter = async (requestId: string) => {
    try {
      const res = await fetch('/api/waiter-calls', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ requestId, status: 'COMPLETED' }),
      });
      if (res.ok) {
        showToast('Waiter call marked resolved', 'success');
        setWaiterCalls((prev) => prev.filter((c) => c.id !== requestId));
      }
    } catch {
      showToast('Failed to resolve call', 'error');
    }
  };

  const handleQuickTableStatus = async (tableId: string, newStatus: string) => {
    try {
      const res = await fetch(`/api/tables/${tableId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: newStatus }),
      });
      if (res.ok) {
        setTables((prev) =>
          prev.map((t) => (t.id === tableId ? { ...t, status: newStatus } : t))
        );
        showToast(`Table status updated to ${newStatus}`, 'success');
      }
    } catch {
      showToast('Failed to update table status', 'error');
    }
  };

  if (loading) {
    return (
      <div className="py-24 text-center text-xs text-gray-400 flex items-center justify-center gap-2">
        <span className="w-4 h-4 border-2 border-gold border-t-transparent rounded-full animate-spin" />
        Synchronizing operations feed...
      </div>
    );
  }

  return (
    <div className="space-y-8 max-w-7xl mx-auto">
      {/* Title */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-serif font-bold text-white">
            Daily Operations Center
          </h1>
          <p className="text-xs text-gray-400">
            Real-time floor status, active culinary orders, and table availability.
          </p>
        </div>

        <div className="flex gap-3">
          <Link
            href="/admin/orders"
            className="px-4 py-2 rounded-xl bg-gold hover:bg-gold-hover text-background font-bold text-xs uppercase tracking-wider transition-all shadow-md flex items-center gap-2"
          >
            <ChefHat className="w-4 h-4" />
            <span>Kitchen View</span>
          </Link>
          <Link
            href="/admin/reservations"
            className="px-4 py-2 rounded-xl bg-surface border border-surface-border hover:border-gold/50 text-white font-semibold text-xs uppercase tracking-wider transition-all flex items-center gap-2"
          >
            <Calendar className="w-4 h-4 text-gold" />
            <span>Reservations</span>
          </Link>
        </div>
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
        {/* Today's Reservations */}
        <div className="bg-surface-card p-5 rounded-2xl border border-surface-border flex items-center justify-between">
          <div>
            <span className="text-[10px] font-semibold uppercase tracking-wider text-gray-400 block">
              Today's Bookings
            </span>
            <span className="text-2xl sm:text-3xl font-serif font-bold text-white mt-1 block">
              {metrics?.todayReservations || 0}
            </span>
            <span className="text-[10px] text-emerald-400 flex items-center gap-1 mt-1 font-medium">
              <TrendingUp className="w-3 h-3" /> Guaranteed Covers
            </span>
          </div>
          <div className="w-12 h-12 rounded-xl bg-gold/15 border border-gold/30 flex items-center justify-center text-gold">
            <Calendar className="w-6 h-6" />
          </div>
        </div>

        {/* Active Orders */}
        <div className="bg-surface-card p-5 rounded-2xl border border-surface-border flex items-center justify-between">
          <div>
            <span className="text-[10px] font-semibold uppercase tracking-wider text-gray-400 block">
              Kitchen Tickets
            </span>
            <span className="text-2xl sm:text-3xl font-serif font-bold text-white mt-1 block">
              {metrics?.activeOrders || 0}
            </span>
            <span className="text-[10px] text-amber-400 font-medium mt-1 block">
              In preparation / ready
            </span>
          </div>
          <div className="w-12 h-12 rounded-xl bg-amber-950/40 border border-amber-800/40 flex items-center justify-center text-amber-400">
            <ChefHat className="w-6 h-6" />
          </div>
        </div>

        {/* Table Occupancy */}
        <div className="bg-surface-card p-5 rounded-2xl border border-surface-border flex items-center justify-between">
          <div>
            <span className="text-[10px] font-semibold uppercase tracking-wider text-gray-400 block">
              Occupied Tables
            </span>
            <span className="text-2xl sm:text-3xl font-serif font-bold text-white mt-1 block">
              {metrics?.tableStats?.occupied || 0}{' '}
              <span className="text-sm font-normal text-gray-500">
                / {metrics?.tableStats?.total || 12}
              </span>
            </span>
            <span className="text-[10px] text-gray-400 mt-1 block">
              {metrics?.tableStats?.available || 0} Available for seating
            </span>
          </div>
          <div className="w-12 h-12 rounded-xl bg-surface border border-surface-border flex items-center justify-center text-gold">
            <Grid className="w-6 h-6" />
          </div>
        </div>

        {/* Pending Waiter Calls */}
        <div className="bg-surface-card p-5 rounded-2xl border border-surface-border flex items-center justify-between">
          <div>
            <span className="text-[10px] font-semibold uppercase tracking-wider text-gray-400 block">
              Waiter Calls
            </span>
            <span className={`text-2xl sm:text-3xl font-serif font-bold mt-1 block ${
              waiterCalls.length > 0 ? 'text-rose-400 animate-pulse' : 'text-white'
            }`}>
              {waiterCalls.length}
            </span>
            <span className="text-[10px] text-gray-400 mt-1 block">
              {waiterCalls.length === 0 ? 'No active floor alerts' : 'Requires immediate staff attention'}
            </span>
          </div>
          <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
            waiterCalls.length > 0
              ? 'bg-rose-950/60 border border-rose-700 text-rose-400'
              : 'bg-surface border border-surface-border text-gray-500'
          }`}>
            <Bell className="w-6 h-6" />
          </div>
        </div>
      </div>

      {/* Urgent Pending Waiter Alerts Banner */}
      {waiterCalls.length > 0 && (
        <div className="bg-rose-950/40 border border-rose-800/60 rounded-2xl p-5 space-y-3">
          <div className="flex items-center gap-2 text-rose-400 font-serif font-bold text-sm">
            <Bell className="w-5 h-5 animate-bounce" />
            <span>Active Staff Summons ({waiterCalls.length})</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
            {waiterCalls.map((call) => (
              <div
                key={call.id}
                className="bg-surface p-3.5 rounded-xl border border-surface-border flex items-center justify-between gap-3"
              >
                <div>
                  <h4 className="text-sm font-bold text-white">
                    Table #{call.table.tableNumber} • {call.table.name}
                  </h4>
                  <p className="text-[10px] text-gold font-mono">
                    {call.table.section}
                  </p>
                </div>
                <button
                  onClick={() => handleResolveWaiter(call.id)}
                  className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shrink-0"
                >
                  Attend
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Floor Plan & Table Matrix */}
      <div className="bg-surface-card rounded-3xl border border-surface-border p-6 space-y-4">
        <div className="flex items-center justify-between border-b border-surface-border pb-4">
          <div>
            <h2 className="text-lg font-serif font-bold text-white">
              Live Floor Plan Matrix
            </h2>
            <p className="text-xs text-gray-400">
              Click any table to quickly toggle its operational status.
            </p>
          </div>
          <Link
            href="/admin/tables"
            className="text-xs font-semibold text-gold hover:underline flex items-center gap-1"
          >
            <span>Manage All Tables & QR Codes</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3">
          {tables.map((table) => {
            const isOccupied = table.status === 'OCCUPIED';
            const isReserved = table.status === 'RESERVED';
            const isCleaning = table.status === 'CLEANING';
            const isAvailable = table.status === 'AVAILABLE';

            return (
              <div
                key={table.id}
                className={`p-3.5 rounded-2xl border transition-all flex flex-col justify-between space-y-2 ${
                  isOccupied
                    ? 'bg-rose-950/30 border-rose-800/50 text-rose-200'
                    : isReserved
                    ? 'bg-amber-950/30 border-amber-800/50 text-amber-200'
                    : isCleaning
                    ? 'bg-blue-950/30 border-blue-800/50 text-blue-200'
                    : 'bg-surface border-surface-border text-gray-300 hover:border-gold/40'
                }`}
              >
                <div className="flex justify-between items-start">
                  <span className="font-serif font-bold text-base text-white">
                    T-{table.tableNumber}
                  </span>
                  <span className="text-[10px] font-mono font-medium px-1.5 py-0.5 rounded bg-surface-card border border-surface-border text-gray-300">
                    {table.capacity}p
                  </span>
                </div>

                <div className="min-w-0">
                  <p className="text-[11px] font-medium text-white truncate">{table.name}</p>
                  <p className="text-[9px] text-gray-400 truncate">{table.section}</p>
                </div>

                {/* Status Toggle buttons */}
                <div className="pt-2 border-t border-surface-border/50 flex flex-wrap gap-1">
                  <select
                    value={table.status}
                    onChange={(e) => handleQuickTableStatus(table.id, e.target.value)}
                    className="w-full bg-surface-card border border-surface-border rounded-lg text-[10px] font-semibold text-white px-2 py-1 focus:outline-none focus:border-gold"
                  >
                    <option value="AVAILABLE">Available</option>
                    <option value="OCCUPIED">Occupied</option>
                    <option value="RESERVED">Reserved</option>
                    <option value="CLEANING">Cleaning</option>
                    <option value="DISABLED">Disabled</option>
                  </select>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Incoming Tickets Feed */}
      <div className="bg-surface-card rounded-3xl border border-surface-border p-6 space-y-4">
        <div className="flex items-center justify-between border-b border-surface-border pb-4">
          <div>
            <h2 className="text-lg font-serif font-bold text-white">
              Incoming Kitchen Tickets
            </h2>
            <p className="text-xs text-gray-400">
              Orders requiring kitchen brigade acceptance.
            </p>
          </div>
          <Link
            href="/admin/orders"
            className="text-xs font-semibold text-gold hover:underline flex items-center gap-1"
          >
            <span>Open Kitchen Display System (KDS)</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>

        {recentOrders.length === 0 ? (
          <div className="text-center py-8 text-xs text-gray-500">
            No new pending tickets. Kitchen queue is clear.
          </div>
        ) : (
          <div className="divide-y divide-surface-border">
            {recentOrders.map((order) => (
              <div key={order.id} className="py-3 flex items-center justify-between gap-4 text-xs">
                <div className="flex items-center gap-3">
                  <span className="font-mono text-gold font-bold">
                    {order.orderNumber}
                  </span>
                  <span className="font-medium text-white">
                    Table #{order.table.tableNumber}
                  </span>
                  <span className="text-gray-400">
                    ({order.items.length} items • ${order.totalAmount.toFixed(2)})
                  </span>
                </div>
                <Link
                  href="/admin/orders"
                  className="px-3 py-1 rounded-lg bg-gold text-background font-bold text-[11px] uppercase tracking-wider"
                >
                  Manage
                </Link>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

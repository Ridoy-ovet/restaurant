'use client';

import React, { useState, useEffect } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { Navbar } from '@/components/Navbar';
import { Footer } from '@/components/Footer';
import { useToast } from '@/context/ToastContext';
import { 
  CheckCircle2, 
  Calendar, 
  Clock, 
  Users, 
  MapPin, 
  AlertCircle, 
  XCircle, 
  Edit3, 
  ArrowLeft,
  Mail
} from 'lucide-react';
import Link from 'next/link';

export default function ReservationDetailsPage() {
  const params = useParams();
  const router = useRouter();
  const { showToast } = useToast();
  const code = params.code as string;

  const [reservation, setReservation] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Edit states
  const [isEditing, setIsEditing] = useState(false);
  const [newRequests, setNewRequests] = useState('');
  const [isSaving, setIsSaving] = useState(false);
  const [isCancelling, setIsCancelling] = useState(false);

  useEffect(() => {
    if (!code) return;
    fetch(`/api/reservations/${code}`)
      .then((res) => res.json())
      .then((data) => {
        if (data.reservation) {
          setReservation(data.reservation);
          setNewRequests(data.reservation.specialRequests || '');
        } else {
          setError(data.error || 'Reservation not found');
        }
      })
      .catch(() => setError('Failed to load reservation'))
      .finally(() => setLoading(false));
  }, [code]);

  const handleUpdateRequests = async () => {
    setIsSaving(true);
    try {
      const res = await fetch(`/api/reservations/${code}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ specialRequests: newRequests }),
      });
      const data = await res.json();
      if (res.ok) {
        setReservation(data.reservation);
        setIsEditing(false);
        showToast('Special requests updated successfully', 'success');
      } else {
        showToast(data.error || 'Failed to update', 'error');
      }
    } catch {
      showToast('Network error', 'error');
    } finally {
      setIsSaving(false);
    }
  };

  const handleCancelBooking = async () => {
    if (!confirm('Are you sure you wish to cancel this reservation?')) return;

    setIsCancelling(true);
    try {
      const res = await fetch(`/api/reservations/${code}`, {
        method: 'DELETE',
      });
      if (res.ok) {
        setReservation((prev: any) => ({ ...prev, status: 'CANCELLED' }));
        showToast('Reservation has been cancelled', 'info');
      } else {
        showToast('Failed to cancel reservation', 'error');
      }
    } catch {
      showToast('Network error', 'error');
    } finally {
      setIsCancelling(false);
    }
  };

  return (
    <>
      <Navbar />

      <main className="flex-1 py-16 px-4 sm:px-6 lg:px-8 max-w-3xl mx-auto">
        {loading ? (
          <div className="py-24 text-center text-xs text-gray-400 flex items-center justify-center gap-2">
            <span className="w-4 h-4 border-2 border-gold border-t-transparent rounded-full animate-spin" />
            Loading booking pass...
          </div>
        ) : error || !reservation ? (
          <div className="bg-surface-card p-8 rounded-3xl border border-surface-border text-center space-y-4">
            <AlertCircle className="w-12 h-12 text-rose-400 mx-auto" />
            <h2 className="text-xl font-serif font-bold text-white">Booking Not Found</h2>
            <p className="text-xs text-gray-400 max-w-sm mx-auto">
              We could not locate a reservation matching reference <code className="text-gold font-mono">{code}</code>.
            </p>
            <Link
              href="/reservation"
              className="inline-block mt-4 px-6 py-2.5 rounded-full bg-gold text-background font-bold text-xs uppercase tracking-wider"
            >
              Book New Table
            </Link>
          </div>
        ) : (
          <div className="space-y-6">
            <Link
              href="/reservation"
              className="inline-flex items-center gap-2 text-xs text-gray-400 hover:text-white transition-colors"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Back to Reservations</span>
            </Link>

            {/* Confirmation Hero Card */}
            <div className="bg-surface-card rounded-3xl border border-surface-border p-6 sm:p-10 shadow-2xl space-y-6">
              {/* Status Header */}
              <div className="text-center pb-6 border-b border-surface-border space-y-3">
                {reservation.status === 'CANCELLED' ? (
                  <div className="w-14 h-14 rounded-full bg-rose-950/50 border border-rose-700/50 flex items-center justify-center mx-auto text-rose-400">
                    <XCircle className="w-7 h-7" />
                  </div>
                ) : (
                  <div className="w-14 h-14 rounded-full bg-emerald-950/50 border border-emerald-700/50 flex items-center justify-center mx-auto text-emerald-400">
                    <CheckCircle2 className="w-7 h-7" />
                  </div>
                )}

                <div>
                  <h1 className="text-2xl sm:text-3xl font-serif font-bold text-white">
                    {reservation.status === 'CANCELLED'
                      ? 'Reservation Cancelled'
                      : 'Table Confirmed & Reserved'}
                  </h1>
                  <p className="text-xs text-gray-400 mt-1">
                    Booking Reference:{' '}
                    <span className="font-mono text-gold font-bold text-sm tracking-wider">
                      {reservation.reservationCode}
                    </span>
                  </p>
                </div>

                {reservation.status !== 'CANCELLED' && (
                  <div className="inline-flex items-center gap-2 bg-surface px-3 py-1 rounded-full border border-surface-border text-[11px] text-gray-300">
                    <Mail className="w-3.5 h-3.5 text-gold" />
                    <span>Confirmation dispatched to {reservation.guestEmail}</span>
                  </div>
                )}
              </div>

              {/* Itinerary Matrix */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 p-4 bg-surface rounded-2xl border border-surface-border">
                <div className="space-y-1">
                  <span className="text-[10px] uppercase tracking-wider text-gray-500 font-semibold block">
                    Date
                  </span>
                  <div className="flex items-center gap-1.5 text-xs sm:text-sm font-semibold text-white">
                    <Calendar className="w-3.5 h-3.5 text-gold shrink-0" />
                    <span>{reservation.date}</span>
                  </div>
                </div>

                <div className="space-y-1">
                  <span className="text-[10px] uppercase tracking-wider text-gray-500 font-semibold block">
                    Seating Time
                  </span>
                  <div className="flex items-center gap-1.5 text-xs sm:text-sm font-semibold text-white">
                    <Clock className="w-3.5 h-3.5 text-gold shrink-0" />
                    <span>{reservation.timeSlot}</span>
                  </div>
                </div>

                <div className="space-y-1">
                  <span className="text-[10px] uppercase tracking-wider text-gray-500 font-semibold block">
                    Party Size
                  </span>
                  <div className="flex items-center gap-1.5 text-xs sm:text-sm font-semibold text-white">
                    <Users className="w-3.5 h-3.5 text-gold shrink-0" />
                    <span>{reservation.partySize} Guests</span>
                  </div>
                </div>

                <div className="space-y-1">
                  <span className="text-[10px] uppercase tracking-wider text-gray-500 font-semibold block">
                    Assigned Area
                  </span>
                  <div className="flex items-center gap-1.5 text-xs sm:text-sm font-semibold text-white">
                    <MapPin className="w-3.5 h-3.5 text-gold shrink-0" />
                    <span>{reservation.table?.section || 'Indoor Main'}</span>
                  </div>
                </div>
              </div>

              {/* Guest Information */}
              <div className="space-y-3 text-xs">
                <h3 className="font-semibold uppercase tracking-wider text-gray-300">
                  Guest Information
                </h3>
                <div className="space-y-1.5 text-gray-300 bg-surface/50 p-4 rounded-xl border border-surface-border">
                  <div className="flex justify-between">
                    <span className="text-gray-500">Name:</span>
                    <span className="font-medium text-white">{reservation.guestName}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-500">Phone:</span>
                    <span className="font-medium text-white">{reservation.guestPhone}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-500">Table Number:</span>
                    <span className="font-medium text-gold font-mono">
                      Table #{reservation.table?.tableNumber || 'Assigned on arrival'}
                    </span>
                  </div>
                </div>
              </div>

              {/* Special Requests & Notes */}
              <div className="space-y-2 text-xs">
                <div className="flex justify-between items-center">
                  <h3 className="font-semibold uppercase tracking-wider text-gray-300">
                    Special Requests & Dietary
                  </h3>
                  {reservation.status !== 'CANCELLED' && !isEditing && (
                    <button
                      onClick={() => setIsEditing(true)}
                      className="text-gold hover:underline flex items-center gap-1 text-[11px]"
                    >
                      <Edit3 className="w-3 h-3" /> Edit Notes
                    </button>
                  )}
                </div>

                {isEditing ? (
                  <div className="space-y-2">
                    <textarea
                      rows={2}
                      value={newRequests}
                      onChange={(e) => setNewRequests(e.target.value)}
                      className="w-full bg-surface border border-surface-border rounded-xl p-3 text-xs text-white focus:outline-none focus:border-gold resize-none"
                    />
                    <div className="flex justify-end gap-2">
                      <button
                        onClick={() => setIsEditing(false)}
                        className="px-3 py-1.5 rounded-lg text-xs text-gray-400 hover:text-white"
                      >
                        Cancel
                      </button>
                      <button
                        onClick={handleUpdateRequests}
                        disabled={isSaving}
                        className="px-4 py-1.5 rounded-lg bg-gold text-background font-bold text-xs"
                      >
                        {isSaving ? 'Saving...' : 'Save Notes'}
                      </button>
                    </div>
                  </div>
                ) : (
                  <p className="p-3 bg-surface/40 rounded-xl border border-surface-border text-gray-300 italic">
                    {reservation.specialRequests || 'No special requests specified.'}
                  </p>
                )}
              </div>

              {/* Action Buttons */}
              {reservation.status !== 'CANCELLED' && (
                <div className="pt-4 border-t border-surface-border flex flex-col sm:flex-row justify-between items-center gap-3">
                  <p className="text-[11px] text-gray-400">
                    Running late? Please notify our concierge at{' '}
                    <span className="text-white font-medium">+1 (555) 843-9200</span>.
                  </p>
                  <button
                    onClick={handleCancelBooking}
                    disabled={isCancelling}
                    className="w-full sm:w-auto px-5 py-2.5 rounded-xl border border-rose-800/50 hover:bg-rose-950/40 text-rose-400 text-xs font-semibold uppercase tracking-wider transition-colors"
                  >
                    {isCancelling ? 'Cancelling...' : 'Cancel Reservation'}
                  </button>
                </div>
              )}
            </div>
          </div>
        )}
      </main>

      <Footer />
    </>
  );
}

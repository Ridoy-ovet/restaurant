'use client';

import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { Navbar } from '@/components/Navbar';
import { Footer } from '@/components/Footer';
import { useToast } from '@/context/ToastContext';
import { 
  Calendar as CalendarIcon, 
  Users, 
  Clock, 
  CheckCircle2, 
  Sparkles, 
  ShieldCheck, 
  ArrowRight,
  Info
} from 'lucide-react';

interface TimeSlot {
  time: string;
  available: boolean;
  remainingTables: number;
}

export default function ReservationPage() {
  const router = useRouter();
  const { showToast } = useToast();

  // Current date formatted as YYYY-MM-DD
  const todayStr = new Date().toISOString().split('T')[0];

  const [date, setDate] = useState(todayStr);
  const [partySize, setPartySize] = useState(2);
  const [slots, setSlots] = useState<TimeSlot[]>([]);
  const [selectedSlot, setSelectedSlot] = useState<string | null>(null);
  const [loadingSlots, setLoadingSlots] = useState(false);
  const [noSlotsReason, setNoSlotsReason] = useState<string | null>(null);

  // Guest details form
  const [guestName, setGuestName] = useState('');
  const [guestEmail, setGuestEmail] = useState('');
  const [guestPhone, setGuestPhone] = useState('');
  const [specialRequests, setSpecialRequests] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Auto-populate if user logged in
  useEffect(() => {
    fetch('/api/auth/me')
      .then((res) => res.json())
      .then((data) => {
        if (data?.user) {
          setGuestName(data.user.name || '');
          setGuestEmail(data.user.email || '');
          setGuestPhone(data.user.phone || '');
        }
      })
      .catch(() => {});
  }, []);

  // Fetch real-time available time slots whenever Date or Party Size changes
  useEffect(() => {
    if (!date) return;
    setLoadingSlots(true);
    setSelectedSlot(null);
    setNoSlotsReason(null);

    fetch(`/api/reservations/availability?date=${date}&partySize=${partySize}`)
      .then((res) => res.json())
      .then((data) => {
        if (data.slots) {
          setSlots(data.slots);
          if (data.slots.length === 0 && data.reason) {
            setNoSlotsReason(data.reason);
          }
        } else if (data.reason) {
          setSlots([]);
          setNoSlotsReason(data.reason);
        }
      })
      .catch(() => {
        showToast('Failed to check availability', 'error');
      })
      .finally(() => {
        setLoadingSlots(false);
      });
  }, [date, partySize]);

  const handleBookingSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!selectedSlot) {
      showToast('Please select an available seating time slot.', 'warning');
      return;
    }

    if (!guestName || !guestEmail || !guestPhone) {
      showToast('Please provide your name, email, and contact phone number.', 'warning');
      return;
    }

    setIsSubmitting(true);
    try {
      const res = await fetch('/api/reservations', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          date,
          timeSlot: selectedSlot,
          partySize,
          guestName,
          guestEmail,
          guestPhone,
          specialRequests,
        }),
      });

      const data = await res.json();

      if (!res.ok) {
        showToast(data.error || 'Failed to confirm reservation', 'error');
        return;
      }

      showToast('Table reservation successfully confirmed!', 'success');
      router.push(`/reservation/${data.reservation.reservationCode}`);
    } catch (err) {
      showToast('Network error while booking table.', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <>
      <Navbar />

      <main className="flex-1 py-16 px-4 sm:px-6 lg:px-8 max-w-5xl mx-auto">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <span className="text-xs uppercase tracking-widest text-gold font-semibold block mb-2">
            Online Table Bookings
          </span>
          <h1 className="text-3xl sm:text-5xl font-serif font-bold text-white tracking-tight">
            Reserve Your Table
          </h1>
          <p className="mt-3 text-xs sm:text-sm text-gray-400 font-light leading-relaxed">
            Real-time table availability with instant confirmation. Experience our wood-fired hearth and refined wine pairings.
          </p>
        </div>

        <div className="bg-surface-card rounded-3xl border border-surface-border p-6 sm:p-10 shadow-2xl">
          <form onSubmit={handleBookingSubmit} className="space-y-8">
            {/* Step 1: Date & Party Size */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Date Input */}
              <div className="space-y-2">
                <label className="text-xs font-semibold uppercase tracking-wider text-gray-300 flex items-center gap-2">
                  <CalendarIcon className="w-4 h-4 text-gold" />
                  Select Date
                </label>
                <input
                  type="date"
                  min={todayStr}
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="w-full bg-surface border border-surface-border rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-gold transition-colors"
                  required
                />
              </div>

              {/* Party Size Selector */}
              <div className="space-y-2">
                <label className="text-xs font-semibold uppercase tracking-wider text-gray-300 flex items-center gap-2">
                  <Users className="w-4 h-4 text-gold" />
                  Party Size
                </label>
                <select
                  value={partySize}
                  onChange={(e) => setPartySize(parseInt(e.target.value, 10))}
                  className="w-full bg-surface border border-surface-border rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-gold transition-colors"
                >
                  {[1, 2, 3, 4, 5, 6, 7, 8, 10, 12].map((num) => (
                    <option key={num} value={num}>
                      {num} {num === 1 ? 'Guest' : 'Guests'}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Step 2: Available Seating Slots */}
            <div className="space-y-3 pt-4 border-t border-surface-border">
              <div className="flex items-center justify-between">
                <label className="text-xs font-semibold uppercase tracking-wider text-gray-300 flex items-center gap-2">
                  <Clock className="w-4 h-4 text-gold" />
                  Available Seating Times
                </label>
                <span className="text-[11px] text-gray-400">
                  90-minute dining duration
                </span>
              </div>

              {loadingSlots ? (
                <div className="py-12 text-center text-xs text-gray-400 flex items-center justify-center gap-2">
                  <span className="w-4 h-4 border-2 border-gold border-t-transparent rounded-full animate-spin" />
                  Calculating live table availability...
                </div>
              ) : noSlotsReason ? (
                <div className="p-4 rounded-xl bg-amber-950/40 border border-amber-800/40 text-amber-300 text-xs flex items-center gap-2">
                  <Info className="w-4 h-4 shrink-0 text-amber-400" />
                  <span>{noSlotsReason}</span>
                </div>
              ) : slots.length === 0 ? (
                <div className="p-4 rounded-xl bg-surface text-center text-xs text-gray-400">
                  No tables available for this configuration. Please try an alternate date or party size.
                </div>
              ) : (
                <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-2.5">
                  {slots.map((slot) => (
                    <button
                      key={slot.time}
                      type="button"
                      disabled={!slot.available}
                      onClick={() => setSelectedSlot(slot.time)}
                      className={`py-3 px-2 rounded-xl text-xs font-semibold font-mono tracking-wide transition-all ${
                        selectedSlot === slot.time
                          ? 'bg-gold text-background shadow-lg shadow-gold/20 scale-105'
                          : slot.available
                          ? 'bg-surface hover:bg-surface-hover border border-surface-border hover:border-gold/50 text-white'
                          : 'bg-surface/40 border border-transparent text-gray-600 cursor-not-allowed line-through'
                      }`}
                    >
                      {slot.time}
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Step 3: Guest Contact & Details */}
            <div className="space-y-4 pt-4 border-t border-surface-border">
              <h3 className="text-xs font-semibold uppercase tracking-wider text-gray-300">
                Guest Contact Details
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="text-[11px] text-gray-400 block mb-1">Full Name *</label>
                  <input
                    type="text"
                    placeholder="e.g. Eleanor Vance"
                    value={guestName}
                    onChange={(e) => setGuestName(e.target.value)}
                    className="w-full bg-surface border border-surface-border rounded-xl px-3 py-2.5 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-gold"
                    required
                  />
                </div>

                <div>
                  <label className="text-[11px] text-gray-400 block mb-1">Email Address *</label>
                  <input
                    type="email"
                    placeholder="eleanor@example.com"
                    value={guestEmail}
                    onChange={(e) => setGuestEmail(e.target.value)}
                    className="w-full bg-surface border border-surface-border rounded-xl px-3 py-2.5 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-gold"
                    required
                  />
                </div>

                <div>
                  <label className="text-[11px] text-gray-400 block mb-1">Mobile Phone *</label>
                  <input
                    type="tel"
                    placeholder="+1 (555) 000-0000"
                    value={guestPhone}
                    onChange={(e) => setGuestPhone(e.target.value)}
                    className="w-full bg-surface border border-surface-border rounded-xl px-3 py-2.5 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-gold"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="text-[11px] text-gray-400 block mb-1">
                  Special Requests / Dietary Allergies / Occasion (Optional)
                </label>
                <textarea
                  rows={2}
                  placeholder="e.g., Anniversary dinner, quiet table requested, gluten allergy..."
                  value={specialRequests}
                  onChange={(e) => setSpecialRequests(e.target.value)}
                  className="w-full bg-surface border border-surface-border rounded-xl px-3 py-2 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-gold resize-none"
                />
              </div>
            </div>

            {/* Submission CTA */}
            <div className="pt-4 border-t border-surface-border flex flex-col sm:flex-row items-center justify-between gap-4">
              <div className="flex items-center gap-2 text-xs text-gray-400">
                <ShieldCheck className="w-4 h-4 text-gold shrink-0" />
                <span>Zero reservation fee • Instant confirmation email with management link</span>
              </div>

              <button
                type="submit"
                disabled={isSubmitting || !selectedSlot}
                className="w-full sm:w-auto px-8 py-4 rounded-xl bg-gold hover:bg-gold-hover disabled:opacity-40 disabled:pointer-events-none text-background font-bold text-xs uppercase tracking-widest transition-all shadow-xl hover:shadow-gold/20 flex items-center justify-center gap-2"
              >
                {isSubmitting ? (
                  <span className="w-4 h-4 border-2 border-background border-t-transparent rounded-full animate-spin" />
                ) : (
                  <>
                    <span>Confirm Reservation</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>
            </div>
          </form>
        </div>
      </main>

      <Footer />
    </>
  );
}

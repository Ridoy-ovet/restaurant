import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { getCurrentUser } from '@/lib/auth';

export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const target = searchParams.get('target');

    const where: any = { isActive: true };
    if (target && target !== 'ALL') {
      where.OR = [{ targetPage: 'ALL' }, { targetPage: target }];
    }

    const promotions = await prisma.promotion.findMany({
      where,
      orderBy: { createdAt: 'desc' },
    });

    return NextResponse.json({ promotions });
  } catch (error: any) {
    console.error('Fetch promotions error:', error);
    return NextResponse.json({ error: 'Failed to fetch promotions' }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const user = await getCurrentUser();
    if (!user || !['SUPER_ADMIN', 'MANAGER'].includes(user.role)) {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
    }

    const body = await req.json();
    const { title, description, imageUrl, videoUrl, targetPage, buttonText, buttonUrl, startDate, endDate } = body;

    if (!title || !description) {
      return NextResponse.json({ error: 'Title and description are required' }, { status: 400 });
    }

    const promo = await prisma.promotion.create({
      data: {
        title: title.trim(),
        description: description.trim(),
        imageUrl: imageUrl || null,
        videoUrl: videoUrl || null,
        targetPage: targetPage || 'ALL',
        buttonText: buttonText ? buttonText.trim() : 'View Details',
        buttonUrl: buttonUrl ? buttonUrl.trim() : '/menu',
        startDate: startDate || null,
        endDate: endDate || null,
        isActive: true,
      },
    });

    return NextResponse.json({ success: true, promotion: promo });
  } catch (error: any) {
    console.error('Create promotion error:', error);
    return NextResponse.json({ error: 'Failed to create promotion' }, { status: 500 });
  }
}

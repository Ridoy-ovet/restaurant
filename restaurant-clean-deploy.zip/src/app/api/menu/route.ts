import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { getCurrentUser } from '@/lib/auth';

export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const categorySlug = searchParams.get('category');
    const search = searchParams.get('search');
    const onlyAvailable = searchParams.get('onlyAvailable') === 'true';

    const categories = await prisma.menuCategory.findMany({
      where: { isActive: true },
      orderBy: { displayOrder: 'asc' },
      include: {
        items: {
          where: {
            ...(onlyAvailable ? { isAvailable: true } : {}),
            ...(search
              ? {
                  OR: [
                    { name: { contains: search } },
                    { description: { contains: search } },
                    { tags: { contains: search } },
                    { dietary: { contains: search } },
                  ],
                }
              : {}),
          },
          orderBy: { displayOrder: 'asc' },
        },
      },
    });

    // If specific category requested
    let filtered = categories;
    if (categorySlug && categorySlug !== 'all') {
      filtered = categories.filter((c) => c.slug === categorySlug);
    }

    return NextResponse.json({ categories: filtered });
  } catch (error: any) {
    console.error('Fetch menu error:', error);
    return NextResponse.json({ error: 'Failed to fetch menu' }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const user = await getCurrentUser();
    if (!user || !['SUPER_ADMIN', 'MANAGER'].includes(user.role)) {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
    }

    const body = await req.json();
    const { categoryId, name, description, price, discountPrice, imageUrl, tags, dietary, isFeatured } = body;

    if (!categoryId || !name || price === undefined) {
      return NextResponse.json({ error: 'Category, name and price are required' }, { status: 400 });
    }

    const item = await prisma.menuItem.create({
      data: {
        categoryId,
        name: name.trim(),
        description: description ? description.trim() : '',
        price: parseFloat(price),
        discountPrice: discountPrice ? parseFloat(discountPrice) : null,
        imageUrl: imageUrl || null,
        tags: tags ? tags.trim() : null,
        dietary: dietary ? dietary.trim() : null,
        isFeatured: Boolean(isFeatured),
        isAvailable: true,
      },
    });

    await prisma.auditLog.create({
      data: {
        userId: user.id,
        userName: user.name,
        userRole: user.role,
        action: 'CREATE_MENU_ITEM',
        entity: 'MenuItem',
        entityId: item.id,
        details: `Created dish: ${item.name} ($${item.price})`,
      },
    });

    return NextResponse.json({ success: true, item });
  } catch (error: any) {
    console.error('Create menu item error:', error);
    return NextResponse.json({ error: 'Failed to create menu item' }, { status: 500 });
  }
}

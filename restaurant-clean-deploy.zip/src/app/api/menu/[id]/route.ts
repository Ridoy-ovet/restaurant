import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { getCurrentUser } from '@/lib/auth';

interface Params {
  params: { id: string };
}

export async function PATCH(req: Request, { params }: Params) {
  try {
    const user = await getCurrentUser();
    if (!user || !['SUPER_ADMIN', 'MANAGER'].includes(user.role)) {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
    }

    const body = await req.json();
    const data: any = {};

    if (body.name !== undefined) data.name = body.name.trim();
    if (body.description !== undefined) data.description = body.description.trim();
    if (body.price !== undefined) data.price = parseFloat(body.price);
    if (body.discountPrice !== undefined) data.discountPrice = body.discountPrice ? parseFloat(body.discountPrice) : null;
    if (body.imageUrl !== undefined) data.imageUrl = body.imageUrl;
    if (body.tags !== undefined) data.tags = body.tags;
    if (body.dietary !== undefined) data.dietary = body.dietary;
    if (body.isAvailable !== undefined) data.isAvailable = Boolean(body.isAvailable);
    if (body.isFeatured !== undefined) data.isFeatured = Boolean(body.isFeatured);
    if (body.categoryId !== undefined) data.categoryId = body.categoryId;

    const updated = await prisma.menuItem.update({
      where: { id: params.id },
      data,
    });

    await prisma.auditLog.create({
      data: {
        userId: user.id,
        userName: user.name,
        userRole: user.role,
        action: 'UPDATE_MENU_ITEM',
        entity: 'MenuItem',
        entityId: updated.id,
        details: `Updated dish: ${updated.name}`,
      },
    });

    return NextResponse.json({ success: true, item: updated });
  } catch (error: any) {
    console.error('Update menu item error:', error);
    return NextResponse.json({ error: 'Failed to update menu item' }, { status: 500 });
  }
}

export async function DELETE(req: Request, { params }: Params) {
  try {
    const user = await getCurrentUser();
    if (!user || !['SUPER_ADMIN', 'MANAGER'].includes(user.role)) {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
    }

    const item = await prisma.menuItem.delete({
      where: { id: params.id },
    });

    await prisma.auditLog.create({
      data: {
        userId: user.id,
        userName: user.name,
        userRole: user.role,
        action: 'DELETE_MENU_ITEM',
        entity: 'MenuItem',
        entityId: item.id,
        details: `Deleted dish: ${item.name}`,
      },
    });

    return NextResponse.json({ success: true, message: 'Item deleted' });
  } catch (error: any) {
    console.error('Delete menu item error:', error);
    return NextResponse.json({ error: 'Failed to delete menu item' }, { status: 500 });
  }
}

export const dynamic = 'force-dynamic';
import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { getCurrentUser } from '@/lib/auth';

export async function GET() {
  try {
    let settings = await prisma.restaurantSettings.findUnique({
      where: { id: 'default' },
    });

    if (!settings) {
      return NextResponse.json({ error: 'Settings not found' }, { status: 404 });
    }

    return NextResponse.json({
      settings: {
        ...settings,
        openingHours: JSON.parse(settings.openingHours),
        bookingConfig: JSON.parse(settings.bookingConfig),
        socialLinks: JSON.parse(settings.socialLinks),
      },
    });
  } catch (error: any) {
    console.error('Fetch settings error:', error);
    return NextResponse.json({ error: 'Failed to fetch settings' }, { status: 500 });
  }
}

export async function PUT(req: Request) {
  try {
    const user = await getCurrentUser();
    if (!user || !['SUPER_ADMIN', 'MANAGER'].includes(user.role)) {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
    }

    const body = await req.json();
    const {
      name,
      tagline,
      description,
      address,
      phone,
      email,
      heroBanner,
      logoUrl,
      faviconUrl,
      openingHours,
      bookingConfig,
      socialLinks,
    } = body;

    const data: any = {};
    if (name) data.name = name;
    if (tagline) data.tagline = tagline;
    if (description) data.description = description;
    if (address) data.address = address;
    if (phone) data.phone = phone;
    if (email) data.email = email;
    if (heroBanner !== undefined) data.heroBanner = heroBanner;
    if (logoUrl !== undefined) data.logoUrl = logoUrl;
    if (faviconUrl !== undefined) data.faviconUrl = faviconUrl;
    if (openingHours) data.openingHours = JSON.stringify(openingHours);
    if (bookingConfig) data.bookingConfig = JSON.stringify(bookingConfig);
    if (socialLinks) data.socialLinks = JSON.stringify(socialLinks);

    const updated = await prisma.restaurantSettings.update({
      where: { id: 'default' },
      data,
    });

    await prisma.auditLog.create({
      data: {
        userId: user.id,
        userName: user.name,
        userRole: user.role,
        action: 'UPDATE_RESTAURANT_SETTINGS',
        entity: 'RestaurantSettings',
        details: `Updated settings: ${Object.keys(data).join(', ')}`,
      },
    });

    return NextResponse.json({
      success: true,
      settings: {
        ...updated,
        openingHours: JSON.parse(updated.openingHours),
        bookingConfig: JSON.parse(updated.bookingConfig),
        socialLinks: JSON.parse(updated.socialLinks),
      },
    });
  } catch (error: any) {
    console.error('Update settings error:', error);
    return NextResponse.json({ error: 'Failed to update settings' }, { status: 500 });
  }
}

import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { broadcastEvent } from '@/lib/events';
import { getCurrentUser } from '@/lib/auth';

const COOLDOWN_SECONDS = 120; // 2 minute spam prevention cooldown

export async function GET() {
  try {
    const activeCalls = await prisma.waiterRequest.findMany({
      where: { status: 'PENDING' },
      include: {
        table: { select: { id: true, tableNumber: true, name: true, section: true } },
      },
      orderBy: { requestedAt: 'asc' },
    });

    return NextResponse.json({ activeCalls });
  } catch (error: any) {
    console.error('Fetch waiter calls error:', error);
    return NextResponse.json({ error: 'Failed to fetch waiter calls' }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const { tableId } = await req.json();

    if (!tableId) {
      return NextResponse.json({ error: 'tableId is required' }, { status: 400 });
    }

    const table = await prisma.table.findUnique({
      where: { id: tableId },
    });

    if (!table) {
      return NextResponse.json({ error: 'Table not found' }, { status: 404 });
    }

    // Cooldown check: Find pending request for this table created recently
    const recentCall = await prisma.waiterRequest.findFirst({
      where: {
        tableId: table.id,
        status: 'PENDING',
      },
      orderBy: { requestedAt: 'desc' },
    });

    if (recentCall) {
      const elapsedSeconds = Math.floor((Date.now() - new Date(recentCall.requestedAt).getTime()) / 1000);
      if (elapsedSeconds < COOLDOWN_SECONDS) {
        const remaining = COOLDOWN_SECONDS - elapsedSeconds;
        return NextResponse.json(
          {
            error: `Waiter has already been called. Please wait ${remaining}s before calling again.`,
            remainingSeconds: remaining,
          },
          { status: 429 }
        );
      }
    }

    const request = await prisma.waiterRequest.create({
      data: {
        tableId: table.id,
        status: 'PENDING',
      },
      include: {
        table: true,
      },
    });

    broadcastEvent('WAITER_CALLED', {
      requestId: request.id,
      tableNumber: table.tableNumber,
      tableName: table.name,
      section: table.section,
      requestedAt: request.requestedAt,
    });

    return NextResponse.json({
      success: true,
      message: `Head Waiter alerted for Table ${table.tableNumber}. A staff member will arrive shortly.`,
      request,
      cooldownSeconds: COOLDOWN_SECONDS,
    });
  } catch (error: any) {
    console.error('Call waiter error:', error);
    return NextResponse.json({ error: 'Failed to submit waiter request' }, { status: 500 });
  }
}

export async function PATCH(req: Request) {
  try {
    const { requestId, status } = await req.json();
    const user = await getCurrentUser();

    if (!requestId) {
      return NextResponse.json({ error: 'requestId is required' }, { status: 400 });
    }

    const updated = await prisma.waiterRequest.update({
      where: { id: requestId },
      data: {
        status: status || 'COMPLETED',
        resolvedAt: new Date(),
        resolvedBy: user ? user.name : 'Staff Member',
      },
      include: { table: true },
    });

    broadcastEvent('WAITER_RESOLVED', {
      requestId: updated.id,
      tableNumber: updated.table.tableNumber,
    });

    return NextResponse.json({ success: true, request: updated });
  } catch (error: any) {
    console.error('Resolve waiter call error:', error);
    return NextResponse.json({ error: 'Failed to resolve waiter call' }, { status: 500 });
  }
}

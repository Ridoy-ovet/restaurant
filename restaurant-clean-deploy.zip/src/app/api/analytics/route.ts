import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { getCurrentUser } from '@/lib/auth';

export async function GET() {
  try {
    const user = await getCurrentUser();
    if (!user || !['SUPER_ADMIN', 'MANAGER'].includes(user.role)) {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
    }

    const todayStr = new Date().toISOString().split('T')[0];

    const [
      totalReservationsToday,
      activeOrders,
      totalRevenueOrders,
      tables,
      topDishes,
      pendingWaiterCalls,
    ] = await Promise.all([
      prisma.reservation.count({
        where: { date: todayStr, status: { not: 'CANCELLED' } },
      }),
      prisma.order.count({
        where: { status: { in: ['NEW', 'CONFIRMED', 'PREPARING', 'READY', 'SERVED'] } },
      }),
      prisma.order.aggregate({
        where: { status: { not: 'CANCELLED' } },
        _sum: { totalAmount: true },
      }),
      prisma.table.findMany({
        select: { id: true, status: true, capacity: true },
      }),
      prisma.orderItem.groupBy({
        by: ['menuItemId'],
        _sum: { quantity: true },
        orderBy: { _sum: { quantity: 'desc' } },
        take: 5,
      }),
      prisma.waiterRequest.count({
        where: { status: 'PENDING' },
      }),
    ]);

    // Populate top dishes details
    const topDishIds = topDishes.map((d) => d.menuItemId);
    const dishItems = await prisma.menuItem.findMany({
      where: { id: { in: topDishIds } },
      select: { id: true, name: true, price: true, imageUrl: true },
    });
    const dishMap = new Map(dishItems.map((d) => [d.id, d]));

    const popularDishes = topDishes.map((d) => ({
      item: dishMap.get(d.menuItemId),
      totalOrdered: d._sum.quantity || 0,
    }));

    const occupiedTables = tables.filter((t) => t.status === 'OCCUPIED').length;
    const availableTables = tables.filter((t) => t.status === 'AVAILABLE').length;
    const reservedTables = tables.filter((t) => t.status === 'RESERVED').length;

    return NextResponse.json({
      metrics: {
        todayReservations: totalReservationsToday,
        activeOrders,
        totalRevenue: totalRevenueOrders._sum.totalAmount || 0,
        pendingWaiterCalls,
        tableStats: {
          total: tables.length,
          occupied: occupiedTables,
          available: availableTables,
          reserved: reservedTables,
        },
        popularDishes,
      },
    });
  } catch (error: any) {
    console.error('Analytics error:', error);
    return NextResponse.json({ error: 'Failed to fetch analytics' }, { status: 500 });
  }
}

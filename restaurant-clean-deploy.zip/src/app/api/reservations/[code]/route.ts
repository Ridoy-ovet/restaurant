import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { getCurrentUser } from '@/lib/auth';
import { broadcastEvent } from '@/lib/events';

interface Params {
  params: { code: string };
}

export async function GET(req: Request, { params }: Params) {
  try {
    const reservation = await prisma.reservation.findUnique({
      where: { reservationCode: params.code },
      include: {
        table: {
          select: { id: true, tableNumber: true, name: true, section: true },
        },
      },
    });

    if (!reservation) {
      return NextResponse.json({ error: 'Reservation not found' }, { status: 404 });
    }

    return NextResponse.json({ reservation });
  } catch (error: any) {
    console.error('Fetch reservation by code error:', error);
    return NextResponse.json({ error: 'Failed to fetch reservation' }, { status: 500 });
  }
}

export async function PATCH(req: Request, { params }: Params) {
  try {
    const user = await getCurrentUser();
    const body = await req.json();

    const reservation = await prisma.reservation.findUnique({
      where: { reservationCode: params.code },
    });

    if (!reservation) {
      return NextResponse.json({ error: 'Reservation not found' }, { status: 404 });
    }

    const isStaff = user && ['SUPER_ADMIN', 'MANAGER', 'STAFF'].includes(user.role);

    // If customer, ensure they own it or match the guest email
    if (!isStaff && user && reservation.customerId && reservation.customerId !== user.id) {
      return NextResponse.json({ error: 'Unauthorized to modify this reservation' }, { status: 403 });
    }

    const updated = await prisma.reservation.update({
      where: { reservationCode: params.code },
      data: {
        ...(body.status ? { status: body.status } : {}),
        ...(body.specialRequests !== undefined ? { specialRequests: body.specialRequests } : {}),
        ...(body.tableId ? { tableId: body.tableId } : {}),
        ...(body.partySize ? { partySize: parseInt(body.partySize, 10) } : {}),
        ...(body.timeSlot ? { timeSlot: body.timeSlot } : {}),
        ...(body.date ? { date: body.date } : {}),
        ...(body.cancelReason ? { cancelReason: body.cancelReason } : {}),
      },
      include: {
        table: true,
      },
    });

    broadcastEvent('RESERVATION_UPDATED', {
      reservationCode: updated.reservationCode,
      status: updated.status,
      date: updated.date,
      timeSlot: updated.timeSlot,
    });

    return NextResponse.json({ success: true, reservation: updated });
  } catch (error: any) {
    console.error('Update reservation error:', error);
    return NextResponse.json({ error: 'Failed to update reservation' }, { status: 500 });
  }
}

export async function DELETE(req: Request, { params }: Params) {
  try {
    const reservation = await prisma.reservation.findUnique({
      where: { reservationCode: params.code },
    });

    if (!reservation) {
      return NextResponse.json({ error: 'Reservation not found' }, { status: 404 });
    }

    const updated = await prisma.reservation.update({
      where: { reservationCode: params.code },
      data: {
        status: 'CANCELLED',
        cancelReason: 'Cancelled by customer/admin request',
      },
    });

    broadcastEvent('RESERVATION_UPDATED', {
      reservationCode: updated.reservationCode,
      status: 'CANCELLED',
    });

    return NextResponse.json({ success: true, message: 'Reservation successfully cancelled' });
  } catch (error: any) {
    console.error('Cancel reservation error:', error);
    return NextResponse.json({ error: 'Failed to cancel reservation' }, { status: 500 });
  }
}

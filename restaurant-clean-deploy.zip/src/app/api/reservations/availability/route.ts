export const dynamic = 'force-dynamic';
import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

// Helper to convert "HH:MM" to minutes from midnight
function timeToMinutes(timeStr: string): number {
  const [h, m] = timeStr.split(':').map(Number);
  return h * 60 + m;
}

// Helper to convert minutes to "HH:MM"
function minutesToTime(minutes: number): string {
  const h = Math.floor(minutes / 60);
  const m = minutes % 60;
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
}

export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const date = searchParams.get('date');
    const partySizeStr = searchParams.get('partySize');

    if (!date) {
      return NextResponse.json({ error: 'Date is required (YYYY-MM-DD)' }, { status: 400 });
    }

    const partySize = parseInt(partySizeStr || '2', 10);
    if (isNaN(partySize) || partySize < 1 || partySize > 20) {
      return NextResponse.json({ error: 'Invalid party size' }, { status: 400 });
    }

    // 1. Fetch settings
    const settings = await prisma.restaurantSettings.findUnique({
      where: { id: 'default' },
    });

    if (!settings) {
      return NextResponse.json({ error: 'Settings not configured' }, { status: 500 });
    }

    const openingHours = JSON.parse(settings.openingHours);
    const bookingConfig = JSON.parse(settings.bookingConfig);

    // Check if closed on this specific date
    if (bookingConfig.closedDates && bookingConfig.closedDates.includes(date)) {
      return NextResponse.json({
        available: false,
        reason: 'Restaurant is closed for a holiday on this date',
        slots: [],
      });
    }

    // Determine day of week
    const targetDate = new Date(date + 'T12:00:00Z');
    const dayNames = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
    const dayName = dayNames[targetDate.getUTCDay()];
    const daySchedule = openingHours[dayName];

    if (!daySchedule || daySchedule.closed) {
      return NextResponse.json({
        available: false,
        reason: `Restaurant is closed on ${dayName.toUpperCase()}s`,
        slots: [],
      });
    }

    // 2. Fetch all active tables that can accommodate this party size
    const candidateTables = await prisma.table.findMany({
      where: {
        isActive: true,
        capacity: { gte: partySize },
      },
      orderBy: { capacity: 'asc' }, // Prefer most snug table fit
    });

    if (candidateTables.length === 0) {
      return NextResponse.json({
        available: false,
        reason: `No tables available with capacity for ${partySize} guests`,
        slots: [],
      });
    }

    // 3. Fetch all active reservations for this date
    const existingReservations = await prisma.reservation.findMany({
      where: {
        date,
        status: { in: ['PENDING', 'CONFIRMED', 'SEATED'] },
      },
    });

    // Parse service periods (e.g. "12:00 - 15:00", "17:30 - 22:30")
    const servicePeriods: { start: number; end: number }[] = [];

    const parsePeriod = (str: string) => {
      if (!str) return;
      const [startStr, endStr] = str.split('-').map((s) => s.trim());
      if (startStr && endStr) {
        servicePeriods.push({
          start: timeToMinutes(startStr),
          end: timeToMinutes(endStr),
        });
      }
    };

    parsePeriod(daySchedule.lunch);
    parsePeriod(daySchedule.dinner);

    const interval = bookingConfig.intervalMinutes || 30;
    const standardDuration = bookingConfig.defaultDurationMinutes || 90;

    const slots: { time: string; available: boolean; remainingTables: number }[] = [];

    for (const period of servicePeriods) {
      // Last booking time is typically period.end - standardDuration (or period.end - 30)
      const lastBookingMin = period.end - 45;

      for (let timeMin = period.start; timeMin <= lastBookingMin; timeMin += interval) {
        const slotTime = minutesToTime(timeMin);
        const slotEndMin = timeMin + standardDuration;

        // Count how many tables are free during [timeMin, slotEndMin]
        let freeTableCount = 0;

        for (const table of candidateTables) {
          // Check if this table has any collision with existing reservations
          const hasOverlap = existingReservations.some((res) => {
            if (res.tableId !== table.id) return false;
            const resStart = timeToMinutes(res.timeSlot);
            const resEnd = resStart + res.durationMinutes;
            // Overlap condition: start < resEnd AND slotEndMin > resStart
            return timeMin < resEnd && slotEndMin > resStart;
          });

          if (!hasOverlap) {
            freeTableCount++;
          }
        }

        slots.push({
          time: slotTime,
          available: freeTableCount > 0,
          remainingTables: freeTableCount,
        });
      }
    }

    return NextResponse.json({
      date,
      partySize,
      slots,
    });
  } catch (error: any) {
    console.error('Availability check error:', error);
    return NextResponse.json({ error: 'Failed to calculate availability' }, { status: 500 });
  }
}

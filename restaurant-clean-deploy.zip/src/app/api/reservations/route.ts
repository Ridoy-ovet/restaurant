import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { getCurrentUser } from '@/lib/auth';
import { broadcastEvent } from '@/lib/events';
import { sendEmail, renderReservationConfirmationEmail } from '@/lib/email';

function timeToMinutes(timeStr: string): number {
  const [h, m] = timeStr.split(':').map(Number);
  return h * 60 + m;
}

function generateReservationCode(): string {
  const randomPart = Math.random().toString(36).substring(2, 6).toUpperCase();
  const numPart = Math.floor(1000 + Math.random() * 9000);
  return `RSV-${numPart}-${randomPart}`;
}

export async function GET(req: Request) {
  try {
    const user = await getCurrentUser();
    const { searchParams } = new URL(req.url);
    const date = searchParams.get('date');
    const status = searchParams.get('status');
    const search = searchParams.get('search');

    const isStaff = user && ['SUPER_ADMIN', 'MANAGER', 'STAFF'].includes(user.role);

    const whereClause: any = {};

    if (!isStaff) {
      if (!user) {
        return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
      }
      // Normal customer only sees their own reservations
      whereClause.customerId = user.id;
    } else {
      // Staff filters
      if (date) whereClause.date = date;
      if (status && status !== 'ALL') whereClause.status = status;
      if (search) {
        whereClause.OR = [
          { guestName: { contains: search } },
          { guestEmail: { contains: search } },
          { guestPhone: { contains: search } },
          { reservationCode: { contains: search } },
        ];
      }
    }

    const reservations = await prisma.reservation.findMany({
      where: whereClause,
      include: {
        table: {
          select: { id: true, tableNumber: true, name: true, section: true },
        },
      },
      orderBy: [{ date: 'asc' }, { timeSlot: 'asc' }],
    });

    return NextResponse.json({ reservations });
  } catch (error: any) {
    console.error('Fetch reservations error:', error);
    return NextResponse.json({ error: 'Failed to fetch reservations' }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { date, timeSlot, partySize, guestName, guestEmail, guestPhone, specialRequests } = body;

    if (!date || !timeSlot || !partySize || !guestName || !guestEmail || !guestPhone) {
      return NextResponse.json({ error: 'Missing required reservation fields' }, { status: 400 });
    }

    const size = parseInt(partySize, 10);
    if (isNaN(size) || size < 1 || size > 20) {
      return NextResponse.json({ error: 'Party size must be between 1 and 20' }, { status: 400 });
    }

    const startMin = timeToMinutes(timeSlot);
    const durationMinutes = 90;
    const endMin = startMin + durationMinutes;

    // 1. Double-booking prevention check: find suitable free table
    const candidateTables = await prisma.table.findMany({
      where: {
        isActive: true,
        capacity: { gte: size },
      },
      orderBy: { capacity: 'asc' },
    });

    if (candidateTables.length === 0) {
      return NextResponse.json({ error: `No tables available for ${size} guests.` }, { status: 400 });
    }

    const existingReservations = await prisma.reservation.findMany({
      where: {
        date,
        status: { in: ['PENDING', 'CONFIRMED', 'SEATED'] },
      },
    });

    // Find the first free table that doesn't overlap
    let assignedTable = null;
    for (const table of candidateTables) {
      const hasConflict = existingReservations.some((res) => {
        if (res.tableId !== table.id) return false;
        const resStart = timeToMinutes(res.timeSlot);
        const resEnd = resStart + res.durationMinutes;
        return startMin < resEnd && endMin > resStart;
      });

      if (!hasConflict) {
        assignedTable = table;
        break;
      }
    }

    if (!assignedTable) {
      return NextResponse.json(
        { error: 'Selected time slot is fully booked for this party size. Please choose another time.' },
        { status: 409 }
      );
    }

    const loggedInUser = await getCurrentUser();
    const reservationCode = generateReservationCode();

    const reservation = await prisma.reservation.create({
      data: {
        reservationCode,
        customerId: loggedInUser ? loggedInUser.id : null,
        tableId: assignedTable.id,
        guestName: guestName.trim(),
        guestEmail: guestEmail.toLowerCase().trim(),
        guestPhone: guestPhone.trim(),
        partySize: size,
        date,
        timeSlot,
        durationMinutes,
        status: 'CONFIRMED',
        specialRequests: specialRequests ? specialRequests.trim() : null,
      },
      include: {
        table: true,
      },
    });

    // Broadcast real-time event to Admin & Staff
    broadcastEvent('RESERVATION_CREATED', {
      id: reservation.id,
      reservationCode: reservation.reservationCode,
      guestName: reservation.guestName,
      partySize: reservation.partySize,
      date: reservation.date,
      timeSlot: reservation.timeSlot,
      tableNumber: assignedTable.tableNumber,
      tableName: assignedTable.name,
    });

    // Send confirmation email asynchronously
    const appUrl = process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000';
    const manageUrl = `${appUrl}/reservation/${reservation.reservationCode}`;

    sendEmail({
      to: reservation.guestEmail,
      subject: `Reservation Confirmed: ${reservation.reservationCode} - L'Étoile Modern Brasserie`,
      html: renderReservationConfirmationEmail({
        restaurantName: "L'Étoile Modern Brasserie",
        guestName: reservation.guestName,
        reservationCode: reservation.reservationCode,
        date: reservation.date,
        timeSlot: reservation.timeSlot,
        partySize: reservation.partySize,
        specialRequests: reservation.specialRequests,
        manageUrl,
      }),
    }).catch((err) => console.error('Error dispatching reservation email:', err));

    return NextResponse.json({
      success: true,
      reservation,
    });
  } catch (error: any) {
    console.error('Create reservation error:', error);
    return NextResponse.json({ error: 'Internal server error while reserving table' }, { status: 500 });
  }
}

import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

interface Params {
  params: { token: string };
}

export async function GET(req: Request, { params }: Params) {
  try {
    const table = await prisma.table.findUnique({
      where: { qrToken: params.token },
      select: {
        id: true,
        tableNumber: true,
        name: true,
        capacity: true,
        section: true,
        status: true,
        isActive: true,
      },
    });

    if (!table || !table.isActive) {
      return NextResponse.json({ error: 'Invalid or inactive table QR' }, { status: 404 });
    }

    return NextResponse.json({ table });
  } catch (error: any) {
    console.error('Resolve table token error:', error);
    return NextResponse.json({ error: 'Failed to resolve table' }, { status: 500 });
  }
}

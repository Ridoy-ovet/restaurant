import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { broadcastEvent } from '@/lib/events';

interface Params {
  params: { id: string };
}

export async function PATCH(req: Request, { params }: Params) {
  try {
    const body = await req.json();
    const { status, capacity, section, name, regenerateQR, isActive } = body;

    const data: any = {};
    if (status !== undefined) data.status = status;
    if (capacity !== undefined) data.capacity = parseInt(capacity, 10);
    if (section !== undefined) data.section = section;
    if (name !== undefined) data.name = name;
    if (isActive !== undefined) data.isActive = Boolean(isActive);

    if (regenerateQR) {
      data.qrToken = `tbl_${Math.random().toString(36).substring(2, 9)}`;
    }

    const updated = await prisma.table.update({
      where: { id: params.id },
      data,
    });

    broadcastEvent('TABLE_STATUS_CHANGED', { tableId: updated.id, status: updated.status });

    return NextResponse.json({ success: true, table: updated });
  } catch (error: any) {
    console.error('Update table error:', error);
    return NextResponse.json({ error: 'Failed to update table' }, { status: 500 });
  }
}

export async function DELETE(req: Request, { params }: Params) {
  try {
    await prisma.table.delete({
      where: { id: params.id },
    });

    return NextResponse.json({ success: true, message: 'Table deleted successfully' });
  } catch (error: any) {
    console.error('Delete table error:', error);
    return NextResponse.json({ error: 'Failed to delete table' }, { status: 500 });
  }
}

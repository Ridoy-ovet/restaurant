import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { generateQRCodeSvg, generateQRCodeDataUrl } from '@/lib/qrcode';

interface Params {
  params: { id: string };
}

export async function GET(req: Request, { params }: Params) {
  try {
    const table = await prisma.table.findUnique({
      where: { id: params.id },
    });

    if (!table) {
      return NextResponse.json({ error: 'Table not found' }, { status: 404 });
    }

    const appUrl = process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000';
    const targetUrl = `${appUrl}/table/${table.qrToken}`;

    const { searchParams } = new URL(req.url);
    const format = searchParams.get('format');

    if (format === 'svg') {
      const svg = await generateQRCodeSvg(targetUrl);
      return new Response(svg, {
        headers: { 'Content-Type': 'image/svg+xml' },
      });
    }

    const dataUrl = await generateQRCodeDataUrl(targetUrl);
    return NextResponse.json({
      targetUrl,
      dataUrl,
      tableNumber: table.tableNumber,
      tableName: table.name,
      section: table.section,
    });
  } catch (error: any) {
    console.error('Generate table QR error:', error);
    return NextResponse.json({ error: 'Failed to generate QR code' }, { status: 500 });
  }
}

import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { broadcastEvent } from '@/lib/events';

export async function GET() {
  try {
    const tables = await prisma.table.findMany({
      orderBy: { tableNumber: 'asc' },
      include: {
        orders: {
          where: { status: { notIn: ['COMPLETED', 'CANCELLED'] } },
          select: { id: true, orderNumber: true, status: true, totalAmount: true },
        },
        waiterRequests: {
          where: { status: 'PENDING' },
          select: { id: true, requestedAt: true },
        },
      },
    });

    return NextResponse.json({ tables });
  } catch (error: any) {
    console.error('Fetch tables error:', error);
    return NextResponse.json({ error: 'Failed to fetch tables' }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { tableNumber, name, capacity, section } = body;

    if (!tableNumber || !name) {
      return NextResponse.json({ error: 'Table number and name are required' }, { status: 400 });
    }

    const parsedNum = parseInt(tableNumber, 10);
    const existing = await prisma.table.findUnique({
      where: { tableNumber: parsedNum },
    });

    if (existing) {
      return NextResponse.json({ error: `Table #${parsedNum} already exists` }, { status: 400 });
    }

    const qrToken = `tbl_${Math.random().toString(36).substring(2, 8)}_${parsedNum}`;

    const table = await prisma.table.create({
      data: {
        tableNumber: parsedNum,
        name: name.trim(),
        capacity: parseInt(capacity || '4', 10),
        section: section || 'Indoor Main',
        qrToken,
        status: 'AVAILABLE',
      },
    });

    broadcastEvent('TABLE_STATUS_CHANGED', { tableId: table.id, status: table.status });

    return NextResponse.json({ success: true, table });
  } catch (error: any) {
    console.error('Create table error:', error);
    return NextResponse.json({ error: 'Failed to create table' }, { status: 500 });
  }
}

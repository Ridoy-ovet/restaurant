import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { getCurrentUser } from '@/lib/auth';
import { broadcastEvent } from '@/lib/events';
import { sendEmail, renderOrderConfirmationEmail } from '@/lib/email';

export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const status = searchParams.get('status');
    const tableId = searchParams.get('tableId');

    const where: any = {};
    if (status && status !== 'ALL') {
      where.status = status;
    }
    if (tableId) {
      where.tableId = tableId;
    }

    const orders = await prisma.order.findMany({
      where,
      include: {
        table: { select: { id: true, tableNumber: true, name: true, section: true } },
        items: {
          include: {
            menuItem: { select: { id: true, name: true, imageUrl: true } },
          },
        },
      },
      orderBy: { createdAt: 'desc' },
    });

    return NextResponse.json({ orders });
  } catch (error: any) {
    console.error('Fetch orders error:', error);
    return NextResponse.json({ error: 'Failed to fetch orders' }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { tableId, items, guestName, notes } = body;

    if (!tableId || !items || !Array.isArray(items) || items.length === 0) {
      return NextResponse.json({ error: 'Valid table and items are required' }, { status: 400 });
    }

    // Verify table
    const table = await prisma.table.findUnique({
      where: { id: tableId },
    });

    if (!table) {
      return NextResponse.json({ error: 'Table not found' }, { status: 404 });
    }

    // Calculate item pricing from DB
    const itemIds = items.map((i: any) => i.menuItemId);
    const dbItems = await prisma.menuItem.findMany({
      where: { id: { in: itemIds } },
    });

    const dbItemMap = new Map(dbItems.map((item) => [item.id, item]));

    let total = 0;
    const orderItemData = [];

    for (const item of items) {
      const dbItem = dbItemMap.get(item.menuItemId);
      if (!dbItem || !dbItem.isAvailable) {
        return NextResponse.json(
          { error: `Item "${dbItem?.name || item.menuItemId}" is currently unavailable.` },
          { status: 400 }
        );
      }
      const unitPrice = dbItem.discountPrice ?? dbItem.price;
      const quantity = Math.max(1, parseInt(item.quantity || '1', 10));
      total += unitPrice * quantity;

      orderItemData.push({
        menuItemId: dbItem.id,
        quantity,
        unitPrice,
        notes: item.notes ? String(item.notes).trim() : null,
      });
    }

    const orderNumber = `ORD-${Math.floor(1000 + Math.random() * 9000)}`;
    const user = await getCurrentUser();

    const order = await prisma.order.create({
      data: {
        orderNumber,
        tableId: table.id,
        customerId: user ? user.id : null,
        guestName: guestName ? guestName.trim() : (user ? user.name : `Guest (Table ${table.tableNumber})`),
        totalAmount: parseFloat(total.toFixed(2)),
        notes: notes ? notes.trim() : null,
        status: 'NEW',
        items: {
          create: orderItemData,
        },
      },
      include: {
        table: true,
        items: {
          include: { menuItem: true },
        },
      },
    });

    // Mark table as OCCUPIED if it was AVAILABLE
    if (table.status === 'AVAILABLE') {
      await prisma.table.update({
        where: { id: table.id },
        data: { status: 'OCCUPIED' },
      });
      broadcastEvent('TABLE_STATUS_CHANGED', { tableId: table.id, status: 'OCCUPIED' });
    }

    // Broadcast new order to Kitchen & Staff POS in real time
    broadcastEvent('ORDER_CREATED', {
      id: order.id,
      orderNumber: order.orderNumber,
      tableName: table.name,
      tableNumber: table.tableNumber,
      totalAmount: order.totalAmount,
      itemCount: order.items.length,
      status: order.status,
      createdAt: order.createdAt,
    });

    // If user has email, send transactional order receipt
    if (user?.email) {
      const appUrl = process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000';
      sendEmail({
        to: user.email,
        subject: `Order Received: ${order.orderNumber} - L'Étoile Brasserie`,
        html: renderOrderConfirmationEmail({
          restaurantName: "L'Étoile Modern Brasserie",
          orderNumber: order.orderNumber,
          tableName: table.name,
          totalAmount: order.totalAmount,
          items: order.items.map((i) => ({
            name: i.menuItem.name,
            quantity: i.quantity,
            unitPrice: i.unitPrice,
          })),
          statusUrl: `${appUrl}/order-status/${order.orderNumber}`,
        }),
      }).catch((e) => console.error('Error dispatching order receipt email:', e));
    }

    return NextResponse.json({
      success: true,
      order,
    });
  } catch (error: any) {
    console.error('Create order error:', error);
    return NextResponse.json({ error: 'Failed to create order' }, { status: 500 });
  }
}

import type { Metadata } from 'next';
import './globals.css';
import { CartProvider } from '@/context/CartContext';
import { ToastProvider } from '@/context/ToastContext';
import { CartDrawer } from '@/components/CartDrawer';

export const metadata: Metadata = {
  title: "L'Étoile Modern Brasserie | Table Reservations & QR Ordering",
  description: "Artisanal gastronomy, wood-fired hearth cooking, and seamless digital table reservations and QR ordering.",
  keywords: "restaurant, reservation, digital menu, QR ordering, fine dining, brasserie",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="dark">
      <body className="min-h-screen bg-background text-foreground antialiased flex flex-col selection:bg-gold/30 selection:text-gold">
        <ToastProvider>
          <CartProvider>
            {children}
            <CartDrawer />
          </CartProvider>
        </ToastProvider>
      </body>
    </html>
  );
}

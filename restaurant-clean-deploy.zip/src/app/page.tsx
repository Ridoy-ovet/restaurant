import React from 'react';
import Link from 'next/link';
import { prisma } from '@/lib/prisma';
import { Navbar } from '@/components/Navbar';
import { Footer } from '@/components/Footer';
import { Hero } from '@/components/Hero';
import { MenuExplorer } from '@/components/MenuExplorer';
import { 
  Sparkles, 
  Wine, 
  Flame, 
  Calendar, 
  Clock, 
  MapPin, 
  ArrowRight, 
  ShieldCheck, 
  CheckCircle2,
  ChevronRight
} from 'lucide-react';

export const revalidate = 0; // Fresh data

async function getLandingData() {
  const [settings, categories, promotions] = await Promise.all([
    prisma.restaurantSettings.findUnique({ where: { id: 'default' } }),
    prisma.menuCategory.findMany({
      where: { isActive: true },
      orderBy: { displayOrder: 'asc' },
      include: {
        items: {
          where: { isAvailable: true },
          orderBy: { displayOrder: 'asc' },
        },
      },
    }),
    prisma.promotion.findMany({
      where: {
        isActive: true,
        OR: [{ targetPage: 'ALL' }, { targetPage: 'HOME' }],
      },
      take: 2,
    }),
  ]);

  return {
    settings,
    categories,
    promotions,
  };
}

export default async function HomePage() {
  const { settings, categories, promotions } = await getLandingData();

  return (
    <>
      <Navbar />

      <main className="flex-1">
        {/* Hero Section */}
        <Hero
          settings={{
            name: settings?.name,
            tagline: settings?.tagline,
            description: settings?.description,
            heroBanner: settings?.heroBanner || undefined,
          }}
        />

        {/* Featured Promotions Banner */}
        {promotions.length > 0 && (
          <section className="bg-surface-card border-y border-surface-border py-6 px-4 sm:px-6">
            <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-6">
              {promotions.map((promo) => (
                <div
                  key={promo.id}
                  className="bg-surface rounded-2xl border border-surface-border hover:border-gold/40 p-5 flex flex-col sm:flex-row items-center gap-5 transition-all group"
                >
                  {promo.imageUrl && (
                    <div className="w-full sm:w-32 h-28 shrink-0 rounded-xl overflow-hidden bg-surface-card">
                      <img
                        src={promo.imageUrl}
                        alt={promo.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                      />
                    </div>
                  )}
                  <div className="flex-1 text-center sm:text-left">
                    <span className="text-[10px] font-bold uppercase tracking-widest text-gold bg-gold/10 border border-gold/20 px-2 py-0.5 rounded-full inline-block mb-1.5">
                      Limited Seasonal Experience
                    </span>
                    <h3 className="text-base font-serif font-bold text-white group-hover:text-gold transition-colors">
                      {promo.title}
                    </h3>
                    <p className="text-xs text-gray-400 mt-1 line-clamp-2">
                      {promo.description}
                    </p>
                    {promo.buttonText && promo.buttonUrl && (
                      <Link
                        href={promo.buttonUrl}
                        className="inline-flex items-center gap-1 text-xs font-semibold text-gold hover:text-gold-hover mt-3"
                      >
                        <span>{promo.buttonText}</span>
                        <ChevronRight className="w-3.5 h-3.5" />
                      </Link>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </section>
        )}

        {/* Philosophy & Craftsmanship Section */}
        <section className="py-24 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="bg-surface-card p-8 rounded-2xl border border-surface-border hover:border-gold/30 transition-all space-y-4">
              <div className="w-12 h-12 rounded-xl bg-gold/15 border border-gold/30 flex items-center justify-center text-gold">
                <Flame className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-serif font-bold text-white">
                Binchotan Wood-Fired Hearth
              </h3>
              <p className="text-xs text-gray-400 leading-relaxed font-light">
                Every prime cut and coastal catch is kissed by white oak charcoal at 900°F, caramelizing natural fats while infusing an incomparable smoky resonance.
              </p>
            </div>

            <div className="bg-surface-card p-8 rounded-2xl border border-surface-border hover:border-gold/30 transition-all space-y-4">
              <div className="w-12 h-12 rounded-xl bg-gold/15 border border-gold/30 flex items-center justify-center text-gold">
                <Sparkles className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-serif font-bold text-white">
                Biodynamic Provenance
              </h3>
              <p className="text-xs text-gray-400 leading-relaxed font-light">
                We partner exclusively with multi-generational organic farms, wild foraged fungi harvesters, and sustainable line-caught fishermen to champion pure terroir.
              </p>
            </div>

            <div className="bg-surface-card p-8 rounded-2xl border border-surface-border hover:border-gold/30 transition-all space-y-4">
              <div className="w-12 h-12 rounded-xl bg-gold/15 border border-gold/30 flex items-center justify-center text-gold">
                <Wine className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-serif font-bold text-white">
                Curated Sommelier Cellar
              </h3>
              <p className="text-xs text-gray-400 leading-relaxed font-light">
                Our subterranean vault houses over 800 references of grower Champagnes, natural Burgundies, and rare single-cask botanical elixirs.
              </p>
            </div>
          </div>
        </section>

        {/* Interactive Digital Menu Explorer */}
        <MenuExplorer
          categories={categories}
          title="The Degustation & À La Carte"
          subtitle="Select any dish to view ingredients, dietary profiles, or add directly to your in-restaurant dining cart."
        />

        {/* Reservation Callout Banner */}
        <section className="py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-b from-surface-card to-background border-t border-surface-border">
          <div className="max-w-4xl mx-auto text-center space-y-6">
            <span className="text-xs uppercase tracking-widest text-gold font-semibold">
              Bespoke Seating
            </span>
            <h2 className="text-3xl sm:text-5xl font-serif font-bold text-white tracking-tight">
              An Evening Designed to Linger
            </h2>
            <p className="text-sm text-gray-300 max-w-xl mx-auto font-light leading-relaxed">
              Tables are reserved with generous intervals to guarantee unhurried service, private ambiance, and exquisite kitchen attention.
            </p>
            <div className="pt-4">
              <Link
                href="/reservation"
                className="inline-flex items-center gap-3 px-8 py-4 rounded-full bg-gold hover:bg-gold-hover text-background font-bold text-sm uppercase tracking-widest transition-all shadow-xl hover:shadow-gold/20"
              >
                <Calendar className="w-4 h-4" />
                <span>Reserve Your Table Now</span>
              </Link>
            </div>
          </div>
        </section>

        {/* Location & Map Preview (Performance-optimized lazy presentation) */}
        <section className="py-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
          <div className="bg-surface-card rounded-3xl border border-surface-border p-8 sm:p-12 grid grid-cols-1 lg:grid-cols-2 gap-10 items-center">
            <div className="space-y-6">
              <span className="text-xs uppercase tracking-widest text-gold font-semibold">
                Arrival & Concierge
              </span>
              <h3 className="text-2xl sm:text-4xl font-serif font-bold text-white">
                Located in the Historic Arts District
              </h3>
              <div className="space-y-4 text-xs sm:text-sm text-gray-300 font-light">
                <p className="flex items-start gap-3">
                  <MapPin className="w-5 h-5 text-gold shrink-0 mt-0.5" />
                  <span>
                    428 Grand Boulevard, Suite 100, Metropolitan Arts District.<br />
                    Complimentary valet service available Tuesday through Sunday evenings.
                  </span>
                </p>
                <p className="flex items-center gap-3">
                  <Clock className="w-5 h-5 text-gold shrink-0" />
                  <span>Dinner: 17:30 – Late • Lunch: 12:00 – 15:30</span>
                </p>
              </div>

              <div className="pt-2 flex flex-wrap gap-4">
                <Link
                  href="/reservation"
                  className="px-6 py-3 rounded-full bg-gold text-background font-bold text-xs uppercase tracking-wider hover:bg-gold-hover transition-colors shadow-md"
                >
                  Book Table
                </Link>
                <Link
                  href="/menu"
                  className="px-6 py-3 rounded-full border border-surface-border text-white font-semibold text-xs uppercase tracking-wider hover:border-gold/50 transition-colors"
                >
                  Browse Menu
                </Link>
              </div>
            </div>

            {/* Interactive Map card */}
            <div className="relative h-72 sm:h-80 w-full rounded-2xl overflow-hidden border border-surface-border bg-surface flex items-center justify-center group">
              <div
                className="absolute inset-0 bg-cover bg-center opacity-60 group-hover:opacity-75 transition-opacity"
                style={{
                  backgroundImage:
                    "url('https://images.unsplash.com/photo-1526778548025-fa2f459cd5c1?q=80&w=1200&auto=format&fit=crop')",
                }}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-background via-black/40 to-transparent" />
              <div className="relative z-10 text-center p-6 bg-surface-card/90 backdrop-blur-md border border-surface-border rounded-xl max-w-xs shadow-2xl">
                <MapPin className="w-8 h-8 text-gold mx-auto mb-2" />
                <h4 className="text-sm font-serif font-bold text-white">Metropolitan Arts District</h4>
                <p className="text-[11px] text-gray-400 mt-1">Valet Entrance on Grand Blvd</p>
                <a
                  href="https://maps.google.com"
                  target="_blank"
                  rel="noreferrer"
                  className="mt-3 inline-block text-[11px] font-bold text-gold uppercase tracking-wider hover:underline"
                >
                  Open in Google Maps →
                </a>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </>
  );
}

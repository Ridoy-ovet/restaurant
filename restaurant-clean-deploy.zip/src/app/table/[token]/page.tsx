'use client';

import React, { useEffect, useState } from 'react';
import { useParams } from 'next/navigation';
import { Navbar } from '@/components/Navbar';
import { Footer } from '@/components/Footer';
import { MenuExplorer, CategoryData } from '@/components/MenuExplorer';
import { useCart } from '@/context/CartContext';
import { useToast } from '@/context/ToastContext';
import { CallWaiterModal } from '@/components/CallWaiterModal';
import { 
  QrCode, 
  Bell, 
  ShoppingBag, 
  Sparkles, 
  MapPin, 
  AlertCircle,
  Clock
} from 'lucide-react';

export default function TableLandingPage() {
  const params = useParams();
  const token = params.token as string;
  const { setTableContext, itemCount, totalAmount, setIsOpen: openCart } = useCart();
  const { showToast } = useToast();

  const [table, setTable] = useState<any>(null);
  const [categories, setCategories] = useState<CategoryData[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [waiterModalOpen, setWaiterModalOpen] = useState(false);

  useEffect(() => {
    if (!token) return;

    // 1. Resolve Table from token
    fetch(`/api/tables/by-token/${token}`)
      .then((res) => res.json())
      .then((data) => {
        if (data.table) {
          setTable(data.table);
          // Set active table session in CartContext & LocalStorage
          setTableContext(data.table.id, data.table.tableNumber, data.table.name);
          showToast(`Welcome! You are seated at Table #${data.table.tableNumber}`, 'info');
        } else {
          setError(data.error || 'Invalid table QR code');
        }
      })
      .catch(() => setError('Failed to verify table QR'))
      .finally(() => setLoading(false));

    // 2. Fetch Menu
    fetch('/api/menu?onlyAvailable=true')
      .then((res) => res.json())
      .then((data) => {
        if (data.categories) setCategories(data.categories);
      })
      .catch(() => {});
  }, [token]);

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <div className="text-center space-y-3">
          <span className="w-8 h-8 border-2 border-gold border-t-transparent rounded-full animate-spin inline-block" />
          <p className="text-xs text-gold uppercase tracking-widest font-mono">
            Connecting to Table QR...
          </p>
        </div>
      </div>
    );
  }

  if (error || !table) {
    return (
      <>
        <Navbar />
        <main className="flex-1 max-w-md mx-auto py-20 px-4 text-center space-y-4">
          <AlertCircle className="w-12 h-12 text-rose-400 mx-auto" />
          <h2 className="text-xl font-serif font-bold text-white">QR Code Not Recognized</h2>
          <p className="text-xs text-gray-400">
            {error || 'This table QR code is invalid or has been archived.'}
          </p>
        </main>
        <Footer />
      </>
    );
  }

  return (
    <>
      <Navbar />

      <main className="flex-1 pb-24">
        {/* Table Welcome Banner */}
        <section className="bg-gradient-to-b from-surface-card to-background border-b border-surface-border py-8 px-4 sm:px-6">
          <div className="max-w-4xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-6">
            <div className="flex items-center gap-4 text-center sm:text-left">
              <div className="w-14 h-14 rounded-2xl bg-gold/15 border border-gold/40 flex items-center justify-center text-gold font-serif font-bold text-2xl shrink-0 shadow-lg">
                {table.tableNumber}
              </div>
              <div>
                <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-emerald-950/60 border border-emerald-700/50 text-emerald-300 text-[10px] font-bold uppercase tracking-wider mb-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                  Table Active • {table.section}
                </div>
                <h1 className="text-xl sm:text-2xl font-serif font-bold text-white">
                  {table.name}
                </h1>
                <p className="text-xs text-gray-400">
                  Tap any dish to order directly to your table, or summon your server anytime.
                </p>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="flex items-center gap-3 w-full sm:w-auto">
              <button
                onClick={() => setWaiterModalOpen(true)}
                className="flex-1 sm:flex-initial px-5 py-3 rounded-xl bg-surface hover:bg-surface-hover border border-gold/40 hover:border-gold text-gold font-bold text-xs uppercase tracking-wider transition-all flex items-center justify-center gap-2 shadow-md"
              >
                <Bell className="w-4 h-4" />
                <span>Call Waiter</span>
              </button>

              <button
                onClick={() => openCart(true)}
                className="flex-1 sm:flex-initial px-5 py-3 rounded-xl bg-gold hover:bg-gold-hover text-background font-bold text-xs uppercase tracking-wider transition-all flex items-center justify-center gap-2 shadow-lg shadow-gold/20"
              >
                <ShoppingBag className="w-4 h-4" />
                <span>View Plate ({itemCount})</span>
              </button>
            </div>
          </div>
        </section>

        {/* Digital Menu */}
        <MenuExplorer
          categories={categories}
          title="Digital Table Ordering"
          subtitle="Orders placed here are routed instantaneously to our executive kitchen display."
        />
      </main>

      {/* Mobile Sticky Floating Order Bar */}
      {itemCount > 0 && (
        <div className="fixed bottom-4 inset-x-4 max-w-md mx-auto z-30 sm:hidden">
          <button
            onClick={() => openCart(true)}
            className="w-full py-3.5 px-5 bg-gold text-background rounded-2xl shadow-2xl font-bold text-sm flex items-center justify-between uppercase tracking-wider animate-bounce"
          >
            <span className="flex items-center gap-2">
              <ShoppingBag className="w-5 h-5" />
              {itemCount} {itemCount === 1 ? 'Dish' : 'Dishes'}
            </span>
            <span>View & Order • ${totalAmount.toFixed(2)} →</span>
          </button>
        </div>
      )}

      <CallWaiterModal
        isOpen={waiterModalOpen}
        onClose={() => setWaiterModalOpen(false)}
      />

      <Footer />
    </>
  );
}

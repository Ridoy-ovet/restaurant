import React from 'react';
import { prisma } from '@/lib/prisma';
import { Navbar } from '@/components/Navbar';
import { Footer } from '@/components/Footer';
import { MenuExplorer } from '@/components/MenuExplorer';

export const revalidate = 0;

export default async function MenuPage() {
  const categories = await prisma.menuCategory.findMany({
    where: { isActive: true },
    orderBy: { displayOrder: 'asc' },
    include: {
      items: {
        where: { isAvailable: true },
        orderBy: { displayOrder: 'asc' },
      },
    },
  });

  return (
    <>
      <Navbar />
      <main className="flex-1 py-12">
        <MenuExplorer
          categories={categories}
          title="Digital Degustation & Menu"
          subtitle="Explore our complete kitchen catalog. Add dishes to your table cart for instant preparation."
        />
      </main>
      <Footer />
    </>
  );
}

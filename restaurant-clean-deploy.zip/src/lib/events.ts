import { EventEmitter } from 'events';

// Global singleton event emitter
const globalForEvents = globalThis as unknown as { appEmitter: EventEmitter | undefined };

export const appEmitter = globalForEvents.appEmitter ?? new EventEmitter();
appEmitter.setMaxListeners(100);

if (process.env.NODE_ENV !== 'production') globalForEvents.appEmitter = appEmitter;

export type EventType =
  | 'ORDER_CREATED'
  | 'ORDER_STATUS_CHANGED'
  | 'WAITER_CALLED'
  | 'WAITER_RESOLVED'
  | 'RESERVATION_CREATED'
  | 'RESERVATION_UPDATED'
  | 'TABLE_STATUS_CHANGED';

export interface RealtimeEvent {
  type: EventType;
  timestamp: string;
  data: any;
}

export function broadcastEvent(type: EventType, data: any) {
  const payload: RealtimeEvent = {
    type,
    timestamp: new Date().toISOString(),
    data,
  };
  appEmitter.emit('restaurant_event', payload);
}

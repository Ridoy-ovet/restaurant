export interface EmailPayload {
  to: string;
  subject: string;
  html: string;
  text?: string;
}

export async function sendEmail(payload: EmailPayload): Promise<{ success: boolean; messageId?: string }> {
  const simulatedId = `msg_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`;
  
  // Production transactional email dispatch / logging
  console.log('----------------------------------------------------');
  console.log(`✉️  [TRANSACTIONAL EMAIL DISPATCH] -> ${payload.to}`);
  console.log(`📌 Subject: ${payload.subject}`);
  console.log(`🆔 Message ID: ${simulatedId}`);
  console.log('----------------------------------------------------');

  return { success: true, messageId: simulatedId };
}

export function renderReservationConfirmationEmail(params: {
  restaurantName: string;
  guestName: string;
  reservationCode: string;
  date: string;
  timeSlot: string;
  partySize: number;
  specialRequests?: string | null;
  manageUrl: string;
}): string {
  return `
  <!DOCTYPE html>
  <html>
  <head>
    <meta charset="utf-8">
    <title>Reservation Confirmed - ${params.restaurantName}</title>
    <style>
      body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; background-color: #0c0e12; color: #f3f4f6; margin: 0; padding: 40px 20px; }
      .container { max-width: 580px; margin: 0 auto; background: #141820; border: 1px solid #252e3d; border-radius: 12px; padding: 36px; }
      .logo { font-size: 22px; font-weight: 700; letter-spacing: 2px; color: #d4af37; text-transform: uppercase; margin-bottom: 24px; text-align: center; }
      h1 { font-size: 24px; color: #ffffff; margin-bottom: 12px; font-weight: 600; text-align: center; }
      p { color: #9ca3af; line-height: 1.6; font-size: 15px; }
      .card { background: #1a202c; border-radius: 8px; border: 1px solid #2d3748; padding: 20px; margin: 24px 0; }
      .row { display: flex; justify-content: space-between; padding: 8px 0; border-bottom: 1px solid #2d3748; }
      .row:last-child { border-bottom: none; }
      .label { color: #9ca3af; font-size: 14px; }
      .value { color: #ffffff; font-weight: 600; font-size: 14px; }
      .btn { display: block; width: 220px; margin: 30px auto 10px; background: #d4af37; color: #0c0e12; text-decoration: none; text-align: center; padding: 14px 20px; font-weight: 700; border-radius: 6px; letter-spacing: 0.5px; }
      .footer { text-align: center; font-size: 12px; color: #6b7280; margin-top: 30px; }
    </style>
  </head>
  <body>
    <div class="container">
      <div class="logo">${params.restaurantName}</div>
      <h1>Reservation Confirmed</h1>
      <p>Dear ${params.guestName},</p>
      <p>Your table reservation has been accepted and confirmed. We look forward to offering you an exceptional culinary experience.</p>
      
      <div class="card">
        <div class="row"><span class="label">Confirmation Reference</span><span class="value" style="color: #d4af37; font-family: monospace; font-size: 16px;">${params.reservationCode}</span></div>
        <div class="row"><span class="label">Date</span><span class="value">${params.date}</span></div>
        <div class="row"><span class="label">Seating Time</span><span class="value">${params.timeSlot}</span></div>
        <div class="row"><span class="label">Party Size</span><span class="value">${params.partySize} Guests</span></div>
        ${params.specialRequests ? `<div class="row"><span class="label">Special Requests</span><span class="value">${params.specialRequests}</span></div>` : ''}
      </div>

      <a href="${params.manageUrl}" class="btn">View & Manage Booking</a>
      
      <p style="font-size: 13px; text-align: center; margin-top: 20px;">Need to adjust or cancel? You can modify your reservation at any time using the link above.</p>

      <div class="footer">
        © ${new Date().getFullYear()} ${params.restaurantName}. All rights reserved.
      </div>
    </div>
  </body>
  </html>
  `;
}

export function renderOrderConfirmationEmail(params: {
  restaurantName: string;
  orderNumber: string;
  tableName: string;
  totalAmount: number;
  items: { name: string; quantity: number; unitPrice: number }[];
  statusUrl: string;
}): string {
  const itemsHtml = params.items
    .map(
      (item) => `
    <div style="display: flex; justify-content: space-between; padding: 8px 0; border-bottom: 1px solid #2d3748;">
      <span style="color: #ffffff;">${item.quantity}x ${item.name}</span>
      <span style="color: #d4af37; font-weight: 600;">$${(item.quantity * item.unitPrice).toFixed(2)}</span>
    </div>
  `
    )
    .join('');

  return `
  <!DOCTYPE html>
  <html>
  <head>
    <meta charset="utf-8">
    <title>Order Confirmed - ${params.orderNumber}</title>
  </head>
  <body style="font-family: -apple-system, sans-serif; background-color: #0c0e12; color: #f3f4f6; padding: 40px 20px;">
    <div style="max-width: 540px; margin: 0 auto; background: #141820; border: 1px solid #252e3d; border-radius: 12px; padding: 32px;">
      <h2 style="color: #d4af37; text-align: center; margin-top: 0;">${params.restaurantName}</h2>
      <h3 style="text-align: center; color: #ffffff; margin-bottom: 24px;">Order Received: ${params.orderNumber}</h3>
      <p style="color: #9ca3af;">Your order for <strong>${params.tableName}</strong> has been transmitted to our kitchen brigade and is being prepared.</p>
      
      <div style="background: #1a202c; padding: 18px; border-radius: 8px; margin: 20px 0;">
        ${itemsHtml}
        <div style="display: flex; justify-content: space-between; padding-top: 14px; margin-top: 10px; border-top: 2px solid #2d3748; font-size: 16px; font-weight: 700;">
          <span style="color: #ffffff;">Total</span>
          <span style="color: #d4af37;">$${params.totalAmount.toFixed(2)}</span>
        </div>
      </div>

      <div style="text-align: center; margin-top: 24px;">
        <a href="${params.statusUrl}" style="background: #d4af37; color: #0c0e12; text-decoration: none; padding: 12px 24px; font-weight: 700; border-radius: 6px; display: inline-block;">Track Order Status</a>
      </div>
    </div>
  </body>
  </html>
  `;
}

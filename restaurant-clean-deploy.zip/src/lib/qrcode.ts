import QRCode from 'qrcode';

export async function generateQRCodeDataUrl(text: string): Promise<string> {
  try {
    return await QRCode.toDataURL(text, {
      width: 320,
      margin: 2,
      color: {
        dark: '#0c0e12',
        light: '#ffffff',
      },
    });
  } catch (err) {
    console.error('Failed to generate QR DataURL:', err);
    throw err;
  }
}

export async function generateQRCodeSvg(text: string): Promise<string> {
  try {
    return await QRCode.toString(text, {
      type: 'svg',
      margin: 2,
      color: {
        dark: '#0c0e12',
        light: '#ffffff',
      },
    });
  } catch (err) {
    console.error('Failed to generate QR SVG:', err);
    throw err;
  }
}

'use client';

import React from 'react';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { 
  LayoutDashboard, 
  ChefHat, 
  Calendar, 
  Grid, 
  UtensilsCrossed, 
  Sparkles, 
  Settings, 
  BarChart3, 
  ShieldCheck, 
  ArrowLeft,
  LogOut
} from 'lucide-react';

interface AdminSidebarProps {
  userRole?: string;
  userName?: string;
}

export function AdminSidebar({ userRole = 'STAFF', userName = 'Staff Member' }: AdminSidebarProps) {
  const pathname = usePathname();
  const router = useRouter();

  const handleLogout = async () => {
    try {
      await fetch('/api/auth/logout', { method: 'POST' });
      router.push('/login');
      router.refresh();
    } catch {}
  };

  const navItems = [
    { label: 'Operations Overview', href: '/admin', icon: LayoutDashboard, roles: ['SUPER_ADMIN', 'MANAGER', 'STAFF'] },
    { label: 'Live Kitchen Orders', href: '/admin/orders', icon: ChefHat, roles: ['SUPER_ADMIN', 'MANAGER', 'STAFF'] },
    { label: 'Reservations', href: '/admin/reservations', icon: Calendar, roles: ['SUPER_ADMIN', 'MANAGER', 'STAFF'] },
    { label: 'Floor Plan & QR Codes', href: '/admin/tables', icon: Grid, roles: ['SUPER_ADMIN', 'MANAGER', 'STAFF'] },
    { label: 'Menu Catalog', href: '/admin/menu', icon: UtensilsCrossed, roles: ['SUPER_ADMIN', 'MANAGER'] },
    { label: 'Promotions & Banners', href: '/admin/promotions', icon: Sparkles, roles: ['SUPER_ADMIN', 'MANAGER'] },
    { label: 'Website & Service Hours', href: '/admin/settings', icon: Settings, roles: ['SUPER_ADMIN', 'MANAGER'] },
    { label: 'Analytics', href: '/admin/analytics', icon: BarChart3, roles: ['SUPER_ADMIN', 'MANAGER'] },
    { label: 'Audit Logs', href: '/admin/audit', icon: ShieldCheck, roles: ['SUPER_ADMIN'] },
  ];

  return (
    <aside className="w-64 bg-surface-card border-r border-surface-border flex flex-col justify-between shrink-0 h-screen sticky top-0">
      <div className="p-5 space-y-6">
        {/* Brand Header */}
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl border border-gold/40 flex items-center justify-center bg-surface text-gold font-serif font-bold text-lg">
            É
          </div>
          <div>
            <h2 className="text-sm font-serif font-bold tracking-wider text-white">
              L'ÉTOILE
            </h2>
            <p className="text-[10px] uppercase tracking-widest text-gold font-mono">
              Management Portal
            </p>
          </div>
        </div>

        {/* User Card */}
        <div className="p-3 bg-surface rounded-xl border border-surface-border flex items-center justify-between">
          <div className="min-w-0">
            <p className="text-xs font-semibold text-white truncate">{userName}</p>
            <span className="inline-block text-[9px] font-bold px-1.5 py-0.5 rounded bg-gold/15 text-gold border border-gold/30 mt-0.5">
              {userRole}
            </span>
          </div>
        </div>

        {/* Navigation List */}
        <nav className="space-y-1">
          {navItems
            .filter((item) => item.roles.includes(userRole))
            .map((item) => {
              const active = pathname === item.href;
              const Icon = item.icon;

              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className={`flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-medium transition-all ${
                    active
                      ? 'bg-gold text-background font-bold shadow-md shadow-gold/20'
                      : 'text-gray-400 hover:text-white hover:bg-surface-hover'
                  }`}
                >
                  <Icon className="w-4 h-4 shrink-0" />
                  <span>{item.label}</span>
                </Link>
              );
            })}
        </nav>
      </div>

      {/* Bottom Actions */}
      <div className="p-5 border-t border-surface-border space-y-2">
        <Link
          href="/"
          className="flex items-center gap-2 px-3 py-2 rounded-xl text-xs text-gray-400 hover:text-white hover:bg-surface-hover transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Public Website</span>
        </Link>

        <button
          onClick={handleLogout}
          className="w-full flex items-center gap-2 px-3 py-2 rounded-xl text-xs text-rose-400 hover:bg-rose-950/40 transition-colors"
        >
          <LogOut className="w-4 h-4" />
          <span>Sign Out</span>
        </button>
      </div>
    </aside>
  );
}

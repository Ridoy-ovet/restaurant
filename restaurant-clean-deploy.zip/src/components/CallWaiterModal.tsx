'use client';

import React, { useState, useEffect } from 'react';
import { useCart } from '@/context/CartContext';
import { useToast } from '@/context/ToastContext';
import { Bell, CheckCircle2, Clock, X, AlertTriangle } from 'lucide-react';

interface CallWaiterModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function CallWaiterModal({ isOpen, onClose }: CallWaiterModalProps) {
  const { tableId, tableNumber, tableName } = useCart();
  const { showToast } = useToast();
  const [loading, setLoading] = useState(false);
  const [cooldown, setCooldown] = useState(0);
  const [calledSuccess, setCalledSuccess] = useState(false);

  // Tick down cooldown timer
  useEffect(() => {
    if (cooldown <= 0) return;
    const timer = setInterval(() => {
      setCooldown((prev) => prev - 1);
    }, 1000);
    return () => clearInterval(timer);
  }, [cooldown]);

  if (!isOpen) return null;

  const handleCallWaiter = async () => {
    if (!tableId) {
      showToast('No active table detected. Please scan a table QR code first.', 'warning');
      return;
    }

    setLoading(true);
    try {
      const res = await fetch('/api/waiter-calls', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ tableId }),
      });

      const data = await res.json();

      if (!res.ok) {
        if (data.remainingSeconds) {
          setCooldown(data.remainingSeconds);
        }
        showToast(data.error || 'Unable to call waiter right now', 'warning');
        return;
      }

      setCalledSuccess(true);
      setCooldown(data.cooldownSeconds || 120);
      showToast(data.message, 'success');
    } catch (err) {
      showToast('Network error while requesting staff.', 'error');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in">
      <div className="bg-surface-card border border-surface-border rounded-2xl max-w-md w-full p-6 shadow-2xl relative text-center">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-gray-400 hover:text-white p-1 rounded-lg"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="w-16 h-16 rounded-full bg-gold/15 border border-gold/40 flex items-center justify-center mx-auto mb-4 text-gold">
          <Bell className="w-8 h-8" />
        </div>

        <h3 className="text-xl font-serif font-bold text-white mb-1">
          Call Head Waiter
        </h3>
        
        {tableNumber ? (
          <p className="text-sm text-gold font-medium mb-4">
            Table {tableNumber} {tableName ? `• ${tableName}` : ''}
          </p>
        ) : (
          <div className="p-3 bg-amber-950/40 border border-amber-800/40 rounded-xl mb-4 text-amber-300 text-xs flex items-center gap-2 text-left">
            <AlertTriangle className="w-5 h-5 shrink-0 text-amber-400" />
            <span>You haven't scanned a table QR code yet. Please scan the QR code located on your table to summon staff directly to your seat.</span>
          </div>
        )}

        <p className="text-gray-400 text-xs sm:text-sm mb-6 leading-relaxed">
          Need wine recommendations, tableware assistance, or your bill? Press below and our floor sommelier or captain will attend to your table immediately.
        </p>

        {calledSuccess ? (
          <div className="bg-emerald-950/40 border border-emerald-800/50 rounded-xl p-4 mb-6 text-emerald-300">
            <div className="flex items-center justify-center gap-2 font-semibold text-sm mb-1">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              Staff Alerted
            </div>
            <p className="text-xs text-gray-300">
              Your request was transmitted to our floor terminals. A waiter is currently on their way.
            </p>
          </div>
        ) : null}

        {cooldown > 0 ? (
          <div className="flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-surface-hover border border-surface-border text-gray-300 text-xs font-mono mb-4">
            <Clock className="w-4 h-4 text-gold animate-spin" />
            <span>Cooldown active: please allow {cooldown}s for staff to arrive</span>
          </div>
        ) : (
          <button
            onClick={handleCallWaiter}
            disabled={loading || !tableId}
            className="w-full py-3.5 rounded-xl bg-gold hover:bg-gold-hover disabled:opacity-40 disabled:pointer-events-none text-background font-bold text-sm uppercase tracking-wider transition-all shadow-lg hover:shadow-gold/20 flex items-center justify-center gap-2"
          >
            {loading ? (
              <span className="inline-block w-4 h-4 border-2 border-background border-t-transparent rounded-full animate-spin" />
            ) : (
              <Bell className="w-4 h-4" />
            )}
            Alert Staff Now
          </button>
        )}

        <button
          onClick={onClose}
          className="mt-3 text-xs text-gray-400 hover:text-white transition-colors"
        >
          Close Window
        </button>
      </div>
    </div>
  );
}

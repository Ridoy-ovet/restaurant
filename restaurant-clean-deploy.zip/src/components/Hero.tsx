'use client';

import React from 'react';
import Link from 'next/link';
import { Calendar, Utensils, QrCode, Sparkles, ChevronRight } from 'lucide-react';

interface HeroProps {
  settings?: {
    name?: string;
    tagline?: string;
    description?: string;
    heroBanner?: string;
  };
}

export function Hero({ settings }: HeroProps) {
  const name = settings?.name || "L'Étoile Modern Brasserie";
  const tagline = settings?.tagline || "Artisanal Gastronomy & Contemporary Dining";
  const description = settings?.description || "An immersive culinary journey celebrating wood-fired techniques, rare seasonal harvests, and cellar-reserve pairings in an architecturally refined space.";
  const banner = settings?.heroBanner || "https://images.unsplash.com/photo-1544025162-d76694265947?q=80&w=1600&auto=format&fit=crop";

  return (
    <section className="relative min-h-[90vh] flex items-center justify-center overflow-hidden">
      {/* Background Image with optimized dark gradient overlay */}
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat transition-transform duration-1000 scale-105"
        style={{ backgroundImage: `url('${banner}')` }}
      >
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/80 to-background/40" />
        <div className="absolute inset-0 bg-black/40 backdrop-blur-[1px]" />
      </div>

      <div className="relative z-10 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-20 text-center flex flex-col items-center">
        {/* Subtle pill badge */}
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-surface-card/80 border border-gold/40 text-gold text-xs font-semibold uppercase tracking-widest mb-8 backdrop-blur-md shadow-lg">
          <Sparkles className="w-3.5 h-3.5" />
          <span>Seasonal Autumn Degustation Now Open</span>
        </div>

        {/* Main Title */}
        <h1 className="text-4xl sm:text-6xl lg:text-7xl font-serif font-bold text-white tracking-tight leading-[1.1] max-w-4xl">
          {name}
        </h1>

        <p className="mt-4 text-lg sm:text-xl font-serif italic text-gold tracking-wide max-w-2xl">
          "{tagline}"
        </p>

        <p className="mt-6 text-sm sm:text-base text-gray-300 max-w-2xl leading-relaxed font-light">
          {description}
        </p>

        {/* Dual Primary Call to Actions */}
        <div className="mt-10 flex flex-col sm:flex-row items-center gap-4 w-full sm:w-auto">
          <Link
            href="/reservation"
            className="w-full sm:w-auto px-8 py-4 rounded-full bg-gold hover:bg-gold-hover text-background font-bold text-sm uppercase tracking-widest transition-all shadow-xl hover:shadow-gold/20 flex items-center justify-center gap-3"
          >
            <Calendar className="w-4 h-4" />
            <span>Book a Table</span>
          </Link>

          <Link
            href="/menu"
            className="w-full sm:w-auto px-8 py-4 rounded-full bg-surface-card/90 hover:bg-surface-hover border border-surface-border hover:border-gold/50 text-white font-semibold text-sm uppercase tracking-widest transition-all backdrop-blur-md flex items-center justify-center gap-3"
          >
            <Utensils className="w-4 h-4 text-gold" />
            <span>Explore Menu</span>
          </Link>
        </div>

        {/* Quick Table QR Hint for In-Restaurant Diners */}
        <div className="mt-12 pt-8 border-t border-white/10 flex flex-wrap justify-center items-center gap-6 sm:gap-12 text-xs text-gray-400 font-medium">
          <div className="flex items-center gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-gold" />
            <span>Michelin Guide Selection 2026</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-gold" />
            <span>Wood-Fired Binchotan Hearth</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-gold" />
            <span>Grand Sommelier Cellar</span>
          </div>
        </div>
      </div>
    </section>
  );
}

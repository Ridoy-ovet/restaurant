'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { useCart } from '@/context/CartContext';
import { 
  ShoppingBag, 
  Bell, 
  Menu as MenuIcon, 
  X, 
  Calendar, 
  Utensils, 
  User, 
  LogOut, 
  ShieldAlert,
  Sparkles
} from 'lucide-react';
import { CallWaiterModal } from './CallWaiterModal';

export function Navbar() {
  const pathname = usePathname();
  const router = useRouter();
  const { itemCount, tableId, tableNumber, tableName, setIsOpen: openCart } = useCart();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [waiterModalOpen, setWaiterModalOpen] = useState(false);
  const [user, setUser] = useState<{ name: string; role: string; email: string } | null>(null);
  const [userMenuOpen, setUserMenuOpen] = useState(false);

  useEffect(() => {
    fetch('/api/auth/me')
      .then((res) => res.json())
      .then((data) => {
        if (data?.user) setUser(data.user);
      })
      .catch(() => {});
  }, [pathname]);

  const handleLogout = async () => {
    try {
      await fetch('/api/auth/logout', { method: 'POST' });
      setUser(null);
      router.push('/');
      router.refresh();
    } catch {}
  };

  const navLinks = [
    { label: 'Home', href: '/' },
    { label: 'Menu', href: '/menu' },
    { label: 'Reservations', href: '/reservation' },
  ];

  const isStaff = user && ['SUPER_ADMIN', 'MANAGER', 'STAFF'].includes(user.role);

  return (
    <>
      <header className="sticky top-0 z-40 w-full bg-background/85 backdrop-blur-md border-b border-surface-border transition-all">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-3 group">
            <div className="w-10 h-10 rounded-full border border-gold/40 flex items-center justify-center bg-surface-card group-hover:border-gold transition-colors">
              <span className="text-gold font-serif font-bold text-xl leading-none">É</span>
            </div>
            <div>
              <span className="text-lg sm:text-xl font-serif font-bold tracking-widest text-foreground block group-hover:text-gold transition-colors">
                L'ÉTOILE
              </span>
              <span className="text-[10px] uppercase tracking-[0.25em] text-gray-400 block -mt-1">
                Modern Brasserie
              </span>
            </div>
          </Link>

          {/* Desktop Navigation Links */}
          <nav className="hidden md:flex items-center gap-8">
            {navLinks.map((link) => {
              const active = pathname === link.href;
              return (
                <Link
                  key={link.href}
                  href={link.href}
                  className={`text-sm tracking-wider uppercase font-medium transition-colors ${
                    active ? 'text-gold' : 'text-gray-300 hover:text-white'
                  }`}
                >
                  {link.label}
                </Link>
              );
            })}
          </nav>

          {/* Right Action Icons */}
          <div className="flex items-center gap-3 sm:gap-4">
            {/* Table Context Indicator & Call Waiter button */}
            {tableId && (
              <div className="flex items-center gap-2 bg-surface-card border border-gold/40 rounded-full px-3 py-1.5 shadow-sm">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                <span className="text-xs font-semibold text-gold tracking-wide">
                  Table {tableNumber}
                </span>
                <button
                  onClick={() => setWaiterModalOpen(true)}
                  className="ml-1 text-xs bg-gold/15 hover:bg-gold/30 text-gold font-medium px-2 py-0.5 rounded-full flex items-center gap-1 transition-colors"
                  title="Call Head Waiter"
                >
                  <Bell className="w-3 h-3" />
                  <span className="hidden sm:inline">Call Waiter</span>
                </button>
              </div>
            )}

            {/* Cart Button */}
            <button
              onClick={() => openCart(true)}
              className="relative p-2.5 rounded-full bg-surface-card border border-surface-border hover:border-gold/50 text-foreground transition-colors"
              aria-label="View Order Cart"
            >
              <ShoppingBag className="w-5 h-5" />
              {itemCount > 0 && (
                <span className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-gold text-background font-bold text-xs flex items-center justify-center shadow-lg animate-scale">
                  {itemCount}
                </span>
              )}
            </button>

            {/* Reservation Quick CTA (Desktop) */}
            <Link
              href="/reservation"
              className="hidden lg:flex items-center gap-2 px-4 py-2 rounded-full bg-gold hover:bg-gold-hover text-background font-semibold text-xs tracking-wider uppercase transition-all shadow-md hover:shadow-gold/20"
            >
              <Calendar className="w-3.5 h-3.5" />
              Book Table
            </Link>

            {/* User Account / Admin Access */}
            {user ? (
              <div className="relative">
                <button
                  onClick={() => setUserMenuOpen(!userMenuOpen)}
                  className="flex items-center gap-2 p-1.5 sm:px-3 sm:py-1.5 rounded-full bg-surface-card border border-surface-border hover:border-gold/50 text-xs font-medium transition-colors"
                >
                  <div className="w-7 h-7 rounded-full bg-gold/20 border border-gold/40 flex items-center justify-center text-gold font-bold">
                    {user.name.charAt(0)}
                  </div>
                  <span className="hidden sm:inline max-w-[100px] truncate text-gray-200">
                    {user.name.split(' ')[0]}
                  </span>
                </button>

                {userMenuOpen && (
                  <div className="absolute right-0 mt-2 w-52 bg-surface-card border border-surface-border rounded-xl shadow-2xl py-2 z-50 animate-in fade-in slide-in-from-top-2">
                    <div className="px-4 py-2 border-b border-surface-border">
                      <p className="text-xs font-semibold text-white truncate">{user.name}</p>
                      <p className="text-[11px] text-gray-400 truncate">{user.email}</p>
                      {isStaff && (
                        <span className="inline-block mt-1 text-[10px] font-bold px-2 py-0.5 rounded bg-gold/15 text-gold border border-gold/30">
                          {user.role}
                        </span>
                      )}
                    </div>

                    {isStaff && (
                      <Link
                        href="/admin"
                        onClick={() => setUserMenuOpen(false)}
                        className="flex items-center gap-2 px-4 py-2.5 text-xs text-gold font-medium hover:bg-surface-hover transition-colors"
                      >
                        <ShieldAlert className="w-4 h-4" />
                        Admin Dashboard
                      </Link>
                    )}

                    <Link
                      href="/reservation"
                      onClick={() => setUserMenuOpen(false)}
                      className="flex items-center gap-2 px-4 py-2.5 text-xs text-gray-300 hover:text-white hover:bg-surface-hover transition-colors"
                    >
                      <Calendar className="w-4 h-4" />
                      My Reservations
                    </Link>

                    <button
                      onClick={() => {
                        setUserMenuOpen(false);
                        handleLogout();
                      }}
                      className="w-full flex items-center gap-2 px-4 py-2.5 text-xs text-rose-400 hover:bg-rose-950/30 transition-colors"
                    >
                      <LogOut className="w-4 h-4" />
                      Sign Out
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <Link
                href="/login"
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-full border border-surface-border hover:border-gold/50 text-xs font-medium text-gray-300 hover:text-white transition-colors"
              >
                <User className="w-4 h-4" />
                <span className="hidden sm:inline">Sign In</span>
              </Link>
            )}

            {/* Mobile Hamburger Button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2 rounded-lg text-gray-400 hover:text-white hover:bg-surface-card transition-colors"
              aria-label="Toggle Navigation Menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <MenuIcon className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation Drawer */}
        {mobileMenuOpen && (
          <div className="md:hidden border-t border-surface-border bg-background/95 backdrop-blur-lg px-4 pt-3 pb-6 space-y-3 animate-in fade-in">
            {navLinks.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                onClick={() => setMobileMenuOpen(false)}
                className="block py-2 text-sm font-medium uppercase tracking-wider text-gray-300 hover:text-gold transition-colors"
              >
                {link.label}
              </Link>
            ))}
            {isStaff && (
              <Link
                href="/admin"
                onClick={() => setMobileMenuOpen(false)}
                className="block py-2 text-sm font-semibold uppercase tracking-wider text-gold"
              >
                Admin & Operations Dashboard
              </Link>
            )}
            <div className="pt-2 border-t border-surface-border flex gap-2">
              <Link
                href="/reservation"
                onClick={() => setMobileMenuOpen(false)}
                className="flex-1 py-2.5 text-center rounded-lg bg-gold text-background font-bold text-xs uppercase tracking-wider"
              >
                Reserve Table
              </Link>
              {tableId && (
                <button
                  onClick={() => {
                    setMobileMenuOpen(false);
                    setWaiterModalOpen(true);
                  }}
                  className="flex-1 py-2.5 text-center rounded-lg border border-gold text-gold font-bold text-xs uppercase tracking-wider"
                >
                  Call Waiter
                </button>
              )}
            </div>
          </div>
        )}
      </header>

      {/* Call Waiter Modal Component */}
      <CallWaiterModal
        isOpen={waiterModalOpen}
        onClose={() => setWaiterModalOpen(false)}
      />
    </>
  );
}

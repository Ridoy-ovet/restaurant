'use client';

import React, { useState, useMemo } from 'react';
import Image from 'next/image';
import { useCart } from '@/context/CartContext';
import { useToast } from '@/context/ToastContext';
import { Search, Plus, Sparkles, Check, Flame, Wine, Leaf } from 'lucide-react';

export interface MenuItemData {
  id: string;
  name: string;
  description: string;
  price: number;
  discountPrice?: number | null;
  imageUrl?: string | null;
  isAvailable: boolean;
  isFeatured: boolean;
  tags?: string | null;
  dietary?: string | null;
  categoryId: string;
}

export interface CategoryData {
  id: string;
  name: string;
  slug: string;
  description?: string | null;
  items: MenuItemData[];
}

interface MenuExplorerProps {
  categories: CategoryData[];
  initialCategory?: string;
  title?: string;
  subtitle?: string;
}

export function MenuExplorer({
  categories,
  initialCategory = 'all',
  title = 'Culinary Repertoire',
  subtitle = 'Curated seasonal gastronomy, fresh artisanal ingredients, and wood-fired preparations.',
}: MenuExplorerProps) {
  const { addItem } = useCart();
  const { showToast } = useToast();
  const [selectedCategory, setSelectedCategory] = useState<string>(initialCategory);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDiet, setSelectedDiet] = useState<string>('all');

  // Filter items
  const filteredCategories = useMemo(() => {
    return categories
      .filter((cat) => (selectedCategory === 'all' ? true : cat.slug === selectedCategory))
      .map((cat) => ({
        ...cat,
        items: cat.items.filter((item) => {
          // Search match
          const matchesSearch =
            searchQuery.trim() === '' ||
            item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
            item.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
            (item.tags && item.tags.toLowerCase().includes(searchQuery.toLowerCase()));

          // Dietary match
          const matchesDiet =
            selectedDiet === 'all' ||
            (item.dietary && item.dietary.toLowerCase().includes(selectedDiet.toLowerCase()));

          return matchesSearch && matchesDiet;
        }),
      }))
      .filter((cat) => cat.items.length > 0);
  }, [categories, selectedCategory, searchQuery, selectedDiet]);

  const handleAddToCart = (item: MenuItemData) => {
    if (!item.isAvailable) {
      showToast('This dish is currently out of stock.', 'warning');
      return;
    }
    const finalPrice = item.discountPrice ?? item.price;
    addItem({
      menuItemId: item.id,
      name: item.name,
      price: finalPrice,
      imageUrl: item.imageUrl,
    });
    showToast(`Added ${item.name} to your order.`, 'success');
  };

  const dietaryOptions = [
    { label: 'All Diets', value: 'all' },
    { label: 'Vegetarian', value: 'vegetarian' },
    { label: 'Vegan', value: 'vegan' },
    { label: 'Gluten-Free', value: 'gluten-free' },
  ];

  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto" id="menu">
      <div className="text-center max-w-2xl mx-auto mb-12">
        <span className="text-xs uppercase font-semibold tracking-widest text-gold block mb-2">
          À La Carte & Chef's Creations
        </span>
        <h2 className="text-3xl sm:text-4xl font-serif font-bold text-white tracking-tight">
          {title}
        </h2>
        <p className="mt-3 text-sm text-gray-400 font-light">
          {subtitle}
        </p>
      </div>

      {/* Category Pills & Filters */}
      <div className="space-y-4 mb-10">
        {/* Category Tabs */}
        <div className="flex items-center justify-start sm:justify-center gap-2 overflow-x-auto pb-2 scrollbar-none">
          <button
            onClick={() => setSelectedCategory('all')}
            className={`px-5 py-2 rounded-full text-xs font-semibold uppercase tracking-wider whitespace-nowrap transition-all ${
              selectedCategory === 'all'
                ? 'bg-gold text-background shadow-lg shadow-gold/20'
                : 'bg-surface-card border border-surface-border text-gray-300 hover:text-white hover:border-gray-600'
            }`}
          >
            All Courses
          </button>
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.slug)}
              className={`px-5 py-2 rounded-full text-xs font-semibold uppercase tracking-wider whitespace-nowrap transition-all ${
                selectedCategory === cat.slug
                  ? 'bg-gold text-background shadow-lg shadow-gold/20'
                  : 'bg-surface-card border border-surface-border text-gray-300 hover:text-white hover:border-gray-600'
              }`}
            >
              {cat.name}
            </button>
          ))}
        </div>

        {/* Search Bar & Dietary Filter */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 max-w-3xl mx-auto pt-2">
          {/* Search Input */}
          <div className="relative w-full sm:w-80">
            <Search className="w-4 h-4 text-gray-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search dishes, ingredients, wines..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 text-xs bg-surface-card border border-surface-border rounded-full text-white placeholder-gray-500 focus:outline-none focus:border-gold/60 transition-colors"
            />
          </div>

          {/* Dietary Selectors */}
          <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto pb-1 sm:pb-0">
            {dietaryOptions.map((opt) => (
              <button
                key={opt.value}
                onClick={() => setSelectedDiet(opt.value)}
                className={`px-3 py-1 rounded-full text-[11px] font-medium whitespace-nowrap transition-colors ${
                  selectedDiet === opt.value
                    ? 'bg-surface-border text-gold border border-gold/40'
                    : 'text-gray-400 hover:text-gray-200'
                }`}
              >
                {opt.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Menu Categories Grid */}
      <div className="space-y-16">
        {filteredCategories.length === 0 ? (
          <div className="text-center py-20 bg-surface-card/40 rounded-2xl border border-surface-border">
            <p className="text-base font-serif text-white">No dishes match your selection</p>
            <p className="text-xs text-gray-400 mt-1">Try refining your search terms or dietary filter.</p>
          </div>
        ) : (
          filteredCategories.map((cat) => (
            <div key={cat.id} className="space-y-6">
              {/* Category Header */}
              <div className="border-b border-surface-border pb-3 flex items-baseline justify-between">
                <div>
                  <h3 className="text-xl sm:text-2xl font-serif font-bold text-white tracking-wide">
                    {cat.name}
                  </h3>
                  {cat.description && (
                    <p className="text-xs text-gray-400 mt-0.5">{cat.description}</p>
                  )}
                </div>
                <span className="text-xs text-gold font-mono">
                  {cat.items.length} {cat.items.length === 1 ? 'item' : 'items'}
                </span>
              </div>

              {/* Items Card Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {cat.items.map((item) => {
                  const finalPrice = item.discountPrice ?? item.price;
                  const hasDiscount = item.discountPrice && item.discountPrice < item.price;

                  return (
                    <div
                      key={item.id}
                      className="group bg-surface-card rounded-2xl border border-surface-border hover:border-gold/40 transition-all duration-300 overflow-hidden flex flex-col justify-between"
                    >
                      {/* Image Thumbnail */}
                      {item.imageUrl && (
                        <div className="relative w-full h-48 overflow-hidden bg-surface">
                          <img
                            src={item.imageUrl}
                            alt={item.name}
                            loading="lazy"
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                          />
                          <div className="absolute inset-0 bg-gradient-to-t from-surface-card via-transparent to-transparent opacity-70" />
                          
                          {/* Badges */}
                          <div className="absolute top-3 left-3 flex flex-wrap gap-1.5">
                            {item.isFeatured && (
                              <span className="bg-gold text-background text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full shadow-md flex items-center gap-1">
                                <Sparkles className="w-2.5 h-2.5" /> Featured
                              </span>
                            )}
                            {hasDiscount && (
                              <span className="bg-rose-600 text-white text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full shadow-md">
                                Special Offer
                              </span>
                            )}
                          </div>

                          {!item.isAvailable && (
                            <div className="absolute inset-0 bg-black/75 backdrop-blur-[2px] flex items-center justify-center">
                              <span className="text-xs uppercase tracking-widest font-bold text-rose-400 bg-black/60 px-3 py-1 rounded-full border border-rose-800">
                                Sold Out Today
                              </span>
                            </div>
                          )}
                        </div>
                      )}

                      {/* Content */}
                      <div className="p-5 flex-1 flex flex-col justify-between">
                        <div>
                          <div className="flex justify-between items-start gap-2 mb-1.5">
                            <h4 className="text-base font-serif font-bold text-white group-hover:text-gold transition-colors">
                              {item.name}
                            </h4>
                            <div className="text-right shrink-0">
                              <span className="text-base font-serif font-bold text-gold">
                                ${finalPrice.toFixed(2)}
                              </span>
                              {hasDiscount && (
                                <span className="block text-[11px] text-gray-500 line-through">
                                  ${item.price.toFixed(2)}
                                </span>
                              )}
                            </div>
                          </div>

                          <p className="text-xs text-gray-400 font-light leading-relaxed mb-3">
                            {item.description}
                          </p>

                          {/* Dietary / Tags */}
                          {(item.dietary || item.tags) && (
                            <div className="flex flex-wrap gap-1.5 mb-4">
                              {item.dietary?.split(',').map((d) => (
                                <span
                                  key={d}
                                  className="text-[10px] font-medium px-2 py-0.5 rounded-full bg-surface border border-surface-border text-gray-300"
                                >
                                  {d.trim()}
                                </span>
                              ))}
                              {item.tags?.split(',').map((t) => (
                                <span
                                  key={t}
                                  className="text-[10px] font-medium px-2 py-0.5 rounded-full bg-gold/10 text-gold border border-gold/20"
                                >
                                  {t.trim()}
                                </span>
                              ))}
                            </div>
                          )}
                        </div>

                        {/* Add Button */}
                        <button
                          onClick={() => handleAddToCart(item)}
                          disabled={!item.isAvailable}
                          className="w-full mt-2 py-2.5 rounded-xl bg-surface-hover hover:bg-gold hover:text-background border border-surface-border hover:border-gold text-xs font-semibold uppercase tracking-wider text-gray-200 transition-all flex items-center justify-center gap-2 disabled:opacity-30 disabled:pointer-events-none"
                        >
                          <Plus className="w-3.5 h-3.5" />
                          <span>Add to Plate</span>
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          ))
        )}
      </div>
    </section>
  );
}

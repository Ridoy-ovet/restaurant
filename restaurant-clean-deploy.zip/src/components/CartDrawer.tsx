'use client';

import React, { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useCart } from '@/context/CartContext';
import { useToast } from '@/context/ToastContext';
import { X, Plus, Minus, Trash2, ShoppingBag, ArrowRight, Utensils, AlertCircle } from 'lucide-react';
import Image from 'next/image';

export function CartDrawer() {
  const router = useRouter();
  const {
    items,
    isOpen,
    setIsOpen,
    updateQuantity,
    updateNotes,
    removeItem,
    clearCart,
    totalAmount,
    tableId,
    tableNumber,
    tableName,
  } = useCart();
  const { showToast } = useToast();
  const [orderNotes, setOrderNotes] = useState('');
  const [guestName, setGuestName] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!isOpen) return null;

  const handleSubmitOrder = async () => {
    if (!tableId) {
      showToast('Please scan a table QR code before placing an in-restaurant order.', 'warning');
      return;
    }

    if (items.length === 0) {
      showToast('Your cart is empty. Add dishes from the menu first.', 'warning');
      return;
    }

    setIsSubmitting(true);
    try {
      const res = await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          tableId,
          guestName: guestName.trim() || undefined,
          notes: orderNotes.trim() || undefined,
          items: items.map((i) => ({
            menuItemId: i.menuItemId,
            quantity: i.quantity,
            notes: i.notes || undefined,
          })),
        }),
      });

      const data = await res.json();

      if (!res.ok) {
        showToast(data.error || 'Failed to place order', 'error');
        return;
      }

      showToast(`Order ${data.order.orderNumber} sent to kitchen brigade!`, 'success');
      clearCart();
      setIsOpen(false);
      router.push(`/order-status/${data.order.orderNumber}`);
    } catch (err) {
      showToast('Network error while transmitting order.', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-black/70 backdrop-blur-sm transition-opacity"
        onClick={() => setIsOpen(false)}
      />

      <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-surface-card border-l border-surface-border shadow-2xl flex flex-col">
          {/* Header */}
          <div className="p-5 border-b border-surface-border flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-full bg-gold/15 flex items-center justify-center text-gold">
                <ShoppingBag className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-base font-serif font-bold text-white">Your Selection</h2>
                {tableNumber ? (
                  <p className="text-xs text-gold font-medium">
                    Table {tableNumber} {tableName ? `• ${tableName}` : ''}
                  </p>
                ) : (
                  <p className="text-xs text-gray-400">Digital Order Cart</p>
                )}
              </div>
            </div>
            <button
              onClick={() => setIsOpen(false)}
              className="p-1.5 text-gray-400 hover:text-white rounded-lg hover:bg-surface-hover"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Table Missing Warning */}
          {!tableId && (
            <div className="m-4 p-3 bg-amber-950/40 border border-amber-800/40 rounded-xl flex items-start gap-2.5 text-amber-300 text-xs">
              <AlertCircle className="w-4 h-4 shrink-0 text-amber-400 mt-0.5" />
              <div>
                <span className="font-semibold">No Table Selected:</span>
                <p className="text-gray-300 mt-0.5">
                  Orders must be linked to a table. Scan the QR code at your dining table to enable instant kitchen delivery.
                </p>
              </div>
            </div>
          )}

          {/* Cart Items List */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {items.length === 0 ? (
              <div className="text-center py-16 px-4">
                <Utensils className="w-12 h-12 mx-auto text-gray-600 mb-3" />
                <p className="text-base font-serif text-white">Your plate is empty</p>
                <p className="text-xs text-gray-400 mt-1 max-w-xs mx-auto">
                  Explore our seasonal menu and add your favorite dishes, wine pairings, and desserts.
                </p>
              </div>
            ) : (
              items.map((item) => (
                <div
                  key={item.menuItemId}
                  className="p-3 bg-surface rounded-xl border border-surface-border hover:border-gray-700 transition-all space-y-2.5"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1 min-w-0">
                      <h4 className="text-sm font-medium text-white truncate">{item.name}</h4>
                      <p className="text-xs text-gold font-semibold mt-0.5">
                        ${(item.price * item.quantity).toFixed(2)}{' '}
                        <span className="text-gray-400 font-normal">
                          (${item.price.toFixed(2)} each)
                        </span>
                      </p>
                    </div>

                    {/* Quantity controls */}
                    <div className="flex items-center gap-1.5 bg-surface-card border border-surface-border rounded-lg p-1">
                      <button
                        onClick={() => updateQuantity(item.menuItemId, item.quantity - 1)}
                        className="p-1 hover:text-gold text-gray-400 transition-colors"
                        title="Decrease"
                      >
                        <Minus className="w-3.5 h-3.5" />
                      </button>
                      <span className="text-xs font-bold text-white px-1.5">
                        {item.quantity}
                      </span>
                      <button
                        onClick={() => updateQuantity(item.menuItemId, item.quantity + 1)}
                        className="p-1 hover:text-gold text-gray-400 transition-colors"
                        title="Increase"
                      >
                        <Plus className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => removeItem(item.menuItemId)}
                        className="p-1 hover:text-rose-400 text-gray-500 border-l border-surface-border ml-1 pl-1.5 transition-colors"
                        title="Remove"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  {/* Special instruction per item */}
                  <input
                    type="text"
                    placeholder="Special instructions (e.g., sauce on side, allergies)..."
                    value={item.notes || ''}
                    onChange={(e) => updateNotes(item.menuItemId, e.target.value)}
                    className="w-full text-xs bg-surface-card border border-surface-border rounded-lg px-2.5 py-1.5 text-gray-200 placeholder-gray-500 focus:outline-none focus:border-gold/50"
                  />
                </div>
              ))
            )}
          </div>

          {/* Footer Controls */}
          {items.length > 0 && (
            <div className="p-4 border-t border-surface-border bg-surface/50 space-y-3">
              {/* Optional Guest Name / Order Notes */}
              <div className="space-y-2">
                <input
                  type="text"
                  placeholder="Your Name (Optional)"
                  value={guestName}
                  onChange={(e) => setGuestName(e.target.value)}
                  className="w-full text-xs bg-surface-card border border-surface-border rounded-lg px-3 py-2 text-white placeholder-gray-500 focus:outline-none focus:border-gold/50"
                />
                <input
                  type="text"
                  placeholder="Kitchen Notes (e.g. Serve together, celebrate birthday)..."
                  value={orderNotes}
                  onChange={(e) => setOrderNotes(e.target.value)}
                  className="w-full text-xs bg-surface-card border border-surface-border rounded-lg px-3 py-2 text-white placeholder-gray-500 focus:outline-none focus:border-gold/50"
                />
              </div>

              {/* Subtotal */}
              <div className="flex justify-between items-center pt-2 border-t border-surface-border">
                <span className="text-xs uppercase tracking-wider text-gray-400">Total Bill</span>
                <span className="text-lg font-serif font-bold text-gold">
                  ${totalAmount.toFixed(2)}
                </span>
              </div>

              {/* Submit Button */}
              <button
                onClick={handleSubmitOrder}
                disabled={isSubmitting || !tableId}
                className="w-full py-3.5 rounded-xl bg-gold hover:bg-gold-hover disabled:opacity-40 disabled:pointer-events-none text-background font-bold text-sm uppercase tracking-wider transition-all shadow-lg hover:shadow-gold/20 flex items-center justify-center gap-2"
              >
                {isSubmitting ? (
                  <span className="inline-block w-4 h-4 border-2 border-background border-t-transparent rounded-full animate-spin" />
                ) : (
                  <>
                    <span>Send Order to Kitchen</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

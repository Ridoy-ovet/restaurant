'use client';

import React from 'react';
import Link from 'next/link';
import { MapPin, Phone, Mail, Clock, Instagram, Facebook, Calendar } from 'lucide-react';

export function Footer() {
  return (
    <footer className="bg-surface-card border-t border-surface-border text-gray-400 text-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-10">
          {/* Col 1: Brand */}
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-full border border-gold/40 flex items-center justify-center bg-surface">
                <span className="text-gold font-serif font-bold text-base">É</span>
              </div>
              <span className="text-lg font-serif font-bold tracking-widest text-white">
                L'ÉTOILE
              </span>
            </div>
            <p className="text-xs text-gray-400 font-light leading-relaxed">
              Contemporary dining rooted in artisanal craftsmanship, wood-fired hearth cooking, and bespoke hospitality.
            </p>
            <div className="flex items-center gap-3 pt-2">
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noreferrer"
                className="w-8 h-8 rounded-full bg-surface border border-surface-border flex items-center justify-center text-gray-400 hover:text-gold hover:border-gold/40 transition-colors"
                aria-label="Instagram"
              >
                <Instagram className="w-4 h-4" />
              </a>
              <a
                href="https://facebook.com"
                target="_blank"
                rel="noreferrer"
                className="w-8 h-8 rounded-full bg-surface border border-surface-border flex items-center justify-center text-gray-400 hover:text-gold hover:border-gold/40 transition-colors"
                aria-label="Facebook"
              >
                <Facebook className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Col 2: Operating Hours */}
          <div className="space-y-3">
            <h4 className="text-white font-serif font-semibold text-sm uppercase tracking-wider flex items-center gap-2">
              <Clock className="w-4 h-4 text-gold" /> Service Hours
            </h4>
            <div className="space-y-1.5 text-xs">
              <div className="flex justify-between border-b border-surface-border/50 pb-1">
                <span>Mon – Wed:</span>
                <span className="text-gray-300">12:00–15:00 / 17:30–22:30</span>
              </div>
              <div className="flex justify-between border-b border-surface-border/50 pb-1">
                <span>Thu – Fri:</span>
                <span className="text-gray-300">12:00–15:30 / 17:30–23:30</span>
              </div>
              <div className="flex justify-between border-b border-surface-border/50 pb-1">
                <span>Saturday:</span>
                <span className="text-gray-300">11:30–16:00 / 17:00–23:30</span>
              </div>
              <div className="flex justify-between">
                <span>Sunday:</span>
                <span className="text-gray-300">11:30–16:00 / 17:00–22:00</span>
              </div>
            </div>
          </div>

          {/* Col 3: Location & Concierge */}
          <div className="space-y-3">
            <h4 className="text-white font-serif font-semibold text-sm uppercase tracking-wider flex items-center gap-2">
              <MapPin className="w-4 h-4 text-gold" /> Find Us
            </h4>
            <div className="space-y-2 text-xs">
              <p className="text-gray-300">
                428 Grand Boulevard, Suite 100<br />
                Metropolitan Arts District
              </p>
              <p className="flex items-center gap-2 text-gray-300">
                <Phone className="w-3.5 h-3.5 text-gold" />
                +1 (555) 843-9200
              </p>
              <p className="flex items-center gap-2 text-gray-300">
                <Mail className="w-3.5 h-3.5 text-gold" />
                concierge@letoile-brasserie.com
              </p>
            </div>
          </div>

          {/* Col 4: Quick Reservation */}
          <div className="space-y-3">
            <h4 className="text-white font-serif font-semibold text-sm uppercase tracking-wider flex items-center gap-2">
              <Calendar className="w-4 h-4 text-gold" /> Private Dining
            </h4>
            <p className="text-xs text-gray-400 font-light">
              Hosting an intimate reception, executive banquet, or anniversary tasting?
            </p>
            <Link
              href="/reservation"
              className="inline-block px-5 py-2.5 rounded-xl bg-gold hover:bg-gold-hover text-background font-bold text-xs uppercase tracking-wider transition-all shadow-md"
            >
              Reserve Experience
            </Link>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t border-surface-border flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-gray-500">
          <p>© {new Date().getFullYear()} L'Étoile Modern Brasserie. All culinary rights reserved.</p>
          <div className="flex gap-6">
            <Link href="/menu" className="hover:text-gold transition-colors">Digital Menu</Link>
            <Link href="/reservation" className="hover:text-gold transition-colors">Table Bookings</Link>
            <Link href="/login" className="hover:text-gold transition-colors">Staff Access</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}

# L'Étoile Modern Brasserie — Restaurant Reservation, QR Ordering & Management Platform

A complete, production-ready, minimalist, high-performance web application for modern fine dining and contemporary brasseries.

## 🚀 Key Features

- **Public Website & Branding**: Luxury minimalist aesthetic, fast First Contentful Paint, zero cumulative layout shift (CLS = 0), responsive navigation, dynamic hero section.
- **Online Table Reservation Engine**: Real-time timeslot availability calculation, double-booking prevention, party size restrictions, meal periods (Lunch & Dinner), tokenized reservation management links (`RSV-XXXX-XXXX`), and transactional confirmation emails.
- **QR Table Management & Digital Ordering**: Unique secure table tokens (`/table/[token]`), mobile-optimized digital menu with category filtering, search, dietary tags, special instructions per dish, instant order creation (`ORD-XXXX`), and live order tracking.
- **Call Waiter System**: One-tap summoning from any table with anti-spam cooldown protection (120s timer) and instant real-time sound/banner notifications on staff terminals.
- **All-in-One Admin & Staff Operations Deck (`/admin`)**:
  - Live Kitchen Display System (KDS) with status progression (`NEW` -> `CONFIRMED` -> `PREPARING` -> `READY` -> `SERVED` -> `COMPLETED`)
  - Reservation management with search, filters, and manual phone booking
  - Table Floor Plan editor with SVG QR code generation and printable tent cards
  - Menu catalog with instant 86/Sold-Out toggles and price editing
  - Scheduled promotions and banner manager
  - Website settings and service hours editor (fully customizable without code)
  - Real-time Server-Sent Events (SSE) stream with zero external socket dependencies
  - Administrative audit log timeline and business performance analytics

## 🛠️ Technology Stack

- **Framework**: Next.js 14+ (App Router)
- **Frontend**: React 18, Tailwind CSS, Lucide Icons
- **Backend & API**: Next.js Route Handlers (REST), Web Streams API (SSE)
- **Database & ORM**: Prisma ORM (SQLite for zero-config local reliability; switchable to PostgreSQL via `DATABASE_URL`)
- **Authentication**: Bcrypt password hashing, signed HTTP-only JWT cookies, Role-Based Access Control (`SUPER_ADMIN`, `MANAGER`, `STAFF`, `CUSTOMER`)
- **QR Code Engine**: SVG and DataURL QR generator linking directly to secure table sessions

## 📋 Default Credentials (Pre-Seeded)

- **Super Admin**: `admin@restaurant.com` / `admin123`
- **Manager**: `manager@restaurant.com` / `manager123`
- **Staff / Waiter**: `staff@restaurant.com` / `staff123`
- **Customer**: `john@example.com` / `customer123`

## 🏃 Running the Application

```bash
# 1. Install dependencies
npm install

# 2. Database Sync & Seeding
npx prisma db push
node prisma/seed.js

# 3. Development Mode
npm run dev

# 4. Production Build & Start
npm run build
npm start
```

Access the application at `http://localhost:3000`.

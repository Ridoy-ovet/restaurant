/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        background: "#0c0e12",
        foreground: "#f3f4f6",
        surface: {
          DEFAULT: "#141820",
          hover: "#1c222e",
          card: "#161b24",
          border: "#252e3d",
        },
        gold: {
          DEFAULT: "#d4af37",
          hover: "#e5c058",
          light: "#f9e7b2",
          dark: "#997d1e",
        },
        accent: {
          amber: "#f59e0b",
          emerald: "#10b981",
          rose: "#f43f5e",
        }
      },
      fontFamily: {
        sans: ['system-ui', '-apple-system', 'BlinkMacSystemFont', 'Segoe UI', 'Roboto', 'sans-serif'],
      },
    },
  },
  plugins: [],
}

const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcryptjs');

const prisma = new PrismaClient();

async function main() {
  console.log('🌱 Starting comprehensive database seeding...');

  // Clean old records
  await prisma.auditLog.deleteMany();
  await prisma.orderItem.deleteMany();
  await prisma.order.deleteMany();
  await prisma.waiterRequest.deleteMany();
  await prisma.reservation.deleteMany();
  await prisma.menuItem.deleteMany();
  await prisma.menuCategory.deleteMany();
  await prisma.table.deleteMany();
  await prisma.promotion.deleteMany();
  await prisma.restaurantSettings.deleteMany();
  await prisma.user.deleteMany();

  // 1. Create Users
  const superAdminPassword = await bcrypt.hash('admin123', 10);
  const managerPassword = await bcrypt.hash('manager123', 10);
  const staffPassword = await bcrypt.hash('staff123', 10);
  const customerPassword = await bcrypt.hash('customer123', 10);

  const admin = await prisma.user.create({
    data: {
      email: 'admin@restaurant.com',
      passwordHash: superAdminPassword,
      name: 'Henri Moreau (Executive Chef & Owner)',
      phone: '+1 (555) 019-2831',
      role: 'SUPER_ADMIN',
    },
  });

  const manager = await prisma.user.create({
    data: {
      email: 'manager@restaurant.com',
      passwordHash: managerPassword,
      name: 'Claire Laurent (General Manager)',
      phone: '+1 (555) 019-2832',
      role: 'MANAGER',
    },
  });

  const staff = await prisma.user.create({
    data: {
      email: 'staff@restaurant.com',
      passwordHash: staffPassword,
      name: 'Antoine Dubois (Head Waiter)',
      phone: '+1 (555) 019-2833',
      role: 'STAFF',
    },
  });

  const customer = await prisma.user.create({
    data: {
      email: 'john@example.com',
      passwordHash: customerPassword,
      name: 'John Doe',
      phone: '+1 (555) 443-8899',
      role: 'CUSTOMER',
    },
  });

  console.log('✓ Created users (Admin, Manager, Staff, Customer)');

  // 2. Restaurant Settings
  await prisma.restaurantSettings.create({
    data: {
      id: 'default',
      name: "L'Étoile Modern Brasserie",
      tagline: 'Artisanal Gastronomy & Contemporary Dining',
      description: 'An immersive culinary journey celebrating wood-fired techniques, rare seasonal harvests, and cellar-reserve pairings in an architecturally refined space.',
      address: '428 Grand Boulevard, Suite 100, Metropolitan Arts District',
      phone: '+1 (555) 843-9200',
      email: 'concierge@letoile-brasserie.com',
      heroBanner: 'https://images.unsplash.com/photo-1544025162-d76694265947?q=80&w=1600&auto=format&fit=crop',
      logoUrl: '',
      faviconUrl: '',
      openingHours: JSON.stringify({
        monday: { closed: false, lunch: '12:00 - 15:00', dinner: '17:30 - 22:30' },
        tuesday: { closed: false, lunch: '12:00 - 15:00', dinner: '17:30 - 22:30' },
        wednesday: { closed: false, lunch: '12:00 - 15:00', dinner: '17:30 - 22:30' },
        thursday: { closed: false, lunch: '12:00 - 15:00', dinner: '17:30 - 23:00' },
        friday: { closed: false, lunch: '12:00 - 15:30', dinner: '17:30 - 23:30' },
        saturday: { closed: false, lunch: '11:30 - 16:00', dinner: '17:00 - 23:30' },
        sunday: { closed: false, lunch: '11:30 - 16:00', dinner: '17:00 - 22:00' },
      }),
      bookingConfig: JSON.stringify({
        intervalMinutes: 15,
        defaultDurationMinutes: 90,
        minNoticeHours: 1,
        maxAdvanceDays: 60,
        minPartySize: 1,
        maxPartySize: 12,
        closedDates: ['2026-12-25', '2027-01-01'],
      }),
      socialLinks: JSON.stringify({
        instagram: 'https://instagram.com/letoile_dining',
        facebook: 'https://facebook.com/letoiledining',
        tripadvisor: 'https://tripadvisor.com',
      }),
    },
  });

  console.log('✓ Created restaurant settings');

  // 3. Tables
  const tableData = [
    { tableNumber: 1, name: 'Table 01 (Window Alcove)', capacity: 2, section: 'Indoor Main', status: 'AVAILABLE', qrToken: 'tbl_ind_01' },
    { tableNumber: 2, name: 'Table 02 (Center Banquette)', capacity: 4, section: 'Indoor Main', status: 'AVAILABLE', qrToken: 'tbl_ind_02' },
    { tableNumber: 3, name: 'Table 03 (Chef Hearth View)', capacity: 4, section: 'Indoor Main', status: 'OCCUPIED', qrToken: 'tbl_ind_03' },
    { tableNumber: 4, name: 'Table 04 (Grand Round)', capacity: 6, section: 'Indoor Main', status: 'AVAILABLE', qrToken: 'tbl_ind_04' },
    { tableNumber: 5, name: 'Table 05 (Veranda Sunset)', capacity: 2, section: 'Sunset Terrace', status: 'AVAILABLE', qrToken: 'tbl_ter_05' },
    { tableNumber: 6, name: 'Table 06 (Terrace Pergola)', capacity: 4, section: 'Sunset Terrace', status: 'RESERVED', qrToken: 'tbl_ter_06' },
    { tableNumber: 7, name: 'Table 07 (Terrace Corner)', capacity: 4, section: 'Sunset Terrace', status: 'AVAILABLE', qrToken: 'tbl_ter_07' },
    { tableNumber: 8, name: 'Table 08 (Garden Fountain)', capacity: 4, section: 'Garden Patio', status: 'AVAILABLE', qrToken: 'tbl_pat_08' },
    { tableNumber: 9, name: 'Table 09 (Olive Tree Pergola)', capacity: 6, section: 'Garden Patio', status: 'AVAILABLE', qrToken: 'tbl_pat_09' },
    { tableNumber: 10, name: 'Table 10 (Sommelier Cellar)', capacity: 8, section: 'Private VIP Lounge', status: 'AVAILABLE', qrToken: 'tbl_vip_10' },
    { tableNumber: 11, name: 'Table 11 (The President Suite)', capacity: 12, section: 'Private VIP Lounge', status: 'AVAILABLE', qrToken: 'tbl_vip_11' },
    { tableNumber: 12, name: 'Table 12 (Mixologist Counter)', capacity: 2, section: 'Artisan Bar', status: 'AVAILABLE', qrToken: 'tbl_bar_12' },
  ];

  const createdTables = [];
  for (const t of tableData) {
    const tbl = await prisma.table.create({ data: t });
    createdTables.push(tbl);
  }
  console.log(`✓ Created ${createdTables.length} tables with secure QR tokens`);

  // 4. Menu Categories
  const catStarters = await prisma.menuCategory.create({
    data: { name: 'Starters & Crudo', slug: 'starters', description: 'Light appetisers, crudo, and fresh garden selections.', displayOrder: 1 },
  });
  const catMains = await prisma.menuCategory.create({
    data: { name: 'Signature Entrées', slug: 'mains', description: 'Mastercrafted poultry, fresh coastal catches, and hand-rolled pasta.', displayOrder: 2 },
  });
  const catGrill = await prisma.menuCategory.create({
    data: { name: 'Wood-Fired Prime Grill', slug: 'grill', description: 'Charred over Japanese Binchotan oak and finished with smoked herb marrow.', displayOrder: 3 },
  });
  const catDesserts = await prisma.menuCategory.create({
    data: { name: 'Artisan Patisserie', slug: 'desserts', description: 'Deconstructed classics, handcrafted gelato, and French confections.', displayOrder: 4 },
  });
  const catDrinks = await prisma.menuCategory.create({
    data: { name: 'Botanical Cocktails & Cellar', slug: 'drinks', description: 'Handcrafted aperitifs, vintage natural wines, and zero-proof elixirs.', displayOrder: 5 },
  });

  // 5. Menu Items
  const items = [
    // Starters
    {
      categoryId: catStarters.id,
      name: 'Wild Bluefin Tuna Tartare',
      description: 'Avocado mousse, yuzu kosho ponzu, cured egg yolk, nori crisp.',
      price: 24.0,
      discountPrice: null,
      imageUrl: 'https://images.unsplash.com/photo-1534422298391-e4f8c172dddb?q=80&w=800&auto=format&fit=crop',
      isAvailable: true,
      isFeatured: true,
      tags: "Chef's Special, Signature",
      dietary: 'Gluten-Free, Dairy-Free',
      displayOrder: 1,
    },
    {
      categoryId: catStarters.id,
      name: 'Heirloom Burrata & Charred Figs',
      description: 'Aged balsamic pearls, pistachio crumble, micro basil, sourdough crostini.',
      price: 19.5,
      discountPrice: null,
      imageUrl: 'https://images.unsplash.com/photo-1592417817098-8f3d69102a56?q=80&w=800&auto=format&fit=crop',
      isAvailable: true,
      isFeatured: true,
      tags: 'Organic',
      dietary: 'Vegetarian',
      displayOrder: 2,
    },
    {
      categoryId: catStarters.id,
      name: 'Hokkaido Scallop Crudo',
      description: 'Blood orange reduction, finger lime pearls, chili oil, sea coriander.',
      price: 26.0,
      discountPrice: 22.0,
      imageUrl: 'https://images.unsplash.com/photo-1544025162-d76694265947?q=80&w=800&auto=format&fit=crop',
      isAvailable: true,
      isFeatured: false,
      tags: 'Seasonal Catch',
      dietary: 'Gluten-Free',
      displayOrder: 3,
    },
    {
      categoryId: catStarters.id,
      name: 'Truffled Forest Mushroom Velouté',
      description: 'Crisp brioche soldiers, chive blossom, 24-month aged parmesan foam.',
      price: 17.0,
      discountPrice: null,
      imageUrl: 'https://images.unsplash.com/photo-1547592166-23ac45744acd?q=80&w=800&auto=format&fit=crop',
      isAvailable: true,
      isFeatured: false,
      tags: 'Autumn Special',
      dietary: 'Vegetarian',
      displayOrder: 4,
    },

    // Mains
    {
      categoryId: catMains.id,
      name: 'Pan-Seared Chilean Sea Bass',
      description: 'Lemongrass broth, baby bok choy, lotus root crisp, kaffir lime oil.',
      price: 46.0,
      discountPrice: null,
      imageUrl: 'https://images.unsplash.com/photo-1519708227418-c8fd9a32b7a2?q=80&w=800&auto=format&fit=crop',
      isAvailable: true,
      isFeatured: true,
      tags: 'Signature, Coastal Catch',
      dietary: 'Gluten-Free',
      displayOrder: 1,
    },
    {
      categoryId: catMains.id,
      name: 'Handcrafted Truffle Tagliolini',
      description: 'Cultured Normandy butter, shaved Black Perigord truffles, aged Reggiano.',
      price: 36.0,
      discountPrice: null,
      imageUrl: 'https://images.unsplash.com/photo-1556760544-74068565f05c?q=80&w=800&auto=format&fit=crop',
      isAvailable: true,
      isFeatured: true,
      tags: "Chef's Handrolled",
      dietary: 'Vegetarian',
      displayOrder: 2,
    },
    {
      categoryId: catMains.id,
      name: 'Crisp-Skin Duck Breast à l’Orange',
      description: 'Spiced parsnip purée, caramelized blood orange jus, charred baby carrots.',
      price: 39.0,
      discountPrice: null,
      imageUrl: 'https://images.unsplash.com/photo-1514944298352-78d123e4210d?q=80&w=800&auto=format&fit=crop',
      isAvailable: true,
      isFeatured: false,
      tags: 'Classic French',
      dietary: 'Gluten-Free',
      displayOrder: 3,
    },
    {
      categoryId: catMains.id,
      name: 'Roasted Saffron Cauliflower Steak',
      description: 'Whipped tahini, pomegranate molasses, toasted pine nuts, mint chimichurri.',
      price: 28.0,
      discountPrice: null,
      imageUrl: 'https://images.unsplash.com/photo-1540420773420-3366772f4999?q=80&w=800&auto=format&fit=crop',
      isAvailable: true,
      isFeatured: false,
      tags: 'Plant-Based',
      dietary: 'Vegan, Gluten-Free',
      displayOrder: 4,
    },

    // Grill
    {
      categoryId: catGrill.id,
      name: 'Miyazaki A5 Wagyu Ribeye (6oz)',
      description: 'Smoked Maldon sea salt, tare glaze, wasabi stem relish, bone marrow confit.',
      price: 95.0,
      discountPrice: 85.0,
      imageUrl: 'https://images.unsplash.com/photo-1558030006-450675393462?q=80&w=800&auto=format&fit=crop',
      isAvailable: true,
      isFeatured: true,
      tags: 'Prime Reserve, Binchotan Grilled',
      dietary: 'Gluten-Free',
      displayOrder: 1,
    },
    {
      categoryId: catGrill.id,
      name: 'Dry-Aged Tomahawk Rib Steak (32oz)',
      description: '45-day Himalayan salt cave aged, rosemary smoked butter, roasted shallots (serves 2).',
      price: 135.0,
      discountPrice: null,
      imageUrl: 'https://images.unsplash.com/photo-1544025162-d76694265947?q=80&w=800&auto=format&fit=crop',
      isAvailable: true,
      isFeatured: false,
      tags: 'Sharing Feast',
      dietary: 'Gluten-Free',
      displayOrder: 2,
    },
    {
      categoryId: catGrill.id,
      name: 'Charred Iberian Pork Pluma',
      description: 'Acorn-fed bellota pork, apple cider reduction, roasted cipollini onions.',
      price: 42.0,
      discountPrice: null,
      imageUrl: 'https://images.unsplash.com/photo-1603048588665-791ca8aea617?q=80&w=800&auto=format&fit=crop',
      isAvailable: true,
      isFeatured: false,
      tags: 'Spanish Heritage',
      dietary: 'Gluten-Free',
      displayOrder: 3,
    },

    // Desserts
    {
      categoryId: catDesserts.id,
      name: 'Valrhona Dark Chocolate Soufflé',
      description: '70% Guanaja chocolate, Grand Marnier crème anglaise, Tahitian vanilla bean gelato.',
      price: 18.0,
      discountPrice: null,
      imageUrl: 'https://images.unsplash.com/photo-1579372786545-d24232daf58c?q=80&w=800&auto=format&fit=crop',
      isAvailable: true,
      isFeatured: true,
      tags: 'Baked to Order',
      dietary: 'Vegetarian',
      displayOrder: 1,
    },
    {
      categoryId: catDesserts.id,
      name: 'Smoked Salt Mille-Feuille',
      description: 'Caramelized puff pastry sheets, roasted hazelnut praline, whipped mascarpone cream.',
      price: 16.5,
      discountPrice: null,
      imageUrl: 'https://images.unsplash.com/photo-1509440159596-0249088772ff?q=80&w=800&auto=format&fit=crop',
      isAvailable: true,
      isFeatured: false,
      tags: 'House Specialty',
      dietary: 'Vegetarian',
      displayOrder: 2,
    },
    {
      categoryId: catDesserts.id,
      name: 'Meyer Lemon & Yuzu Tartlet',
      description: 'Toasted Swiss meringue peaks, sable crust, candied lemon zest pearls.',
      price: 15.0,
      discountPrice: null,
      imageUrl: 'https://images.unsplash.com/photo-1551024709-8f23befc6f87?q=80&w=800&auto=format&fit=crop',
      isAvailable: true,
      isFeatured: false,
      tags: 'Refreshing',
      dietary: 'Vegetarian',
      displayOrder: 3,
    },

    // Drinks
    {
      categoryId: catDrinks.id,
      name: 'Smoked Rosemary Old Fashioned',
      description: 'Kentucky Bourbon, charred rosemary smoke, Angostura & orange bitters, demerara.',
      price: 21.0,
      discountPrice: null,
      imageUrl: 'https://images.unsplash.com/photo-1514362545857-3bc16c4c7d1b?q=80&w=800&auto=format&fit=crop',
      isAvailable: true,
      isFeatured: true,
      tags: 'Signature Cocktail',
      dietary: 'Vegan, Gluten-Free',
      displayOrder: 1,
    },
    {
      categoryId: catDrinks.id,
      name: 'French 75 Imperial',
      description: 'Botanical French Gin, fresh lemon juice, champagne reserve brut, golden sugar crystal.',
      price: 22.0,
      discountPrice: null,
      imageUrl: 'https://images.unsplash.com/photo-1551024709-8f23befc6f87?q=80&w=800&auto=format&fit=crop',
      isAvailable: true,
      isFeatured: false,
      tags: 'Sparkling Elegance',
      dietary: 'Vegan',
      displayOrder: 2,
    },
    {
      categoryId: catDrinks.id,
      name: 'Elderflower & Yuzu Spritz (Zero-Proof)',
      description: 'Wild elderflower distillate, sparkling San Pellegrino, crushed cucumber, mint sprig.',
      price: 14.0,
      discountPrice: null,
      imageUrl: 'https://images.unsplash.com/photo-1513558161293-cdaf765ed2fd?q=80&w=800&auto=format&fit=crop',
      isAvailable: true,
      isFeatured: false,
      tags: 'Non-Alcoholic, Zero-Proof',
      dietary: 'Vegan, Gluten-Free',
      displayOrder: 3,
    },
  ];

  const createdItems = [];
  for (const it of items) {
    const item = await prisma.menuItem.create({ data: it });
    createdItems.push(item);
  }
  console.log(`✓ Created ${createdItems.length} menu items`);

  // 6. Promotions
  await prisma.promotion.create({
    data: {
      title: 'Chef Henri’s Autumn Seven-Course Tasting Pairing',
      description: 'Reserve an intimate evening featuring our seasonal harvest menu paired with exclusive cellar vintages.',
      imageUrl: 'https://images.unsplash.com/photo-1510812431401-41d2bd2722f3?q=80&w=1200&auto=format&fit=crop',
      targetPage: 'HOME',
      buttonText: 'Reserve Experience',
      buttonUrl: '/reservation',
      startDate: '2026-09-01',
      endDate: '2026-11-30',
      isActive: true,
    },
  });

  await prisma.promotion.create({
    data: {
      title: 'Sommelier Sunset Hour — 20% Off Reserve Cocktails',
      description: 'Join us on the Sunset Terrace Monday through Thursday from 17:00 to 19:00 for bespoke cocktails and small plates.',
      imageUrl: 'https://images.unsplash.com/photo-1514362545857-3bc16c4c7d1b?q=80&w=1200&auto=format&fit=crop',
      targetPage: 'MENU',
      buttonText: 'Explore Cocktails',
      buttonUrl: '/menu?category=drinks',
      startDate: '2026-09-01',
      endDate: '2026-12-31',
      isActive: true,
    },
  });
  console.log('✓ Created promotions');

  // 7. Sample Reservation
  const sampleReservation = await prisma.reservation.create({
    data: {
      reservationCode: 'RSV-8821-X9',
      customerId: customer.id,
      guestName: 'John Doe',
      guestEmail: 'john@example.com',
      guestPhone: '+1 (555) 443-8899',
      partySize: 4,
      date: '2026-09-15',
      timeSlot: '19:30',
      durationMinutes: 90,
      tableId: createdTables[1].id, // Table 2
      status: 'CONFIRMED',
      specialRequests: 'Anniversary celebration. Quiet table requested.',
    },
  });
  console.log('✓ Created sample reservation:', sampleReservation.reservationCode);

  // 8. Sample Active Order & Waiter Call on Table 3
  const sampleOrder = await prisma.order.create({
    data: {
      orderNumber: 'ORD-1042',
      tableId: createdTables[2].id, // Table 3
      guestName: 'Madame DuPont',
      status: 'PREPARING',
      totalAmount: 119.0,
      notes: 'Please serve tuna crudo first as appetizer.',
      paymentStatus: 'UNPAID',
      items: {
        create: [
          {
            menuItemId: createdItems[0].id, // Tuna Tartare
            quantity: 1,
            unitPrice: 24.0,
            notes: 'Extra nori crisps',
          },
          {
            menuItemId: createdItems[8].id, // A5 Wagyu
            quantity: 1,
            unitPrice: 95.0,
            notes: 'Cooked Medium-Rare',
          },
        ],
      },
    },
  });

  const sampleWaiterReq = await prisma.waiterRequest.create({
    data: {
      tableId: createdTables[2].id,
      status: 'PENDING',
    },
  });

  // 9. Initial Audit Log
  await prisma.auditLog.create({
    data: {
      userId: admin.id,
      userName: admin.name,
      userRole: admin.role,
      action: 'SYSTEM_INITIALIZATION',
      entity: 'System',
      details: 'Initial restaurant database seeded with complete menu, tables, and settings.',
    },
  });

  console.log('🎉 Database successfully seeded with all initial restaurant data!');
}

main()
  .catch((e) => {
    console.error('Error during seeding:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
